# Auth plan: pick this up on any machine

Status: **code is done and pushed; the Supabase project is not created yet.** Nothing below has been tested against real Supabase, real emails, tab-close logout, offline mode or phones. It was only run in a browser against a mocked Supabase SDK.

- Branch: `auth-initials` (repo `sumayya123F/Sunday-Driver`)
- Pull request: https://github.com/sumayya123F/Sunday-Driver/pull/5 (**do not merge until Supabase is set up**: merging to `main` auto-deploys to Vercel, and until `src/config.js` has real keys the live site shows "Sign-in is not set up yet" and nobody can play)
- Live site: https://sunday-driver-2.vercel.app

## Decisions already made

| Topic | Decision |
|---|---|
| Backend | Supabase free tier (Postgres + Auth), called straight from the browser |
| Login | **Email only**, no Supabase Auth, no link, code or password. `enter_app(email)` returns the `user_id` (old users matched by email keep theirs). Emails are treated as verified; anyone knowing an address can enter as it (accepted: development project). The browser only calls database functions; entry never depends on the database |
| Email sending | Free custom SMTP (Brevo) because Supabase's built-in mailer is tightly rate-limited |
| Screens | One "Continue with email" screen. First login asks for display name (2–24 chars, not unique) + one of 12 preset vehicle avatars (stored as `car-1`…`car-12`) |
| Gating | Sign-in screen before everything. Sign out is on Start and in Pause |
| Login log | One `sessions` row per visit. 30 s ping. `Sign out` = `manual`; closing the tab = `tab_closed` (best effort); no ping for 2 min = `timeout` (ended at last ping, computed in a view). No IP/device stored |
| Who sees the log | Only you, in the Supabase dashboard (view `sessions_history`) |
| Journey | Saved per user in the database (30 s throttle + pause/leave/close). `localStorage` is an offline cache, keyed per user. An old anonymous save is adopted once by an account with none |
| Prefs | Quality, volume and mute stay in `localStorage` per device |
| Keys in repo | `src/config.js` holds the project URL + anon key (public by design; Row Level Security protects data). **Never use the `service_role` key** |
| Offline | Signed-in users with a cached session can still start. A new sign-in needs the network. Failed journey saves retry later |

## What was built (in `sunday-driver/`)

- `src/auth.js`: Supabase client, email-only sign-in, profile, session log, journey sync
- `src/config.js`: URL + anon key (**still placeholders**)
- `src/save.js`: per-user journey key, merge with remote, one-time legacy adoption
- `src/menus.js`, `menus.css`, `index.html`: sign-in + profile screens, user chip on Start, account row in Pause
- `src/main.js`: auth gate, sign-out, session start/ping/end, journey push
- `supabase/schema.sql`: tables, Row Level Security, the 3 session functions, `sessions_history` view
- `README.md`: "Accounts (Supabase)" section with the same setup steps

## To do next (in order)

1. **Create the project:** supabase.com, sign in with GitHub, New project (free, no card). Choose a name, a database password and the nearest region.
2. **Create the tables:** SQL Editor, New query, paste all of `sunday-driver/supabase/schema.sql`, Run. Expect "Success".
3. **Email-only entry:** SQL Editor, paste `sunday-driver/supabase/email-auth.sql`, Run (after step 2). Nothing to change under Authentication; who and when is in `sessions_history`.
3b. (Not needed any more) **Redirect URLs:** Authentication, URL Configuration. Add only `https://sunday-driver-2.vercel.app` as a Redirect URL (no local testing: the owner codes from GitHub and tests on the live site). Set Site URL to the same address.
4. **Email sending:** create a free Brevo account, verify a sender address, then paste its SMTP host, port, login and key into Authentication, Emails, SMTP Settings.
5. **Get the keys:** Settings, API. Copy the **Project URL** and the **anon public** key into `sunday-driver/src/config.js` (both are safe to commit; this project uses the `sb_publishable_` key). Commit and push to `auth-initials`.
6. **Merge PR #5** into `main` (only after step 5 is pushed). Vercel deploys `main` only, so the live site has no sign-in until the merge. If it breaks, revert the merge on GitHub and the old version redeploys.
7. **Test on the live site** (`https://sunday-driver-2.vercel.app`):
   - Type your email and press Continue (no email is sent).
   - Set a name and avatar, then drive and pause. The journey should survive a reload.
   - Sign out, and check the row in Table editor, `sessions_history` (`status` = `manual`).
   - Close the tab (expect `tab_closed`), or leave it 2+ minutes (expect `timeout`).
   - Sign in on a second browser and confirm the journey follows you.
   - Try a phone in landscape.

## Resuming with Claude

Open the repo on branch `auth-initials` and say: *"Read auth-plan.md and continue from the To-do list."* The design questions are settled, so no re-grilling is needed.
