# City Drive — Design Briefing

A browser-based 3D driving simulation where players pick a city and a vehicle, then drive freely while changing the weather on the fly.

---

## 1. Project Summary

| Item | Decision |
|---|---|
| Format | Single-page website, full screen, **no scrolling** at any point |
| Genre | Free-roam driving simulation (no missions, no fail state) |
| Visual style | Simple 3D / low-poly. Flat-colored shapes, no textures, no fine detail |
| Core choices | 3 cities × vehicle choice × 4 weather types |
| Platform | Desktop browser first; playable on tablet and phone (touch controls) |
| Priority | Smooth performance over visual detail |

---

## 2. Visual Direction

### Style rules
- **Low-poly, geometric.** Buildings are boxes, trees are cones or spheres on cylinders, cars are a few stacked blocks with cylinder wheels.
- **Flat colors, no textures.** Color and simple lighting do all the work. Windows can be a lighter or darker rectangle, not modelled glass.
- **Soft shading.** One sun/moon light plus ambient light. Simple shadows only under vehicles (a dark blob is fine).
- **Readable silhouettes.** Each city should be recognisable from shape and color alone, even at a glance.
- **No small props unless they matter.** Street lamps, traffic lights and a few trees are enough. Skip benches, signs, litter, etc.

### Mood references (for the designer)
Think toy-model city, papercraft diorama, or isometric mobile game — clean, friendly, uncluttered.

---

## 3. Screens & Flow

All screens fit inside one viewport. Transitions happen in place (fade or slide), never by scrolling.

```
[Start Screen] → [Choose City] → [Choose Vehicle] → [Drive]
                                                        ↕
                                               [Pause Menu]
```

### 3.1 Start Screen
- Game title, large.
- Slowly rotating camera over a sample city in the background.
- One button: **Start Driving**.

### 3.2 Choose City
- 3 large cards side by side (stacked on phone).
- Each card: city name, small 3D preview or illustration, one-line description.
- Selected card is highlighted; **Next** button.

### 3.3 Choose Vehicle
- Vehicle shown on a turntable in the center, rotating.
- Left/right arrows to cycle vehicles.
- Simple stat bars under it: **Speed**, **Handling**, **Size**.
- Optional: 3–4 color swatches to repaint the vehicle.
- **View choice:** two toggle buttons, **Outside** and **Driver**. Picking **Driver** moves the preview camera into the left-hand driver seat so the player sees the interior before driving; picking **Outside** returns to the rotating turntable.
- **Back** and **Drive** buttons.

### 3.4 Drive (main gameplay)
Full-screen 3D view with a light HUD overlay (see Section 7). The player can drive in one of two views and switch between them at any time (see 3.5).

### 3.5 Driving Views

Two views only. The player picks one on the Choose Vehicle screen (default: Outside) and can switch any time while driving with the **View** button or the **C** key. The switch is a quick smooth camera move (about 0.5 seconds), not a hard cut.

#### View 1 — Outside View (third person)
- The whole vehicle is visible in the center-lower part of the screen, seen from behind and slightly above.
- The camera follows the vehicle smoothly and swings a little wider in turns.
- Same vehicle model as the rotating turntable on the Choose Vehicle screen, so the player sees the exact vehicle they picked, in the color they picked.
- Good for: seeing the city, the weather and the vehicle together.

#### View 2 — Driver View (first person, inside the car)
- The camera sits at the **driver's eye height in the left-hand seat** (left-hand drive). The road ahead appears slightly to the right of the steering wheel, as in a real left-hand-drive car.
- Visible interior, kept very simple (flat colors, few shapes):
  - **Steering wheel** in front of the driver on the left; it turns when the player steers.
  - **Dashboard** as one flat block across the bottom of the screen, with a simple speed dial behind the wheel.
  - **Windshield frame**: roof edge at the top, pillars on the left and right edges.
  - **Rear-view mirror** at the top center; **left side mirror** visible through the driver's window.
  - The empty passenger seat area on the right is only hinted at (edge of the seat or dashboard continuing).
- Weather appears on the windshield: raindrops in rain, a few snowflakes landing in snow, and **wipers** that sweep during rain and snow.
- The HUD speedometer hides in this view, since the dashboard dial shows the speed. Weather switcher, mini-map and pause stay.
- A small, slow head bob or camera sway at speed is optional; keep it subtle to avoid motion sickness.

#### Driver view per vehicle
| Vehicle | Seat position & interior |
|---|---|
| Hatchback | Normal seat height, short hood visible over the dashboard |
| Sports Car | Low seat, wide dashboard, long hood visible |
| SUV / Jeep | High seat, tall upright windshield |
| City Bus | Very high seat at the front left, huge windshield, large flat wheel |
| Motorbike | No cabin: handlebars and a small speed display at the bottom, no windshield frame or wipers |

### 3.6 Pause Menu
- Overlay on top of the frozen game, background dimmed.
- Options: **Resume**, **Change Vehicle**, **Change City**, **Driving View (Outside / Driver)**, **Quality (Low / High)**, **Main Menu**.

---

## 4. The Three Cities

Each city is a compact, looping map (a grid of blocks with an outer ring road) so players never hit a dead end. Target size: about 2–3 minutes to drive across.

### City A — Harbor Town
- **Feel:** coastal, relaxed, sunny-day postcard.
- **Layout:** waterfront road along a bay, a pier, small 2–4 storey buildings, a lighthouse as the landmark.
- **Palette:** white, sky blue, sand, coral accents, deep blue water.
- **Unique element:** water plane with gentle color shift; boats as simple floating blocks.

### City B — Metro Downtown
- **Feel:** big, busy, modern.
- **Layout:** strict grid, wide avenues, tall towers (box stacks of varying heights), one elevated highway loop, a central park.
- **Palette:** cool greys, glass blue, warm yellow taxis, neon accents at night.
- **Unique element:** tallest tower as the landmark; lit windows that glow when the sky darkens.

### City C — Mountain Village
- **Feel:** cozy, scenic, winding.
- **Layout:** curvy roads climbing a hill, a bridge over a river, small chalets, pine forest around the edges, a church/clock tower as the landmark.
- **Palette:** pine green, timber brown, stone grey, red roofs.
- **Unique element:** height changes — the only city with slopes; mountains as large background cones.

---

## 5. Vehicles

Each vehicle is built from basic shapes (boxes, cylinders) and drives with a slightly different feel.

| Vehicle | Speed | Handling | Size | Notes |
|---|---|---|---|---|
| Hatchback | ●●●○○ | ●●●●○ | Small | Balanced, the default pick |
| Sports Car | ●●●●● | ●●●○○ | Small | Fast, low, slides on wet/snowy roads |
| SUV / Jeep | ●●●○○ | ●●●○○ | Medium | Best grip in snow |
| City Bus | ●●○○○ | ●●○○○ | Large | Slow, wide turns, high camera |
| Motorbike | ●●●●○ | ●●●●● | Tiny | Quick and nimble, tilts when turning |

Minimum for launch: **3 vehicles** (Hatchback, Sports Car, SUV). Bus and Motorbike are stretch goals.

---

## 6. Weather System

Players can switch weather at any time during the drive. Changes should **blend smoothly over 2–3 seconds** (sky color, fog, light), not snap.

| Weather | Sky & Light | Particles | Road & Ground | Driving effect |
|---|---|---|---|---|
| **Sunny** | Bright blue sky, warm strong light, sharp shadow | None | Normal colors | Full grip |
| **Cloudy** | Grey-white sky, soft flat light, no shadow | A few slow cloud shapes overhead | Slightly muted colors | Full grip |
| **Rainy** | Dark grey sky, dim cool light, light fog | Falling streaks (simple lines) | Darker, shinier road tint; small puddle patches | Reduced grip, longer braking |
| **Snowy** | Pale grey-white sky, soft cool light, thicker fog | Slow drifting white dots | White ground and rooftops, road stays grey with white edges | Lowest grip, cars slide |

### Weather control (UI)
- A compact switcher in a corner of the HUD with **4 icon buttons**: ☀ Sunny · ☁ Cloudy · 🌧 Rainy · ❄ Snowy.
- Active weather is highlighted.
- Keyboard shortcut: number keys **1–4**.

### Optional extras (stretch)
- Day / night toggle (or a time slider).
- Thunder flash during rain.
- Tire tracks in snow.

---

## 7. HUD (In-Game Overlay)

Keep it minimal so the city stays the focus. Elements sit in the corners; the center stays clear.

```
┌──────────────────────────────────────────────────┐
│ [City name]                     [☀][☁][🌧][❄]   │
│                                                  │
│                                                  │
│                  (3D driving view)               │
│                                                  │
│                                                  │
│ [Mini-map]                      [Speed 64 km/h]  │
│                                   [View] [Pause] │
└──────────────────────────────────────────────────┘
```

In Driver view the bottom of the screen is the dashboard, so the HUD speedometer hides and the corner items sit just above the dashboard line.

- **Top left:** current city name.
- **Top right:** weather switcher.
- **Bottom left:** small circular mini-map (top-down dots and lines, player arrow).
- **Bottom right:** speedometer (big number + unit), View toggle (Outside / Driver), pause button.
- **Phone:** on-screen steering arrows bottom left, gas/brake bottom right; mini-map shrinks or hides.

---

## 8. Controls

| Action | Keyboard | Touch |
|---|---|---|
| Accelerate | W / ↑ | Gas button |
| Brake / Reverse | S / ↓ | Brake button |
| Steer | A D / ← → | Left/Right buttons |
| Handbrake | Space | — |
| Horn | H | Tap vehicle icon |
| Switch view (Outside / Driver) | C | View button |
| Weather | 1 – 4 | Weather buttons |
| Pause | Esc / P | Pause button |

**Driving views:** Outside (third person, default) · Driver (inside, left-hand seat). See Section 3.5.

---

## 9. City Life (Keep Light)

- A handful of simple AI cars driving loops on main roads (5–10 per city).
- Traffic lights that change color (visual only, not enforced).
- No pedestrians at launch, or very simple capsule figures on sidewalks as a stretch goal.
- Collisions: vehicles bump off buildings and other cars; no damage system.

---

## 10. Performance Targets

The simple look exists to keep the game smooth. Designers should respect these limits:

- **Target:** 60 fps on a mid-range laptop, 30+ fps on a modern phone.
- **No textures** (or tiny ones only); use flat colors.
- **Low polygon counts:** a building is a box (12 triangles); a vehicle under ~500 triangles.
- **Reuse shapes:** the same building / tree / lamp models repeated with different colors and sizes.
- **Fog hides distance:** far parts of the city fade into fog instead of being drawn in detail.
- **Particles capped:** rain and snow limited to a few thousand simple points or lines.
- **Quality toggle:** Low mode turns off shadows and halves particles.

---

## 11. Full-Screen / No-Scroll Rules

- The page always fills exactly the browser window; resizing the window resizes the game.
- No scrollbars on any screen, at any device size.
- Menus are overlays on the 3D scene, not separate pages.
- Optional **Fullscreen** button to hide the browser bar.
- On phone, recommend landscape with a "rotate your device" hint in portrait.

---

## 12. Design Deliverables Requested

For the design phase, please produce:

1. **Style frame** — one key image showing the low-poly look (vehicle on a street, sunny).
2. **City mood boards** — one per city with palette and landmark sketch.
3. **Weather comparison** — the same street shown in all 4 weathers.
4. **Vehicle sheet** — front/side/top views of each vehicle as simple shapes.
5. **Driver view frames** — the inside view from the left-hand driver seat for each vehicle, plus one frame each in rain and snow showing drops, flakes and wipers.
6. **UI screens** — Start, Choose City, Choose Vehicle (Outside and Driver preview), Drive HUD in both views, Pause (desktop + phone).
7. **Icon set** — weather icons, view toggle (Outside / Driver), pause, fullscreen, controls.
8. **Type & color tokens** — UI font choices and a shared UI palette that reads over both bright (sunny/snow) and dark (rain) scenes.

---

## 13. Open Questions

- Final game name?
- Should cities have a day/night cycle, or always daytime?
- Sound: engine sounds, rain/wind ambience, background music — in scope?
- Any scoring or challenges (e.g. checkpoints, timed laps), or pure free-roam?
- Should the selected city/vehicle/weather be remembered next visit?
