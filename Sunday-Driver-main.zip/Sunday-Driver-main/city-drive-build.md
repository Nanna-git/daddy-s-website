# Sunday Driver — Build Guide (Desktop)

A chill, free-roam driving toy. Build it in **4 stages**, in order. Each stage ends with something you can play, and a short **Done when** check.

- Briefing: [city-drive-briefing.md](city-drive-briefing.md)
- Design canvas: https://claude.ai/artifact/Fnq2td64CafxzLhYJD5LiM (private — share it from the page's Share menu before handing it on)
- First slice: **Harbor Town · Hatchback · Sunny**, desktop only.

---

## Decisions (closes the briefing's open questions)

| Question | Decision |
|---|---|
| Game name | **Sunday Driver** — tagline *"No rush. Nowhere to be."* |
| Day / night | **Yes** — a continuous cycle (20 real minutes per day), can be frozen from Pause |
| Sound | **Engine, rain, wind, horn.** No music |
| Goals | **Pure free roam** — no scores, timers, checkpoints or fail states |
| Memory | **Remember the last journey** — Start screen offers *Continue journey* |

---

## Stage 1 — Drive around Harbor Town

Goal: a car you can drive around a full loop of the city.

1. **Set up the project.** Vite + TypeScript + Three.js. One full-window `<canvas>` with `html, body { margin:0; height:100%; overflow:hidden }`. Resize renderer and camera on window resize.
   ```bash
   npm create vite@latest sunday-driver -- --template vanilla-ts
   ```
   ```bash
   npm install three
   ```
2. **Make the render loop.** `requestAnimationFrame` for drawing, fixed 60 Hz step for physics. Add an fps counter (dev only).
3. **Build the shared props.** One geometry + flat-colour materials each for building box, sphere tree, street lamp, traffic light, boat, railing post. Use `InstancedMesh` wherever a prop repeats.
4. **Lay out Harbor Town.** Block grid inside an outer ring road; the bay along one long side with promenade, white railing, pier and boats; lighthouse on a sand spit. Colours from Reference A.
5. **Build the Hatchback.** Body + cabin boxes, 4 eight-sided wheels, mirrors, flat decals (Reference B). Body colour Coral `#F2674A`.
6. **Add driving.** Arcade model from Reference C, keyboard from Reference F (drive keys only for now).
7. **Add the outside camera.** Behind and above the car, damped follow, slightly wider swing in turns.
8. **Add collisions.** Car vs building boxes as 2D boxes: push out, keep 30 % of speed. No damage.
9. **Add fog and a speed readout.** `THREE.Fog` to hide the map edge; a plain temporary speed number on screen.

**Done when:** you can drive the whole ring road and back through town at 60 fps, without leaving the map or passing through buildings.

---

## Stage 2 — Weather and day / night

Goal: the city's mood changes with weather and time of day.

1. **Make the 4 weather presets** (Reference D) as plain data: sky, fog, light, tint, road colour, particles, grip.
2. **Blend between presets over 2.5 s** — lerp every colour and number; never snap.
3. **Add particles.** Rain = `LineSegments` streaks (~1,400); snow = drifting `Points` (~1,500), both in a 50 m box around the camera; a few flat cloud shapes for Cloudy and Sunny.
4. **Add weather looks on the ground.** Rain: darker road + puddle decals. Snow: white ground, roofs and road edges.
5. **Make weather affect driving.** Multiply grip and braking by the preset values.
6. **Add the day / night cycle** (Reference E). Sun and moon move; time tints sit on top of the weather colours.
7. **Turn lights on.** Window lights, street lamps, lighthouse lantern and car headlights switch on at dusk, or any time it rains or snows.
8. **Add the first real HUD.** City chip with clock (top left), weather switcher with keys 1–4 (top right), speed (bottom right). Styles from Reference G.

**Done when:** pressing 1–4 fades smoothly between weathers, the city goes from day to night in one cycle with lights coming on, and the car slides noticeably more in snow.

---

## Stage 3 — Driver view and sound

Goal: sit inside the car and hear the world.

1. **Build the cockpit** (Reference B, driver view): headliner, pillars, dashboard, short hood, steering wheel, dial, rear-view and left side mirrors. Parent it to the camera.
2. **Place the driver camera** in the left-hand seat so the road sits a little right of the wheel.
3. **Animate the cockpit.** The wheel turns with steering (up to ±90°); the dial shows speed.
4. **Add windshield weather.** Rain drops and streaks, snow flakes and frost band; twin wipers sweep in rain and snow.
5. **Add view switching.** Key C and the HUD View toggle; 0.5 s smooth camera move. The HUD speed hides in Driver view, and the other corner items move above the dashboard line.
6. **Add sound** (Reference H): engine that follows speed, rain and wind loops, horn on H. Muffle outside sounds a little in Driver view.
7. **Add the mini-map.** Round, top-down roads and water, coral player arrow.

**Done when:** you can drive a full lap in Driver view, switch views mid-turn without a jump, see wipers in rain, and hear the engine rise with speed and the rain fade in and out.

---

## Stage 4 — Menus, memory and polish

Goal: the full game flow, remembered between visits.

1. **Start screen.** Title **Sunday Driver**, slow orbit over Harbor Town. If a saved journey exists: **Continue journey** (primary, with a summary line such as *Harbor Town · Hatchback · Sunny · 18:40*) and **New journey** (secondary). Otherwise only **Start Driving**. Audio starts on this first click.
2. **Choose City.** 3 cards; Harbor Town playable, the other two marked *Coming soon*.
3. **Choose Vehicle.** Turntable, stat bars, 4 paint swatches, Outside / Driver preview toggle.
4. **Pause menu.** Resume, Change Vehicle, Change City, Driving view, Quality, **Clock (Running / Frozen)**, **Sound volume + mute**, Main Menu. Esc / P.
5. **Remember the journey** (Reference I). Save to `localStorage`; restore on Continue.
6. **Add city life.** 6 AI cars on looping paths, traffic lights cycling (they stop AI cars only).
7. **Add the quality toggle and fullscreen.** Low = no shadows, half particles, static mirrors, pixel ratio 1.
8. **Do a performance pass.** Check instancing, shared materials, fog distance; hold 60 fps on a mid-range laptop.

**Done when:** a new player goes Start → City → Vehicle → Drive → Pause → Main Menu without help, and closing and reopening the tab offers *Continue journey* that puts them back where they were, in the same car, weather and time.

**After launch:** Sports Car and SUV (launch minimum of 3 vehicles), then Metro Downtown and Mountain Village.

---

## Reference

### A. Harbor Town

| Name | Hex | Used for |
|---|---|---|
| White | `#F6F2EA` | Buildings, lighthouse |
| Sky blue | `#8ED1F2` / `#9DD0EA` | Sky, buildings |
| Sand | `#EBD8B0` / `#EBD9B3` | Buildings, promenade |
| Coral | `#F28B74` / `#E8604C` | Buildings, lighthouse bands, awnings |
| Deep blue | `#1E6FB4` (+ `#4B98D8` shimmer) | Water |
| Road | `#7B818C`, curbs `#C8C2B8`, lines `#F4F1E8` | |

Buildings 2–4 storeys (≈ 3 m each), windows as flat darker quads, shop band with a coral or blue awning strip. Water is one plane with a slow colour shift; boats bob ±3 cm over 4 s.

### B. Hatchback

| Part | Shape | Size (m) |
|---|---|---|
| Body | Box, tapered nose | L 3.95 × W 1.72, from 0.26 to 1.00 high |
| Cabin | Box, sloped windshield and hatch | Roof at 1.66 |
| Wheels ×4 | 8-sided cylinder | r 0.33, w 0.22, axles at ±1.28 |
| Decals | Flat quads | Glass `#2C3B4E`, headlights `#FFF3C4`, tail `#D9343A`, plate `#F4F1E8` |

≈ 220 triangles. Paints: Coral `#F2674A`, Sun `#FFC845`, Mint `#2FB59A`, Cloud `#F4F4F0`.

**Outside camera:** offset ≈ (0, 2.1, −5.5), looking 3 m ahead of the car.
**Driver camera:** (−0.36, 1.18, 0.15) from car centre. Interior colours: headliner `#363C46`, pillars `#2A2F37`, dashboard `#2D323B`, wheel `#1B1E23` with coral hub dot.

### C. Arcade driving (Hatchback)

```
speedMax    120 km/h          accel     6 m/s²
brake       12 m/s² × grip    reverse   25 km/h max
steerMax    32° at rest → 10° at top speed
lateralGrip 8 × weather grip  handbrake rear grip × 0.3
```

### D. Weather presets

| | Sunny | Cloudy | Rainy | Snowy |
|---|---|---|---|---|
| Sky | `#8ED1F2` | `#C5CDD6` | `#5A6777` | `#D8DFE6` |
| Fog colour | `#DCEFF8` | `#D9DEE4` | `#7C8896` | `#E9EEF2` |
| Fog far | 220 m | 170 m | 120 m | 90 m |
| Light | warm, sharp shadow | soft, no shadow | dim, cool | soft, cool |
| Material tint | none | `#9AA3AE` 22 % | `#4C5866` 40 % | `#D6DEE6` 24 % |
| Road | `#7B818C` | `#737983` | `#444A54` + puddles | `#8A9099`, white edges |
| Particles | 3 clouds | 9 clouds | ~1,400 streaks | ~1,500 flakes |
| Grip × | 1.00 | 1.00 | 0.70 | 0.45 |
| Braking distance × | 1.0 | 1.0 | 1.4 | 1.8 |

### E. Day / night cycle

- One full day = **20 real minutes**: dawn 2 min, day 12 min, dusk 2 min, night 4 min.
- A **New journey** starts at 10:00. Clock shown as `HH:MM` in the city chip.
- Pause menu can freeze the clock.

| Phase | Time | Tint over weather colours | Light |
|---|---|---|---|
| Dawn | 06:00–07:30 | `#F6B38E` at 35 % | low warm sun |
| Day | 07:30–18:00 | none | sun as per weather |
| Dusk | 18:00–19:30 | `#F28B74` at 40 % | low orange sun, lights on |
| Night | 19:30–06:00 | `#141C33` at 75 % | weak cool moon, lights on |

Lights on = window glow `#FFD98A`, lamps `#FFF1BF`, lighthouse lantern, one SpotLight for the player's headlights, emissive headlights on AI cars.

### F. Controls

| Action | Key |
|---|---|
| Accelerate / Brake, reverse | W ↑ / S ↓ |
| Steer | A D / ← → |
| Handbrake | Space |
| Horn | H |
| Switch view | C |
| Weather | 1 – 4 |
| Mute | M |
| Fullscreen | F |
| Pause | Esc / P |

### G. UI tokens

```css
:root{
  --ink:#13203A;  --glass:rgba(15,24,43,.78);
  --coral:#FF6A4D; --coral-edge:#C7472E; --sun:#FFC845;
  --mist:#EEF3F7; --slate:#55627A; --haze:#B9C4D6;
  --font-display:'Fredoka',sans-serif;
  --font-body:'DM Sans',system-ui,sans-serif;
  --r-chip:18px; --r-card:28px; --r-pill:999px;
}
```

HUD: 32 px inset, every chip on `--glass` with a 1 px `rgba(255,255,255,.14)` border. Text on coral is always `--ink`. Fonts: Fredoka 600/700 for titles, buttons and the speed number; DM Sans for everything else.

### H. Sound

| Sound | How | Behaviour |
|---|---|---|
| Engine | Synthesised: sawtooth + sub square through a low-pass (no sample files) | Pitch 0.8 → 1.8 with speed; dips at 5 gear-like steps |
| Rain | Looped white noise, high-passed; extra band-passed "roof" layer | Fades with the weather blend; roof layer only in Driver view |
| Wind | Looped white noise, low-passed | Rises with speed; stronger in snow |
| Horn | Two square tones (G4 + B4) | Plays while H is held |

Web Audio API, one master gain (Pause volume + M mute). Driver view: low-pass ~1.2 kHz on wind and rain. Start audio only after the player's first click.

### I. Journey memory

```ts
// localStorage key: "sundayDriver.journey.v1"
{
  city: "harbor", vehicle: "hatchback", color: "#F2674A",
  view: "outside", weather: "sunny", clock: "18:40", clockFrozen: false,
  quality: "high", volume: 0.8, muted: false,
  pos: { x: 0, z: 0, heading: 0 }, savedAt: "2026-11-11T18:40:00Z"
}
```

- Save on pause, on every menu change, every 10 s while driving, and on page hide.
- Wrap every read and write in `try/catch`; if storage is empty or blocked, just show **Start Driving**.
- **New journey** clears the save and starts at 10:00, Sunny, at the city's default spawn.
