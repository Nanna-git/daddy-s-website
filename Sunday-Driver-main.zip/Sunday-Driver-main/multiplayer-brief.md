# Multiplayer — Brief

Status: **built (steps 2–5 of §8) plus player collisions, damage and repair pads; tested with a fake Realtime backend and headless-browser checks only.** Not yet tried against real Supabase Realtime or a phone.

## 1. Summary

Add a shared free-roam to Sunday Driver. Signed-in players in the same city see each other's real cars driving live, with name tags so they can tell who is who. No modes, no scores, no rooms. A player driving alone sees the game exactly as it is today.

## 2. Decisions

| Topic | Decision |
|---|---|
| Shape | Shared free-roam only. No races, objectives or modes |
| World | One shared public world per existing city (Harbor Town, Metro Downtown, Mountain Village). No rooms, join codes, invites or kick button |
| Default | **On by default.** "Show other drivers" toggle in Pause, saved per device in `localStorage`. Off = nothing sent or received |
| Alone | Looks and plays exactly as today (no empty-state UI, no errors) |
| Sign-in | Required. No guest mode. Uses the existing email-only account, display name and avatar |
| Identity trust | Accepted as-is for this development project: anyone knowing an email can enter as it, names are free text and not unique |
| Cap | 12 players per instance. A full city overflows into "Harbor Town 2", "…3" and so on, automatically |
| Remote cars | Their real vehicle model and paint (no cockpit interior) |
| Collisions | **Yes (added after v1).** Cars bump into each other, mass-aware (hatchback 1200, sports 1400, SUV 2000, bus 9000, bike 250). Peer-side: each client moves only its own car against interpolated remote cars, so a hit can feel slightly late. Cars on different levels (> 3 m, Metro's highway) never touch. Pairs that spawn, reappear or teleport inside each other ignore each other until they have been apart once. Only cars that sent something in the last ~1 s collide; silent, fading and paused cars never do |
| Collide toggle | Pause → "Collide with other drivers", on by default, saved per device (`prefs.collide`). Off = you pass through everyone and nobody collides with you (the flag `c` is broadcast; contact needs both sides on). Building and traffic damage still apply |
| Damage | One 0–100 % meter per car from closing speed along the hit normal × (other mass ÷ yours, clamped ½–2); hits under 10 km/h do nothing; one hit is capped at 70 %. Applies to buildings, poles, trees, traffic and players. Per driving session only: not saved, reset on a new session or city change |
| Damage effects | Paint darkens, smoke above 60 % (nearest 4 damaged remote cars only), mild penalty to 70 % top speed/acceleration plus a gentle pull to one side at 100 %. The car never stops. Damage is broadcast (`d`) so everyone sees it |
| Repair | 2–3 free repair pads per city (ring + canopy, green dot on the mini-map, ground level only). Stop on one for 5 s from 100 % (20 %/s). No Pause repair button |
| Crash feedback | Thud, camera jolt and sparks scaled by impact speed, played by each client for its own collision |
| Shared state | Only cars, name tags and reactions. Time of day, weather and traffic stay local to each player |
| Chat | **Yes (added after v1, see §11).** Typed text plus 6 quick phrases, instance-wide, live only. No horn sound for others. Quick reactions stay (§7) |
| Offline | Strictly additive. If Supabase is unreachable or `config.js` has placeholders, the game stays single-player with no error. Auto-reconnect with the same identity |
| Persistence | Nothing stored in the database. Everything is live |

## 3. Identifying each other

- **Name tag** floating above each remote car: avatar emoji + display name. Fades with distance, hidden beyond ~150 m.
- **Minimap dot** per remote player, in their avatar colour.
- **Player list** in the Pause menu: emoji, name, vehicle, and the instance's count (e.g. 5 / 12).
- **Duplicate names** in one instance: the later joiner automatically becomes "Sam #2" (the tag and list use the suffixed name; the saved profile name is unchanged).
- Never shown to others: email, user ID.

## 4. Privacy

Everyone in your city instance sees your display name, avatar, vehicle, paint and live position. Position is broadcast **only while you are in a driving session in that city**, not on menus or while paused. Accepted tradeoff of having no private rooms.

## 5. Technical approach

- **Transport:** Supabase Realtime **Broadcast** (state) + **Presence** (who is here), one channel per city instance. No new server, stays on the free tier.
- **Payload at ~5 Hz:** position (x, z), heading, speed, vehicle id, paint, plus identity from Presence. Clients **interpolate** between updates; a remote car silent for **5 s** fades out and is removed.
- **Instances:** join `harbor-1`; if Presence shows 12, try `harbor-2`, and so on. Leaving a city (or changing vehicle) leaves the channel and rejoins as needed.
- **Auth fit:** the app uses the anon key and database functions rather than Supabase Auth, so channels are public and identity is client-claimed. This matches the accepted trust decision above.
- **Free-tier limits to check:** ~200 concurrent connections and a messages-per-second ceiling. 12 players × 5 Hz per instance is well inside it for now.
- **Rendering:** reuse `buildVehicle` and the vehicle specs for remote cars; keep them cheap on phones (no shadows beyond the blob, tags as sprites, cap on drawn remote cars if needed).
- **Likely new code:** `src/multiplayer.js` (channel, presence, send/receive, instance picker), `src/remoteCars.js` (spawn, interpolate, tags, fade), hooks in `main.js`, `minimap.js`, `menus.js` (player list + toggle), `save.js`/prefs (toggle).

## 6. Out of scope for v1

Server-side chat moderation, chat history storage, horn for others, shared weather/time/traffic, private rooms, friends lists, guests, moderation tools, saving anything about other players.

## 7. Quick reactions (confirmed)

- A small fixed set, e.g. 👋 😀 👍 ❤️ (4 reactions).
- Desktop: keys **5–8** (1–4 already switch the weather), or the 😀 button next to Pause. Touch: a small reaction button that opens the four choices.
- Shown as an emoji that floats above your car for ~3 s, visible to nearby players (same ~150 m range as the name tag).
- Cooldown ~2 s per player to prevent spam.
- Sent as a tiny Broadcast event; ignored entirely when the toggle is off.

## 8. Build order (suggested)

1. Create the Supabase project and finish the auth plan first (multiplayer reuses profiles; see `auth-plan.md`).
2. Prefs toggle + `multiplayer.js` channel/presence with instance picker (no visuals; log players).
3. `remoteCars.js`: spawn, interpolate, fade, name tags.
4. Minimap dots and Pause player list.
5. Reactions.
6. Test with two browsers, then a phone; test dropped connection and the toggle off.

## 9. Open items

- Not yet tested on the real Supabase Realtime service (needs Realtime enabled on the project) or a real phone.
- Confirm the 150 m tag/reaction range and 5 s silence timeout feel right once built.

## 10. Collisions, damage and repair (added later)

- Code: `src/carCollision.js` (box-vs-box, mass-aware, pure), `src/damage.js` (damage/repair maths, pure), `src/damageFx.js` (smoke, sparks), `src/repair.js` (pads), hooks in `main.js`, `remoteCars.js`, `collision.js` (returns the hit speed), `carPhysics.js` (penalty), `hud.js`/`minimap.js`, `audio.js` (`thud`), `camera.js` (`shake`).
- Payload adds `d` (damage %) and `c` (1 = collides with others). Tests: `node tests/multiplayer.test.mjs`.
- Known tradeoffs: peer-side hits are not identical on both screens; a car parked on a pad can block it; hits can feel late by up to ~200 ms.
- Not yet tried against real Realtime or a phone. Damage numbers (2 % per m/s above the dead zone) and the pad positions need a play-test.

## 11. Chat (added later)

- **Who sees it:** everyone in your city instance (up to 12). Live only: nothing stored in the database; each client keeps the last 50 messages in memory and clears them on a city or instance change. A dropped connection that returns to the same instance keeps the history (messages sent during the gap are lost).
- **Typed text:** up to 140 characters, plain text only, one message per ~1.5 s. **Enter** opens the input (desktop), the 💬 button opens it on touch. Driving and hotkeys are suspended while typing; the car keeps rolling. Enter sends, Esc closes.
- **Quick phrases:** 6 chips (Nice car!, Follow me, Race you?, Sorry!, Thanks!, Good drive) send a phrase ID and also show a ~3 s bubble over the sender's car (same ~150 m range as tags). Typed text appears only in the log. The 4 emoji reactions are unchanged.
- **Log:** bottom-left, last 5 lines, each fades after ~8 s; opening chat shows the full history. A dot on 💬 marks unread messages. No sound.
- **Wire format:** Broadcast event `c` on the existing channel, `{id, t}` or `{id, q}`. The payload carries no name: names come from Presence (with the "Sam #2" suffix), so a message cannot spoof one.
- **Safeguards (client-side only):** rate limit, length cap, a basic word filter on receive (masks words with `*`), per-session **Mute** buttons in the Pause player list (not saved), messages rendered with `textContent`.
- **Toggle:** Pause → "Chat" On/Off, on by default, saved per device (`prefs.chat`). Off = nothing sent or received, cars still shown. "Other drivers" off also means no chat.
- **Paused:** the channel stays joined while paused, but the Pause menu's Chat section is read-only (history only, no sending).
- **Code:** `src/chatCore.js` (pure helpers, unit-tested), `src/chat.js` (UI), hooks in `multiplayer.js`, `remoteCars.js`, `main.js`, `menus.js`, `index.html`, CSS.
- **Tested:** unit tests and a headless-browser run with a fake Realtime backend; not yet against real Supabase or a phone.
