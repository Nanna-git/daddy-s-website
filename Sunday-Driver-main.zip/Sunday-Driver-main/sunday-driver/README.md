# Sunday Driver

*No rush. Nowhere to be.* A chill, free-roam driving toy: three cities (Harbor Town, Metro Downtown, Mountain Village), all five vehicles (Hatchback, Sports Car, SUV, City Bus, Motorbike), four weathers and a full day and night. All 4 stages of [../city-drive-build.md](../city-drive-build.md) are built.

## Run

No install needed: plain ES modules, Three.js 0.170 loads from jsDelivr (needs internet).

```bash
cd sunday-driver && python3 serve.py
```

Open http://127.0.0.1:5173. (`serve.py` is Python's built-in server with caching switched off, so a reload always picks up edited files.)

Dev URL options: `?time=19:00` · `?weather=rainy` · `?fps` (fps is always on for localhost).

## Deploy

Live at https://sunday-driver-eta.vercel.app. The Vercel project is connected to the GitHub repository `sumayya123F/Sunday-Driver` with **Root Directory = `sunday-driver`** (the repo also holds the briefing and build guide) and no build step.

- **Push to `main`** → Vercel deploys it to production automatically.
- **Push any other branch** → nothing happens on Vercel (`vercel.json` turns deploys off for every branch except `main`). A branch picks this up once it contains `vercel.json`, e.g. after merging `main` into it.
- Don't run `vercel deploy` from this folder any more: with the root directory set, deploys come from GitHub.

## Accounts (Supabase)

Players enter with **just their email**: no link, no code, no password, no Supabase Auth, no email sent; every address counts as verified. A database function (`enter_app`) turns the email into a `user_id` (known emails keep their old one), and the app reads and writes through database functions only. Entry never depends on the database: if it can't be reached the player continues locally and everything syncs when it answers. Anyone who knows an address can enter as it; fine for this development project, not for real data. A new email creates the account. First sign-in asks for a display name and one of 12 preset avatars. Everything is stored in a free Supabase project: `profiles`, `journeys` (one saved journey per user, synced every 30 s and on pause/leave/close, with `localStorage` as an offline cache) and `sessions` (login/logout log, written through three functions; users can't read it).

**Setup (free, once):**
1. Create a project at supabase.com (no card needed).
2. SQL Editor → paste `supabase/schema.sql` → Run.
3. SQL Editor → paste `supabase/email-auth.sql` → Run (after step 2). It drops the link to Supabase Auth, adds the functions and closes direct table access; existing rows are kept.
4. Nothing to change under Authentication; the app doesn't use it.
5. Put the Project URL and anon key (Settings → API) in `src/config.js`. Both are public by design; never use the service_role key.

**Login history:** Table editor → view `sessions_history` (email, `login_at`, `logout_at`, status `manual` / `tab_closed` / `timeout` / `active`). The page pings every 30 s; no ping for 2 minutes counts as ended at the last ping.

## Multiplayer

Signed-in players in the same city see each other as ghost cars (no collisions) with a name tag, a mini-map dot and a Pause-menu player list. See [../multiplayer-brief.md](../multiplayer-brief.md). It uses **Supabase Realtime** Broadcast + Presence (one channel per city copy, 12 players each, ~5 updates a second); nothing is stored. Realtime must be enabled on the project (it is by default). On by default; **Pause → Other drivers** turns it off per device. Reactions: keys **5–8** or the 😀 button. If Realtime can't be reached the game is simply single-player.

Tests: `node tests/multiplayer.test.mjs` (pure helpers).

## Flow

Sign in → Start → Choose City → Choose Vehicle (Outside / Driver preview) → Drive ⇄ Pause.

- **Start:** slow orbit over Harbor Town. With a saved journey: **Continue journey** (shows city · vehicle · weather · time) and **New journey**; otherwise **Start Driving**.
- **Choose City:** Harbor Town, Metro Downtown or Mountain Village (chalets on a hillside above a river, stone bridges, pine forest, a church clock tower that shows the game time; the only city with slopes). Each city is built the first time you pick it and kept for quick switching.
- **Choose Vehicle:** turntable, stat bars, 4 paints, Outside / Driver preview (you start in the view you pick). All five vehicles are drivable; the bus is shown smaller and the bike larger so each fits the disc.
- **Pause** (Esc / P / the HUD button): Resume, Change Vehicle, Change City, Driving view, Quality, Clock (Running / Frozen), Sound volume + mute, Main Menu.

## Controls

| Key | Action |
|---|---|
| W / ↑ | Accelerate |
| S / ↓ | Brake, then reverse |
| A D / ← → | Steer |
| Space | Handbrake |
| C | Outside ⇄ Driver view |
| H | Horn (hold) |
| 1 – 4 | Sunny · Cloudy · Rainy · Snowy |
| M | Mute |
| F | Fullscreen |
| Esc / P | Pause / resume |

## Cities

| | Harbor Town | Metro Downtown | Mountain Village |
|---|---|---|---|
| Layout | 6 × 6 blocks in a ring road, 12 m roads, bay + promenade on the west | same 6 × 6 grid, 16 m avenues with double yellow lines and zebra crossings at every junction | same grid, 10 m village roads with a dashed centre line, on a hill: level along the river, climbing 16 m to the north edge and 5 m to the south |
| Buildings | 2–4 storey pastel blocks with shop awnings | towers built as 2–3 stacked boxes, taller towards the middle; glass floor bands; rooftop units | chalets on stone plinths: plaster ground floor, timber upper floor, red gable roofs, chimneys |
| Landmark | lighthouse on a sand spit (rotating beam at night) | Meridian Tower, ~180 m, stepped, with a spire and a blinking red beacon | church with a clock tower on the cobbled square; the four clock faces show the game time |
| Extras | pier, boats, promenade trees | central park with a pond, elevated highway loop above the ±160 roads (drivable, see below), neon strips on podiums at night, hazy skyline beyond the edge | river across the middle with a stone bridge on every road (the main-street one is covered), fountain, pine forest up the slopes, snowy peaks on the horizon, timber town fence |
| Traffic | 6 AI hatchbacks | 3 yellow taxis + 3 cars | 6 cars; traffic lights only at the 9 junctions in the middle of the village |
| Night | lit windows, lamps, lighthouse | lit floor bands, lamps, pink/cyan/amber neon, beacon | lit chalet windows, glowing church windows, lantern posts |

**Metro's highway is drivable.** Four on-ramps (one per side, in the blocks just outside the loop, rising 9 m over 52 m) lead up to the deck. At the top, the deck's outer parapet is open for 32 m: steer towards the deck to merge, and do the same the other way to leave. Deck and road are different levels on the same footprint: the pillars only stop cars on the road, the parapets and the parked cars only stop cars on the deck, and the AI traffic underneath ignores you up there. The mini-map shows the loop in orange with a stub for each ramp. The ramps replace the building lot beside them and one lamp or traffic light each; the roads themselves are unchanged.

Mountain Village has hills (and Metro has its ramps): `heightAt(x, z)` in `mountain.js` (and `metro.js`, which also takes the car's current height) gives the ground under every road, and the player's car, the AI cars and the follow camera ride it, tilting with the slope. Steering and speed are the same as on flat ground. The river and the town fence are walls; the bridges are the way across.

## Vehicles

Cars and the bus share one builder (`src/vehicles/hatchback.js` → `buildVehicle`); the motorbike has its own (`src/vehicles/motorbike.js`). Everything that differs lives in `src/vehicles/specs.js`: shape, wheels, extras, handling, engine/horn sound, driver seat and outside-camera distance.

| | Hatchback | Sports Car | SUV / Jeep | City Bus | Motorbike |
|---|---|---|---|---|---|
| Look | balanced two-box | low, long bonnet, rear wing | tall, roof rails, spare wheel | 10 m long, window row, 2 kerb-side doors, destination sign | inline wheels, rider, round headlight |
| Driver view | normal seat, short hood | low seat, long hood | high seat, upright glass | very high seat, huge windshield, big flat wheel | handlebars, 2 round mirrors, small display; no glass or wipers; view tilts gently into turns |
| 0–100 km/h | 10.0 s | 5.0 s | 11.9 s | — (0–60 in 11 s) | — (0–60 in 2.9 s) |
| Top speed | 119 km/h | 163 km/h | 117 km/h | 78 km/h | 140 km/h |
| Turning circle at 15 km/h | 9.2 m | — | — | 17.6 m | 4.8 m |
| Slide at speed · sunny / snowy | 5° / 11° | 6° / 18° | 4° / 6° | 3° / 5° | 5° / 11° |
| Engine / horn | mid hum | high rasp | low rumble | deep, short gears | high, revvy |

The motorbike leans up to ~31° into turns (outside view); from the rider's seat the horizon tilts by about half that, to stay comfortable.

## Phones and tablets

Touch screens get their own layout (`src/touch.js`, `src/phone.css`):

- **Controls:** ◀ ▶ steering bottom left; Brake and a big Gas pedal bottom right, horn above them. Each button follows its own finger, so you can steer and accelerate together.
- **HUD:** city chip top left; weather, fullscreen, speed, view toggle and pause along the top right; the mini-map is hidden to leave the corner to the steering arrows.
- **Landscape only:** holding the phone upright shows *Turn your phone sideways*.
- **Menus fit without scrolling** on a landscape phone (checked at 740 × 360): smaller cards, a tighter vehicle panel and a two-column Pause menu.
- **Quality starts on Low** on touch devices (no shadows, half the particles, pixel ratio 1); change it in Pause.
- No page scrolling, pull-to-refresh or pinch zoom while playing.

## Journey memory

Saved to `localStorage` (`sundayDriver.journey.v1`): city, vehicle, paint, view, weather, time, clock frozen, position and heading. Saved on pause, on leaving a drive, every 10 s while driving, and when the tab is hidden or closed. Quality, volume and mute are kept separately (`sundayDriver.prefs.v1`) so they survive *New journey*. If storage is blocked, the game simply starts fresh.

## City life

6 AI hatchbacks loop the streets in the right-hand lane at 36–46 km/h. Traffic lights at the 25 inner junctions run a 20 s cycle (8 s green, 2 s amber per direction). AI cars stop for red, for each other and for you; you are not stopped. You bump off them like any other obstacle.

## Measured (scripted checks, this Mac)

| Check | Result |
|---|---|
| Frame rate — High, Low, rainy driver view | 60 fps (display cap) · ~163 draw calls · ~96k triangles |
| Journey restore after reload | same position, heading, paint, weather and time |
| AI cars at junctions, 3 min | 76 crossings: 0 stuck, 3 through just-turned red after committing on amber |
| AI car with you parked 20 m ahead | stops 6 m behind you |

## Files

```
index.html                   canvas, HUD + menu markup, import map
src/main.js                  game flow (screens), fixed 60 Hz loop, autosave
src/menus.js / menus.css     Start, City, Vehicle, Pause screens
src/save.js                  journey (per user) + prefs in localStorage
src/auth.js / config.js      Supabase database functions: email-only entry, profile, login log, journey sync
supabase/schema.sql          tables, security rules, history view
src/traffic.js               6 AI cars, signals, stopping
src/turntable.js             Choose Vehicle stage
src/hud.js / minimap.js      in-game HUD
src/audio.js                 engine, rain, wind, horn (Web Audio, synthesised)
src/camera.js                outside follow camera + driver seat, 0.5 s switch
src/input.js                 keyboard
src/collision.js             car vs buildings, walls, poles, trees, AI cars
src/scene/*                  world, Harbor Town (harbor.js), Metro Downtown (metro.js), Mountain Village (mountain.js), weather, day/night, particles, clouds, props
src/vehicles/*               specs (all vehicle numbers), model builder, cockpit, windshield, physics
```

## Notes

- Built without a bundler because this Mac has no Node yet. Moving to Vite + TypeScript later = rename `.js` → `.ts` and `npm install three`.
- Low quality: no shadows, half the rain/snow particles, mirrors refresh once a second, pixel ratio 1.
- In menus the focused button takes Space / Enter, so pressing Space on Choose Vehicle starts the drive.
- `window.__sd` exposes the game for console checks: `simulate(seconds, keys)`, `tick(seconds)`, `go('pause')`, `setView('driver')`, `atmosphere.clock.set('22:00')`.
