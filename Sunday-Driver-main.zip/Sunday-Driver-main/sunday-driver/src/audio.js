// Sound (Reference H): engine, rain, wind, horn — all synthesised with Web Audio, no files. No music.
// Browsers only let sound start inside a real tap/click/key press. On phones that is the finger *lifting*
// (pointerup / touchend / click), not pointerdown — so we listen for all of them and keep trying until it runs.


export function createAudio() {
  let ctx = null, n = null, muted = false, volume = 0.8, paused = true;
  // per-vehicle engine + horn (specs.js audio); gears are km/h where each gear tops out
  let profile = { base: 48, gears: [0, 22, 42, 66, 92, 125], horn: [392, 494] };

  function noiseBuffer(seconds = 2) {
    const b = ctx.createBuffer(1, ctx.sampleRate * seconds, ctx.sampleRate);
    const d = b.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return b;
  }
  function loopNoise() {
    const s = ctx.createBufferSource();
    s.buffer = n.noise; s.loop = true; s.start();
    return s;
  }

  function build() {
    n = {};
    n.master = ctx.createGain();
    n.master.gain.value = muted ? 0 : volume;
    // pause silences this gain instead of suspending the context (phones may refuse to resume later)
    n.pauseGain = ctx.createGain();
    n.pauseGain.gain.value = paused ? 0 : 1;
    n.master.connect(n.pauseGain).connect(ctx.destination);
    n.noise = noiseBuffer();

    // outside sounds go through a low-pass that closes when you sit inside the car
    n.outside = ctx.createBiquadFilter();
    n.outside.type = 'lowpass'; n.outside.frequency.value = 18000;
    n.outside.connect(n.master);

    // engine: saw + sub square → low-pass
    n.engFilter = ctx.createBiquadFilter();
    n.engFilter.type = 'lowpass'; n.engFilter.frequency.value = 700; n.engFilter.Q.value = 1.2;
    n.engGain = ctx.createGain(); n.engGain.gain.value = 0;
    n.engFilter.connect(n.engGain).connect(n.master);
    n.osc1 = ctx.createOscillator(); n.osc1.type = 'sawtooth';
    n.osc2 = ctx.createOscillator(); n.osc2.type = 'square';
    const o2 = ctx.createGain(); o2.gain.value = 0.5;
    n.osc1.connect(n.engFilter); n.osc2.connect(o2).connect(n.engFilter);
    n.osc1.start(); n.osc2.start();

    // rain: bright hiss; roof drum only inside the car
    const rainHp = ctx.createBiquadFilter(); rainHp.type = 'highpass'; rainHp.frequency.value = 900;
    n.rainGain = ctx.createGain(); n.rainGain.gain.value = 0;
    loopNoise().connect(rainHp).connect(n.rainGain).connect(n.outside);
    const roofBp = ctx.createBiquadFilter(); roofBp.type = 'bandpass'; roofBp.frequency.value = 420; roofBp.Q.value = 0.8;
    n.roofGain = ctx.createGain(); n.roofGain.gain.value = 0;
    loopNoise().connect(roofBp).connect(n.roofGain).connect(n.master);

    // wind: low rumble that rises with speed
    n.windLp = ctx.createBiquadFilter(); n.windLp.type = 'lowpass'; n.windLp.frequency.value = 400;
    n.windGain = ctx.createGain(); n.windGain.gain.value = 0;
    loopNoise().connect(n.windLp).connect(n.windGain).connect(n.outside);

    // horn: two friendly square tones
    n.hornGain = ctx.createGain(); n.hornGain.gain.value = 0;
    const hornLp = ctx.createBiquadFilter(); hornLp.type = 'lowpass'; hornLp.frequency.value = 1800;
    hornLp.connect(n.hornGain).connect(n.master);
    n.horns = profile.horn.map(f => { const o = ctx.createOscillator(); o.type = 'square'; o.frequency.value = f; o.connect(hornLp); o.start(); return o; });
  }

  const set = (param, v, tc = 0.08) => param.setTargetAtTime(v, ctx.currentTime, tc);

  return {
    get started() { return !!ctx; },
    get muted() { return muted; },
    get state() { return ctx ? ctx.state : 'none'; },
    /** Create / wake the audio. Must be called from inside a user gesture. */
    start() {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      if (!ctx) {
        // iPhone: play through the ring/silent switch like a game, not like a notification
        try { if (navigator.audioSession) navigator.audioSession.type = 'playback'; } catch { /* older Safari */ }
        ctx = new AC();
        build();
      }
      if (ctx.state !== 'running') {
        ctx.resume().catch(() => {});
        // iOS only unlocks once a sound actually starts inside the gesture: play one silent sample
        const b = ctx.createBuffer(1, 1, 22050), src = ctx.createBufferSource();
        src.buffer = b; src.connect(ctx.destination); src.start(0);
      }
    },
    /** Listen for every kind of user gesture (and coming back to the tab) to start or wake the audio. */
    attachUnlock() {
      const wake = () => { if (!ctx || ctx.state !== 'running') this.start(); };
      for (const ev of ['pointerup', 'touchend', 'click', 'keydown']) addEventListener(ev, wake, { capture: true, passive: true });
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible' && ctx && ctx.state !== 'running') ctx.resume().catch(() => {});
      });
    },
    /** Switch engine pitch, gears and horn to another vehicle. */
    setProfile(p) {
      profile = { ...profile, ...p };
      if (ctx) n.horns.forEach((o, i) => o.frequency.setValueAtTime(profile.horn[i] || profile.horn[0], ctx.currentTime));
    },
    get volume() { return volume; },
    setVolume(v) {
      volume = Math.max(0, Math.min(1, v));
      if (ctx && !muted) set(n.master.gain, volume, 0.05);
    },
    setMuted(m) {
      muted = !!m;
      if (ctx) set(n.master.gain, muted ? 0 : volume, 0.05);
    },
    /** Silence the game while paused / in menus (the context keeps running, so it never needs re-unlocking). */
    pause(on) {
      paused = !!on;
      if (ctx) set(n.pauseGain.gain, paused ? 0 : 1, 0.05);
    },
    toggleMute() {
      muted = !muted;
      if (ctx) set(n.master.gain, muted ? 0 : volume, 0.05);
      return muted;
    },
    /** A crash: low thump plus a burst of crunch. strength 0…1 (scaled by impact speed) */
    thud(strength = 0.5) {
      if (!ctx) return;
      const k = Math.max(0.1, Math.min(1, strength)), t = ctx.currentTime;
      const o = ctx.createOscillator(), og = ctx.createGain();
      o.type = 'sine'; o.frequency.setValueAtTime(150, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.3);
      og.gain.setValueAtTime(0.55 * k, t); og.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
      o.connect(og).connect(n.master); o.start(t); o.stop(t + 0.4);
      const src = ctx.createBufferSource(), bp = ctx.createBiquadFilter(), ng = ctx.createGain();
      src.buffer = n.noise; bp.type = 'bandpass'; bp.frequency.value = 500 + 1500 * k; bp.Q.value = 0.7;
      ng.gain.setValueAtTime(0.4 * k, t); ng.gain.exponentialRampToValueAtTime(0.001, t + 0.12 + 0.2 * k);
      src.connect(bp).connect(ng).connect(n.master); src.start(t, Math.random()); src.stop(t + 0.4);
    },
    horn(on) {
      if (!ctx) return;
      set(n.hornGain.gain, on ? 0.16 : 0, on ? 0.01 : 0.04);
    },
    /** s: { kmh, throttle 0..1, rain 0..1, snow 0..1, inside 0..1 } */
    update(s) {
      if (!ctx) return;
      // gear-like steps: rpm climbs within each gear, drops when the next one starts
      const GEARS = profile.gears;
      const v = Math.min(s.kmh, GEARS[GEARS.length - 1] - 0.1);
      let g = 0;
      while (g < GEARS.length - 2 && v >= GEARS[g + 1]) g++;
      const r = (v - GEARS[g]) / (GEARS[g + 1] - GEARS[g]);
      const rpm = (g === 0 ? 0.2 : 0.38) + r * 0.62;   // 0.2 idle … 1.0 redline
      const pitch = 0.8 + rpm;                          // 0.8 → 1.8
      set(n.osc1.frequency, profile.base * pitch, 0.05);
      set(n.osc2.frequency, profile.base * 0.5 * pitch, 0.05);
      set(n.engFilter.frequency, 500 + 900 * s.throttle + 500 * rpm, 0.1);
      set(n.engGain.gain, 0.07 + 0.07 * s.throttle + 0.03 * rpm);

      const speedK = Math.min(1, s.kmh / 120);
      set(n.rainGain.gain, 0.22 * s.rain, 0.3);
      set(n.roofGain.gain, 0.28 * s.rain * s.inside, 0.3);
      set(n.windGain.gain, Math.min(0.4, 0.32 * speedK * speedK + 0.1 * s.snow + 0.02 * speedK), 0.25);
      set(n.windLp.frequency, 300 + 600 * speedK, 0.25);
      set(n.outside.frequency, s.inside > 0.5 ? 1200 : 18000, 0.15);
    },
  };
}
