// Email-only accounts. No Supabase Auth: typing an email is enough and every address counts as verified.
// The database function enter_app(email) returns the user_id (reusing the old one for known emails); every other
// call is a database function that takes that user_id. Entry never depends on the database: if it can't be reached
// the player continues locally and everything catches up the next time it answers.
import { SUPABASE_URL, SUPABASE_ANON_KEY, CONFIGURED } from './config.js';

const PING_MS = 30_000;          // "still here" heartbeat
const JOURNEY_SYNC_MS = 30_000;  // at most one journey upload per 30 s (unless forced)
const USER_KEY = 'sd-user';      // the email of whoever is signed in on this browser
const PROFILE_KEY = 'sd-profile'; // local copy of the profile, per email

export const AVATARS = [
  ['🚗', '#F2674A'], ['🏎️', '#E8604C'], ['🚙', '#2FB59A'], ['🚌', '#FFC845'], ['🏍️', '#3A8BD0'], ['🚕', '#F0B429'],
  ['🚓', '#5B6EE1'], ['🚑', '#E5484D'], ['🛻', '#7A8F9E'], ['🚐', '#9B6BD3'], ['🛵', '#E6739F'], ['🚲', '#4F9A58'],
].map(([emoji, color], i) => ({ id: `car-${i + 1}`, emoji, color }));
export const avatarById = id => AVATARS.find(a => a.id === id) || AVATARS[0];

let user = null;       // { id: email, email }: id is the email so the local save key stays stable
let uid = null;        // database user_id, once enter_app has answered
let cloudProfile = null;
let sessionId = null, sessionEnded = false;
let pingTimer = 0, lastJourneyPush = 0, journeyDirty = false, lastUpgrade = 0;
const listeners = new Set();
export const onAuthChange = fn => { listeners.add(fn); return () => listeners.delete(fn); };
const emit = () => listeners.forEach(fn => fn(user));

export const configured = CONFIGURED;
export const currentUser = () => user;

const norm = email => email.trim().toLowerCase();

// ---------- database functions over plain fetch ----------
// keepalive lets the request finish while the tab is closing.
async function rpc(name, body, { keepalive = false, timeout = 8000 } = {}) {
  if (!CONFIGURED) return { error: 'not-configured' };
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${name}`, {
      method: 'POST', keepalive,
      headers: { apikey: SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: keepalive ? undefined : AbortSignal.timeout(timeout),
    });
    const text = await res.text();
    const data = text ? JSON.parse(text) : null;
    if (!res.ok) return { error: data?.message || `HTTP ${res.status}` };
    return { data, error: null };
  } catch (e) { return { error: e?.message || 'offline' }; }
}

/** Ask the database who this email is. Returns true when it answered. */
async function enterCloud(email) {
  const { data, error } = await rpc('enter_app', { p_email: email });
  const row = Array.isArray(data) ? data[0] : data;
  if (error || !row?.user_id) return false;
  uid = row.user_id;
  cloudProfile = { display_name: row.display_name, avatar_id: row.avatar_id, email };
  return true;
}
const remember = email => { try { localStorage.setItem(USER_KEY, email); } catch { /* private mode: sign in again next time */ } };
const readLocalProfile = email => { try { return JSON.parse(localStorage.getItem(`${PROFILE_KEY}.${email}`)); } catch { return null; } };
const writeLocalProfile = (email, p) => { try { localStorage.setItem(`${PROFILE_KEY}.${email}`, JSON.stringify(p)); } catch { /* ignore */ } };

/** Restore whoever signed in last on this browser (and reconnect them to the database). Resolves { user, error }. */
export async function initAuth() {
  let email = null;
  try { email = localStorage.getItem(USER_KEY) || localStorage.getItem('sd-local-user'); } catch { /* storage blocked */ } // 2nd key: previous version
  if (!email) return { user: null, error: CONFIGURED ? null : 'not-configured' };
  user = { id: email, email };
  await enterCloud(email);
  return { user, error: null };
}

/** Sign in with just an email. Always succeeds; the database is asked, but its answer is never required. */
export async function signInWithEmail(rawEmail) {
  const email = norm(rawEmail);
  user = { id: email, email };
  remember(email);
  await enterCloud(email);
  emit();
  return { error: null };
}

// ---------- profile ----------
export async function loadProfile() {
  if (!user) return null;
  const mine = readLocalProfile(user.email);
  if (cloudProfile?.display_name) return cloudProfile;
  if (uid && mine?.display_name) { // set while the database was unreachable: upload it now
    await rpc('save_profile', { p_user: uid, p_name: mine.display_name, p_avatar: mine.avatar_id });
    cloudProfile = { ...cloudProfile, ...mine };
    return cloudProfile;
  }
  return mine || cloudProfile || { display_name: null, avatar_id: null, email: user.email };
}
export async function saveProfile({ display_name, avatar_id }) {
  if (!user) return { error: 'Not signed in.' };
  if (uid) {
    const { error } = await rpc('save_profile', { p_user: uid, p_name: display_name, p_avatar: avatar_id });
    if (error && error !== 'offline' && !/fetch|abort|timeout|network/i.test(error)) return { error }; // e.g. name length rule
  }
  writeLocalProfile(user.email, { display_name, avatar_id, email: user.email });
  if (cloudProfile) cloudProfile = { ...cloudProfile, display_name, avatar_id };
  return { error: null };
}

// ---------- login / logout log (see supabase/email-auth.sql: sessions) ----------
const sessionCall = (name, extra, keepalive = false) => uid ? rpc(name, { p_user: uid, p_id: sessionId, ...extra }, { keepalive }) : Promise.resolve();
export function startSession() {
  if (!user) return;
  sessionId = crypto.randomUUID();
  sessionEnded = false;
  sessionCall('start_session', {});
  clearInterval(pingTimer);
  pingTimer = setInterval(() => { if (!sessionEnded) sessionCall('ping_session', {}); }, PING_MS);
}
/** reason: 'manual' (Sign out button) or 'tab_closed' (best effort on pagehide). */
export function endSession(reason, keepalive = false) {
  if (!sessionId || sessionEnded) return Promise.resolve();
  sessionEnded = true;
  clearInterval(pingTimer);
  return sessionCall('end_session', { p_reason: reason }, keepalive);
}
/** A phone may fire pagehide when the app is backgrounded; if the page comes back, open a fresh session. */
export function resumeSessionIfEnded() { if (user && sessionEnded && sessionId) startSession(); }

export async function signOut() {
  await endSession('manual');
  try { localStorage.removeItem(USER_KEY); } catch { /* ignore */ }
  user = null; uid = null; cloudProfile = null; sessionId = null;
  emit();
}

// ---------- journey in the database ----------
export async function fetchJourney() {
  if (!uid) return null;
  const { data } = await rpc('get_journey', { p_user: uid });
  return data?.data ? { ...data.data, savedAt: data.data.savedAt || data.updated_at } : null;
}
/** The database was unreachable at sign-in: try again now (at most every 30 s). On success, log the session too. */
async function upgrade() {
  if (uid || !user || Date.now() - lastUpgrade < JOURNEY_SYNC_MS) return;
  lastUpgrade = Date.now();
  if (await enterCloud(user.email) && sessionId && !sessionEnded) sessionCall('start_session', {});
}
/** Upload at most every 30 s; force = pause / leaving the drive / closing the tab. Failures retry on the next call. */
export async function pushJourney(journey, { force = false, keepalive = false } = {}) {
  if (!user || !journey) return;
  if (!uid) { journeyDirty = true; if (!keepalive) await upgrade(); if (!uid) return; }
  const now = Date.now();
  if (!force && now - lastJourneyPush < JOURNEY_SYNC_MS) { journeyDirty = true; return; }
  lastJourneyPush = now; journeyDirty = false;
  if (keepalive) { rpc('save_journey', { p_user: uid, p_data: journey }, { keepalive: true }); return; }
  const { error } = await rpc('save_journey', { p_user: uid, p_data: journey });
  if (error) { journeyDirty = true; lastJourneyPush = 0; } // offline: the local copy is kept, try again next save
}
export async function deleteRemoteJourney() {
  if (!uid) return;
  await rpc('delete_journey', { p_user: uid });
}
export const hasUnsyncedJourney = () => journeyDirty;
