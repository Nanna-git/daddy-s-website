// Camera rig: Outside (third-person follow) and Driver (left-hand seat), with a 0.5 s smooth move between them.
import * as THREE from 'three';

const AHEAD = 3;
const SWITCH_SECONDS = 0.5;
const FOV = { outside: 60, driver: 70 };

/** Outside view: behind and above the car, damped, swings a little wider in turns. */
class FollowCamera {
  constructor() {
    this.cfg = { back: 5.5, height: 2.1, lookY: 1.0 }; // per vehicle (specs.js "outside")
    this.pos = new THREE.Vector3();
    this.look = new THREE.Vector3();
    this.heading = 0;
    this.ready = false;
  }

  update(dt, car) {
    const target = car.heading - car.yawRate * 0.22;
    if (!this.ready) this.heading = target;
    let d = target - this.heading;
    d = Math.atan2(Math.sin(d), Math.cos(d));
    this.heading += d * (1 - Math.exp(-5 * dt));

    const hx = Math.sin(this.heading), hz = Math.cos(this.heading);
    const { back, height, lookY } = this.cfg;
    const y = car.y || 0; // hills (Mountain Village)
    const wantPos = new THREE.Vector3(car.x - hx * back, y + height, car.z - hz * back);
    const wantLook = new THREE.Vector3(car.x + car.fx * AHEAD, y + lookY, car.z + car.fz * AHEAD);
    if (!this.ready) { this.pos.copy(wantPos); this.look.copy(wantLook); this.ready = true; }
    this.pos.lerp(wantPos, 1 - Math.exp(-8 * dt));
    this.look.lerp(wantLook, 1 - Math.exp(-12 * dt));
  }
}

export class CameraRig {
  constructor(camera, carRoot, view = 'outside') {
    this.camera = camera;
    this.root = carRoot;
    this.follow = new FollowCamera();
    this.view = view;
    this.k = view === 'driver' ? 1 : 0; // 0 = outside, 1 = driver
    this._eye = new THREE.Vector3();
    this._look = new THREE.Vector3();
    this.eye = new THREE.Vector3(0.36, 1.28, -0.3);  // driver seat, car-local (set per vehicle)
    this.lookAt = new THREE.Vector3(-1.3, 1.32, 10);
    this.roll = 0; // motorbike lean, applied to the rider's view
    this._shake = 0;
  }

  /** Follow a different car model / driver seat (when the vehicle changes). */
  attach(carRoot, eye, look, outside) { this.root = carRoot; this.eye.copy(eye); this.lookAt.copy(look); if (outside) this.follow.cfg = outside; }

  /** Jolt the view (a crash). amount in metres, decays in about a third of a second. */
  shake(amount) { this._shake = Math.max(this._shake, amount); }

  toggle() { this.view = this.view === 'driver' ? 'outside' : 'driver'; return this.view; }
  set(view) { this.view = view; }

  /** 0..1 eased blend; > 0.6 means the camera is inside the car. */
  get blend() { const k = this.k; return k * k * (3 - 2 * k); }
  get inside() { return this.blend > 0.6; }

  update(dt, car) {
    this.follow.update(dt, car);
    const target = this.view === 'driver' ? 1 : 0;
    const step = dt / SWITCH_SECONDS;
    this.k += Math.max(-step, Math.min(step, target - this.k));

    this.root.updateMatrixWorld();
    this._eye.copy(this.eye).applyMatrix4(this.root.matrixWorld);
    this._look.copy(this.lookAt).applyMatrix4(this.root.matrixWorld);

    const e = this.blend;
    this.camera.position.copy(this.follow.pos).lerp(this._eye, e);
    const look = this.follow.look.clone().lerp(this._look, e);
    this.camera.lookAt(look);
    if (this._shake > 0.003) {
      const a = this._shake;
      this.camera.position.x += (Math.random() - 0.5) * a; this.camera.position.y += (Math.random() - 0.5) * a * 0.7; this.camera.position.z += (Math.random() - 0.5) * a;
      this._shake *= Math.exp(-9 * dt);
    } else this._shake = 0;
    // the rider's eye already leans with the bike; turn the view back by half, so the horizon tilts gently (no motion sickness)
    if (this.roll) this.camera.rotateZ(-this.roll * e * 0.5);
    const fov = FOV.outside + (FOV.driver - FOV.outside) * e;
    if (Math.abs(this.camera.fov - fov) > 0.01) { this.camera.fov = fov; this.camera.updateProjectionMatrix(); }
  }
}
