// Car against car (pure: unit-tested in node). Peer-side: each client only ever moves its OWN car, treating the other
// as a moving box. Each side takes its share of the push-out and of the bounce, so together they add up.
export const RESTITUTION = 0.35;   // how much of the closing speed comes back as bounce
export const MAX_DY = 3;           // cars on different levels (Metro's highway) never touch
import { DEFAULT_MASS } from './damage.js';

const radius = (hw, hl, ax, az, fx, fz) => hw * Math.abs(fz * ax - fx * az) + hl * Math.abs(fx * ax + fz * az);

/** Overlap of two oriented boxes { x, z, fx, fz, hw, hl }: { depth, nx, nz } with the normal pointing from b to a, or null. */
export function overlapBoxes(a, b) {
  const dx = a.x - b.x, dz = a.z - b.z;
  let best = Infinity, nx = 0, nz = 0;
  for (const [ax, az] of [[a.fx, a.fz], [a.fz, -a.fx], [b.fx, b.fz], [b.fz, -b.fx]]) {
    const ra = radius(a.hw, a.hl, ax, az, a.fx, a.fz), rb = radius(b.hw, b.hl, ax, az, b.fx, b.fz);
    const d = dx * ax + dz * az, o = ra + rb - Math.abs(d);
    if (o <= 0) return null;
    if (o < best) { best = o; const s = d < 0 ? -1 : 1; nx = ax * s; nz = az * s; }
  }
  return { depth: best, nx, nz };
}

/**
 * Resolve my car (CarPhysics-like) against one remote car
 * { x, y, z, heading, vx, vz, hw, hl, mass, armed }.
 * `armed` is kept on the remote: false until we have been apart once, so cars that spawn or teleport into each other
 * pass through instead of exploding. Returns null (no contact) or { closing, massRatio } for a real hit.
 */
export function collideCar(car, other) {
  const dy = Math.abs((other.y || 0) - (car.y || 0));
  const ov = dy <= MAX_DY ? overlapBoxes(
    { x: car.x, z: car.z, fx: car.fx, fz: car.fz, hw: car.spec.halfWidth, hl: car.spec.halfLength },
    { x: other.x, z: other.z, fx: Math.sin(other.heading), fz: Math.cos(other.heading), hw: other.hw, hl: other.hl }) : null;
  if (!ov) { other.armed = true; return null; }
  if (!other.armed) return null;

  const ms = car.spec.mass || DEFAULT_MASS, mo = other.mass || DEFAULT_MASS;
  const share = mo / (ms + mo);                       // the lighter car moves more
  car.x += ov.nx * ov.depth * share; car.z += ov.nz * ov.depth * share;
  const v = car.velocity();
  const vn = (v.x - other.vx) * ov.nx + (v.z - other.vz) * ov.nz;
  if (vn >= 0) return null;                           // already moving apart
  const dv = -(1 + RESTITUTION) * share * vn;
  car.setVelocity(v.x + ov.nx * dv, v.z + ov.nz * dv);
  return { closing: -vn, massRatio: mo / ms };
}
