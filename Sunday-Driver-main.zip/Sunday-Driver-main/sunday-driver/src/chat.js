// Chat UI: fading log while driving, input bar (Enter / 💬), quick-phrase chips, unread dot, read-only history in Pause.
// Messages are plain text only (textContent). Muting is per session and never saved.
import { PHRASES, HISTORY_MAX, LOG_FADE_MS, parseIncoming, pushHistory, visibleLog } from './chatCore.js';

export function createChat({ send, canSend = () => true, onOpenChange } = {}) {
  const $ = id => document.getElementById(id);
  const logEl = $('chat-log'), bar = $('chat-bar'), input = $('chat-input'), chips = $('chat-chips'), btn = $('chat-btn'), dot = $('chat-dot');
  const pauseBox = $('pause-chat'), pauseList = $('pause-chat-list');
  const history = [];
  const muted = new Set();
  let open = false, unread = 0, tick = 0;

  chips.innerHTML = PHRASES.map((p, i) => `<button type="button" data-q="${i}">${p}</button>`).join('');

  const line = m => {
    const el = document.createElement('div');
    el.className = 'msg' + (m.phrase ? ' phrase' : '');
    const b = document.createElement('b'); b.textContent = m.name;
    el.append(b, document.createTextNode(m.text));
    return el;
  };

  function render() {
    const now = Date.now();
    const list = open ? history.filter(m => !muted.has(m.id)) : visibleLog(history, muted, now);
    logEl.replaceChildren(...list.map(m => {
      const el = line(m);
      if (!open && now - m.at > LOG_FADE_MS - 600) el.classList.add('fading');
      return el;
    }));
    if (open) logEl.scrollTop = logEl.scrollHeight;
    logEl.classList.toggle('open', open);
    clearTimeout(tick);
    if (!open && list.length) tick = setTimeout(render, 500);
  }

  function renderPause() {
    pauseList.replaceChildren(...history.filter(m => !muted.has(m.id)).slice(-20).map(line));
    pauseList.scrollTop = pauseList.scrollHeight;
  }

  function setUnread(n) { unread = n; dot.hidden = n === 0; }

  function setOpen(v) {
    if (v === open) return;
    open = v;
    bar.hidden = !v;
    document.body.classList.toggle('chat-open', v);
    if (v) { setUnread(0); input.value = ''; requestAnimationFrame(() => input.focus({ preventScroll: true })); }
    else input.blur();
    render();
    onOpenChange?.(v);
  }

  function submit(msg) {
    const r = send(msg);
    if (r === 'ok') { if (msg.t !== undefined) input.value = ''; return true; }
    return false;
  }

  bar.addEventListener('submit', e => {
    e.preventDefault();
    const t = input.value.trim();
    if (t) submit({ t });
  });
  chips.addEventListener('click', e => { const b = e.target.closest('[data-q]'); if (b) { submit({ q: +b.dataset.q }); b.blur(); input.focus({ preventScroll: true }); } });
  $('chat-close').addEventListener('click', () => setOpen(false));
  btn.addEventListener('click', () => { setOpen(!open); btn.blur(); });
  input.addEventListener('keydown', e => {
    e.stopPropagation();                   // typing never reaches the driving or hotkey handlers
    if (e.code === 'Escape') { e.preventDefault(); setOpen(false); }
  });

  return {
    get open() { return open; },
    get muted() { return muted; },
    history,
    show: () => canSend() && setOpen(true),
    close: () => setOpen(false),
    toggleOpen: () => setOpen(!open),
    /** Add a message (mine or someone else's). Returns the entry, or null if dropped. */
    add(entry, { mine = false } = {}) {
      if (!entry) return null;
      pushHistory(history, entry, HISTORY_MAX);
      if (!muted.has(entry.id)) {
        if (!open && !mine) setUnread(Math.min(99, unread + 1));
        render();
        renderPause();
      }
      return entry;
    },
    receive(payload, name) { const e = parseIncoming(payload, name); return e ? this.add(e) : null; },
    setMuted(id, v) { v ? muted.add(id) : muted.delete(id); render(); renderPause(); },
    clear() { history.length = 0; setUnread(0); render(); renderPause(); },
    /** Show or hide the whole feature (toggle off, offline, menus). */
    setAvailable(v) { btn.hidden = !v; if (!v) setOpen(false); if (!v) logEl.replaceChildren(); else render(); },
    refreshPause(visible) { pauseBox.hidden = !visible; if (visible) renderPause(); },
  };
}
