// Chat: pure helpers (no DOM, no network) so they can be unit-tested.
export const MAX_LEN = 140;          // characters per typed message
export const RATE_MS = 1500;         // minimum gap between my messages
export const HISTORY_MAX = 50;       // messages kept in memory per client
export const LOG_LINES = 5;          // lines shown in the fading driving log
export const LOG_FADE_MS = 8000;     // a line fades out this long after it arrives
export const SAY_MS = 3000;          // quick-phrase bubble over a car
export const PHRASES = ['Nice car!', 'Follow me', 'Race you?', 'Sorry!', 'Thanks!', 'Good drive'];

/** Plain text only: control characters become spaces, whitespace collapses, trimmed and capped. */
export function cleanText(s) {
  return String(s ?? '').replace(/[\u0000-\u001f\u007f-\u009f​-‏‪-‮⁦-⁩]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, MAX_LEN);
}

const BAD = ['fuck', 'shit', 'bitch', 'asshole', 'cunt', 'dick', 'nigger', 'nigga', 'faggot', 'slut', 'whore', 'bastard'];
const BAD_RE = new RegExp(`(?<![a-z])(?:${BAD.join('|')})(?:ty|y|s|er|ers|ing|ed)?(?![a-z])`, 'gi');
/** Basic word filter applied to received text: masks the word with asterisks. */
export const maskWords = s => String(s).replace(BAD_RE, m => '*'.repeat(m.length));

/** Turn a received broadcast payload into a log entry, or null if it is junk. name = shown name from Presence. */
export function parseIncoming(payload, name, now = Date.now()) {
  if (!payload || typeof payload !== 'object' || !payload.id) return null;
  if (Number.isInteger(payload.q)) {
    const text = PHRASES[payload.q];
    return text ? { id: payload.id, name, text, phrase: true, at: now } : null;
  }
  if (typeof payload.t !== 'string') return null;
  const text = maskWords(cleanText(payload.t));
  return text ? { id: payload.id, name, text, phrase: false, at: now } : null;
}

/** Append, keeping only the newest `max`. */
export function pushHistory(list, entry, max = HISTORY_MAX) {
  list.push(entry);
  if (list.length > max) list.splice(0, list.length - max);
  return list;
}

/** The lines the driving log shows: newest few, not muted, not older than the fade time. */
export function visibleLog(list, muted, now, { lines = LOG_LINES, fadeMs = LOG_FADE_MS } = {}) {
  return list.filter(m => !muted.has(m.id) && now - m.at < fadeMs).slice(-lines);
}

/** Is a send allowed right now? */
export const canSendNow = (last, now, rate = RATE_MS) => now - last >= rate;
