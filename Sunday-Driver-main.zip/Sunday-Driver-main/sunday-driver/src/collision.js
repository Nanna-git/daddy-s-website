// Car (oriented box) vs buildings/walls (axis-aligned boxes) and poles/trees (circles).
// Push the car out, then bounce: a head-on hit keeps ~30 % of speed, a scrape keeps most of it.
// resolveCollisions returns the hardest closing speed (m/s) it met this step, for damage and crash feedback.

function respond(car, nx, nz, hit) {
  const v = car.velocity();
  const speed = Math.hypot(v.x, v.z);
  const vn = v.x * nx + v.z * nz;
  if (vn >= 0 || speed < 1e-4) return;
  if (-vn > hit.speed) hit.speed = -vn;
  let vx = v.x - nx * vn * 1.2;
  let vz = v.z - nz * vn * 1.2;
  const keep = 1 - 0.7 * Math.min(1, -vn / speed);
  car.setVelocity(vx * keep, vz * keep);
}

function vsBox(car, b, hit) {
  const hw = car.spec.halfWidth, hl = car.spec.halfLength;
  const fx = car.fx, fz = car.fz, lx = fz, lz = -fx;
  const bx = (b.minX + b.maxX) / 2, bz = (b.minZ + b.maxZ) / 2;
  const ex = (b.maxX - b.minX) / 2, ez = (b.maxZ - b.minZ) / 2;
  const dx = car.x - bx, dz = car.z - bz;
  let best = Infinity, nx = 0, nz = 0;
  for (const [ax, az] of [[1, 0], [0, 1], [fx, fz], [lx, lz]]) {
    const rc = hw * Math.abs(lx * ax + lz * az) + hl * Math.abs(fx * ax + fz * az);
    const rb = ex * Math.abs(ax) + ez * Math.abs(az);
    const d = dx * ax + dz * az;
    const overlap = rc + rb - Math.abs(d);
    if (overlap <= 0) return false;
    if (overlap < best) { best = overlap; const s = d < 0 ? -1 : 1; nx = ax * s; nz = az * s; }
  }
  car.x += nx * best; car.z += nz * best;
  respond(car, nx, nz, hit);
  return true;
}

function vsCircle(car, c, hit) {
  const hw = car.spec.halfWidth, hl = car.spec.halfLength;
  const fx = car.fx, fz = car.fz, lx = fz, lz = -fx;
  const dx = c.x - car.x, dz = c.z - car.z;
  const lf = dx * fx + dz * fz, ll = dx * lx + dz * lz;
  const cf = Math.max(-hl, Math.min(hl, lf)), cl = Math.max(-hw, Math.min(hw, ll));
  const px = car.x + fx * cf + lx * cl, pz = car.z + fz * cf + lz * cl; // closest point on the car
  let ox = px - c.x, oz = pz - c.z;
  let dist = Math.hypot(ox, oz);
  if (dist >= c.r) return false;
  if (dist < 1e-4) { ox = car.x - c.x; oz = car.z - c.z; dist = Math.hypot(ox, oz) || 1; }
  const nx = ox / dist, nz = oz / dist;
  const push = c.r - Math.min(dist, c.r);
  car.x += nx * (push + 0.01); car.z += nz * (push + 0.01);
  respond(car, nx, nz, hit);
  return true;
}

export function resolveCollisions(car, { boxes, circles }) {
  const hit = { speed: 0 };
  const reach = car.spec.halfLength + 1;
  // Metro's highway: lvl 'deck' things (parapets, parked cars) only stop cars up on the deck, lvl 'low' things
  // (its pillars) only cars on the road below; o.y (AI cars) must be within 3 m of the car's height.
  const y = car.y || 0, high = y > 4.5;
  const live = o => (o.lvl === 'deck' ? high : o.lvl === 'low' ? !high : true) && (o.y === undefined || Math.abs(o.y - y) <= 3);
  for (let pass = 0; pass < 2; pass++) {
    for (const b of boxes) {
      if (!live(b)) continue;
      if (car.x + reach < b.minX || car.x - reach > b.maxX || car.z + reach < b.minZ || car.z - reach > b.maxZ) continue;
      vsBox(car, b, hit);
    }
    for (const c of circles) {
      if (!live(c)) continue;
      if (Math.abs(c.x - car.x) > reach + c.r || Math.abs(c.z - car.z) > reach + c.r) continue;
      vsCircle(car, c, hit);
    }
  }
  return hit.speed;
}
