// Supabase project settings. Both values are PUBLIC by design (they ship to every browser);
// Row Level Security in supabase/schema.sql is what protects the data.
// Never put the secret key (sb_secret_...) or the legacy "service_role" key here.
export const SUPABASE_URL = 'https://pwzovfvdlqorsrejgqgm.supabase.co';
export const SUPABASE_ANON_KEY = 'sb_publishable_KrqBIUI_JSA2mUn7TOXjQQ_hG7Aq3HB';
export const CONFIGURED = !SUPABASE_URL.includes('YOUR-PROJECT-REF');
