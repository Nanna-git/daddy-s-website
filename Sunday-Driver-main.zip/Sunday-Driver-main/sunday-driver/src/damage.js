// Damage and repair maths (pure: no browser or three.js, unit-tested in node).
// One 0–100 % damage meter per car. A hit's damage comes from its closing speed along the hit normal, scaled by how
// heavy the other thing is compared with you. Damage darkens the paint, smokes above SMOKE_FROM and mildly slows the car.
export const DEAD_ZONE = 10 / 3.6;       // m/s: gentler bumps than 10 km/h cause no damage
export const DAMAGE_PER_MS = 2;          // % of damage per m/s of closing speed above the dead zone
export const MAX_HIT = 70;               // most one hit can do
export const MAX_SPEED_LOSS = 0.3;       // at 100 % damage: 70 % top speed and acceleration
export const SMOKE_FROM = 60;            // % above which the car smokes
export const REPAIR_RATE = 20;           // % per second on a pad (a wreck is whole again in 5 s)
export const REPAIR_RADIUS = 4;          // m: how close to a pad's centre counts as "on" it
export const REPAIR_MAX_KMH = 4;         // you must be (nearly) stopped
export const DEFAULT_MASS = 1200;

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

/** How much harder you are hit by something heavier: other mass / yours, between ½ and 2. Walls and traffic count as equal. */
export function massFactor(otherMass, selfMass) {
  return clamp((otherMass || DEFAULT_MASS) / (selfMass || DEFAULT_MASS), 0.5, 2);
}

/** Damage % for one hit. closing = m/s towards each other along the hit normal. */
export function impactDamage(closing, factor = 1) {
  if (!(closing > DEAD_ZONE)) return 0;
  return Math.min(MAX_HIT, (closing - DEAD_ZONE) * DAMAGE_PER_MS * factor);
}

/** 1 for a healthy car, down to 1 − MAX_SPEED_LOSS at 100 %. Scales top speed and acceleration. */
export function performanceFactor(damage) {
  return 1 - MAX_SPEED_LOSS * clamp((damage || 0) / 100, 0, 1);
}

export const addDamage = (damage, hit) => clamp(damage + hit, 0, 100);
export const repairStep = (damage, dt) => Math.max(0, damage - REPAIR_RATE * dt);

/** The pad (from [{ x, z, y }]) the car is parked on, or null. Close enough in height so Metro's highway never counts. */
export function padUnder(pads, x, z, y = 0) {
  for (const p of pads || []) {
    if (Math.hypot(x - p.x, z - p.z) <= REPAIR_RADIUS && Math.abs((p.y || 0) - y) < 3) return p;
  }
  return null;
}
export const isRepairing = (pad, kmh, damage) => !!pad && kmh <= REPAIR_MAX_KMH && damage > 0;

/** Paint mixed towards soot: 0 % = as is, 100 % = 65 % of the way to dark. Returns '#rrggbb'. */
export function tintPaint(hex, damage) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  if (!m) return hex;
  const k = 0.65 * clamp((damage || 0) / 100, 0, 1), soot = [0x2a, 0x26, 0x22];
  const n = parseInt(m[1], 16);
  const ch = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((c, i) => Math.round(c + (soot[i] - c) * k));
  return '#' + ch.map(c => c.toString(16).padStart(2, '0')).join('');
}
