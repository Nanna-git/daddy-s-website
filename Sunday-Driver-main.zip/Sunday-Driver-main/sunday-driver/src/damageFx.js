// Crash visuals: pooled smoke puffs for damaged cars and a burst of sparks on impact. Sprites only, so it stays cheap on phones.
import * as THREE from 'three';
import { SMOKE_FROM } from './damage.js';

function texture(stops) {
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const g = c.getContext('2d'), grad = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  stops.forEach(([o, col]) => grad.addColorStop(o, col));
  g.fillStyle = grad; g.fillRect(0, 0, 64, 64);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export function createDamageFx(scene) {
  const smokeTex = texture([[0, 'rgba(70,66,62,0.9)'], [0.6, 'rgba(70,66,62,0.35)'], [1, 'rgba(70,66,62,0)']]);
  const sparkTex = texture([[0, 'rgba(255,240,180,1)'], [0.4, 'rgba(255,150,40,0.8)'], [1, 'rgba(255,100,0,0)']]);
  const make = (tex, additive, n) => Array.from({ length: n }, () => {
    const m = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, opacity: 0, blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending });
    const sprite = new THREE.Sprite(m); sprite.visible = false; scene.add(sprite);
    return { sprite, life: 0, max: 1, vx: 0, vy: 0, vz: 0, s0: 1, s1: 1, o: 1, g: 0 };
  });
  const smoke = make(smokeTex, false, 48), sparks = make(sparkTex, true, 40);
  let si = 0, pi = 0;

  function spawn(pool, idx, x, y, z, vx, vy, vz, life, s0, s1, o, g) {
    const p = pool[idx]; Object.assign(p, { life: 0, max: life, vx, vy, vz, s0, s1, o, g });
    p.sprite.position.set(x, y, z); p.sprite.visible = true; p.sprite.material.opacity = o; p.sprite.scale.setScalar(s0);
  }
  function tick(pool, dt) {
    for (const p of pool) {
      if (!p.sprite.visible) continue;
      p.life += dt;
      if (p.life >= p.max) { p.sprite.visible = false; continue; }
      const k = p.life / p.max;
      p.vy -= p.g * dt;
      p.sprite.position.x += p.vx * dt; p.sprite.position.y += p.vy * dt; p.sprite.position.z += p.vz * dt;
      p.sprite.scale.setScalar(p.s0 + (p.s1 - p.s0) * k);
      p.sprite.material.opacity = p.o * (1 - k) * (1 - k * 0.3);
    }
  }

  return {
    /** Smoke from a damaged car's bonnet. emitter = { t: 0 } kept by the caller; pos = { x, y, z } of the bonnet. */
    smoke(emitter, dt, pos, damage) {
      if (damage < SMOKE_FROM) { emitter.t = 0; return; }
      const heavy = (damage - SMOKE_FROM) / (100 - SMOKE_FROM);       // 0 … 1
      emitter.t += dt * (4 + 8 * heavy);                              // puffs per second
      while (emitter.t >= 1) {
        emitter.t -= 1;
        spawn(smoke, si, pos.x + (Math.random() - 0.5) * 0.5, pos.y, pos.z + (Math.random() - 0.5) * 0.5,
          (Math.random() - 0.5) * 0.6, 1.2 + Math.random() * 0.8, (Math.random() - 0.5) * 0.6,
          1.3 + heavy * 0.7, 0.5, 2 + heavy * 1.2, 0.55 + 0.25 * heavy, 0);
        si = (si + 1) % smoke.length;
      }
    },
    /** A burst of sparks at a hit. strength 0…1 */
    sparks(x, y, z, strength) {
      const n = 4 + Math.round(strength * 10);
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2, sp = 2 + Math.random() * 5 * (0.5 + strength);
        spawn(sparks, pi, x, y, z, Math.cos(a) * sp, 1 + Math.random() * 3, Math.sin(a) * sp, 0.35 + Math.random() * 0.25, 0.28, 0.12, 1, 14);
        pi = (pi + 1) % sparks.length;
      }
    },
    update(dt) { tick(smoke, dt); tick(sparks, dt); },
    clear() { [...smoke, ...sparks].forEach(p => { p.sprite.visible = false; }); },
  };
}
