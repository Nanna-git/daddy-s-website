// HUD: city chip + clock (top left), weather switcher 1–4 (top right), mini-map (bottom left),
// speed + view toggle (bottom right). In Driver view the speed hides and the bottom items sit above the dashboard.
import { WEATHER_ORDER } from './scene/weather.js';
import { createMinimap } from './minimap.js';

export function createHud({ onWeather, onView, canUse = () => true }) {
  const hud = document.getElementById('hud');
  const clockEl = document.getElementById('clock');
  const speedEl = document.getElementById('speed-num');
  const weatherBtns = [...document.querySelectorAll('#weather button')];
  const viewBtns = [...document.querySelectorAll('#view button')];
  const minimap = createMinimap(document.getElementById('minimap'));
  const dmgEl = document.getElementById('damage'), dmgFill = document.getElementById('damage-fill'), dmgPct = document.getElementById('damage-pct'), dmgLabel = document.getElementById('damage-label');
  let lastDmg = -1, lastDmgMode = '';

  const press = (btns, key, value) => btns.forEach(b => b.setAttribute('aria-pressed', String(b.dataset[key] === value)));

  weatherBtns.forEach(b => b.addEventListener('click', () => { onWeather(b.dataset.weather); b.blur(); }));
  viewBtns.forEach(b => b.addEventListener('click', () => { onView(b.dataset.view); b.blur(); })); // blur: keep Space for the handbrake
  addEventListener('keydown', e => {
    const n = { Digit1: 0, Digit2: 1, Digit3: 2, Digit4: 3, Numpad1: 0, Numpad2: 1, Numpad3: 2, Numpad4: 3 }[e.code];
    if (n !== undefined && canUse()) onWeather(WEATHER_ORDER[n]);
  });

  let lastClock = '', lastSpeed = -1, lastLift = -1;
  return {
    /** Damage chip: shown while the car is hurt. mode: '' | 'pad' (on a pad, keep still) | 'repairing' */
    setDamage(damage, mode = '') {
      const d = Math.round(damage);
      if (d === lastDmg && mode === lastDmgMode) return;
      lastDmg = d; lastDmgMode = mode;
      dmgEl.hidden = d <= 0;
      dmgFill.style.width = d + '%';
      dmgEl.dataset.level = d >= 60 ? 'bad' : d >= 30 ? 'mid' : 'low';
      dmgPct.textContent = d + '%';
      dmgLabel.textContent = mode === 'repairing' ? 'Repairing…' : mode === 'pad' ? 'Stop to repair' : 'Damage';
    },
    /** Switch the city chip name and the mini-map. */
    setCity(name, mapInfo) {
      document.querySelector('#city .name').textContent = name;
      minimap.setInfo(mapInfo);
    },
    setMapActive: v => minimap.setActive(v),
    setWeather: name => press(weatherBtns, 'weather', name),
    setView: view => { press(viewBtns, 'view', view); hud.classList.toggle('driver', view === 'driver'); },
    /** lift: px to raise the bottom corners (0 outside, above the dashboard line in driver view) */
    update(dt, { clock, speed, car, lift, others }) {
      if (clock !== lastClock) { clockEl.textContent = clock; lastClock = clock; }
      const s = Math.round(speed);
      if (s !== lastSpeed) { speedEl.textContent = s; lastSpeed = s; }
      const l = Math.round(lift);
      if (Math.abs(l - lastLift) > 2) { hud.style.setProperty('--lift', l + 'px'); lastLift = l; }
      minimap.update(dt, car, others);
    },
  };
}
