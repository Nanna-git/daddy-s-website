// Keyboard: held driving keys + one-shot actions (C view, H horn, M mute).
const HELD = {
  KeyW: 'up', ArrowUp: 'up',
  KeyS: 'down', ArrowDown: 'down',
  KeyA: 'left', ArrowLeft: 'left',
  KeyD: 'right', ArrowRight: 'right',
  Space: 'handbrake',
};

export function createInput({ onFirstInput, onView, onHorn, onMute, canDrive = () => true } = {}) {
  const state = { up: 0, down: 0, left: 0, right: 0, handbrake: 0 };
  let first = true;
  const firstInput = () => { if (first) { first = false; onFirstInput?.(); } };

  addEventListener('keydown', e => {
    firstInput();
    const k = HELD[e.code];
    if (!canDrive()) return; // menus keep their own keys (Tab, Enter, Space on buttons)
    if (k) { e.preventDefault(); state[k] = 1; return; }
    if (e.repeat) return;
    if (e.code === 'KeyC') onView?.();
    else if (e.code === 'KeyH') onHorn?.(true);
    else if (e.code === 'KeyM') onMute?.();
  });
  addEventListener('keyup', e => {
    const k = HELD[e.code];
    if (k) { e.preventDefault(); state[k] = 0; }
    if (e.code === 'KeyH') onHorn?.(false);
  });
  addEventListener('pointerdown', firstInput);
  addEventListener('blur', () => { Object.keys(state).forEach(k => { state[k] = 0; }); onHorn?.(false); });
  return state;
}
