// Sunday Driver — game flow: three cities, five vehicles, menus, journey memory.
import * as THREE from 'three';
import { createWorld } from './scene/world.js';
import { buildHarbor } from './scene/harbor.js';
import { buildMetro } from './scene/metro.js';
import { buildMountain } from './scene/mountain.js';
import { groundPose } from './scene/props.js';
import { createAtmosphere } from './scene/atmosphere.js';
import { createParticles } from './scene/particles.js';
import { createClouds } from './scene/clouds.js';
import { buildVehicle, PAINTS } from './vehicles/hatchback.js';
import { buildCockpit } from './vehicles/cockpit.js';
import { VEHICLES } from './vehicles/specs.js';
import { CarPhysics, HATCHBACK } from './vehicles/carPhysics.js';
import { resolveCollisions } from './collision.js';
import { collideCar } from './carCollision.js';
import { massFactor, impactDamage, addDamage, repairStep, padUnder, isRepairing, tintPaint } from './damage.js';
import { createDamageFx } from './damageFx.js';
import { createRepairPads } from './repair.js';
import { CameraRig } from './camera.js';
import { createInput } from './input.js';
import { createHud } from './hud.js';
import { createAudio } from './audio.js';
import { createTouchControls, isTouchDevice } from './touch.js';
import { createTraffic } from './traffic.js';
import { createMultiplayer, MAX_PLAYERS, REACTIONS } from './multiplayer.js';
import { PHRASES } from './chatCore.js';
import { createRemoteCars } from './remoteCars.js';
import { createChat } from './chat.js';
import { cleanText } from './chatCore.js';
import { createTurntable } from './turntable.js';
import { createMenus } from './menus.js';
import { loadJourney, saveJourney, clearJourney, loadPrefs, savePrefs, journeySummary, setSaveUser, mergeRemoteJourney, takeLegacyJourney, CITY_NAMES, WEATHER_NAMES, VEHICLE_NAMES } from './save.js';
import { initAuth, onAuthChange, signInWithEmail, signOut, loadProfile, saveProfile, startSession, endSession, resumeSessionIfEnded, fetchJourney, pushJourney, deleteRemoteJourney, configured } from './auth.js';

const params = new URLSearchParams(location.search);
const canvas = document.getElementById('game');
const world = createWorld(canvas);

// ---------- cities: each is built into its own group the first time it is chosen ----------
const cities = {};
const BUILDERS = { harbor: buildHarbor, metro: buildMetro, mountain: buildMountain };
function makeCity(id) {
  const g = new THREE.Group();
  world.scene.add(g);
  const c = (BUILDERS[id] || buildHarbor)(g);
  c.id = id;
  c.group = g;
  c.trafficSys = createTraffic(g, c, { ...c.traffic, heightAt: c.heightAt }); // AI cars live in the city's group, so they hide with it
  c.repair = createRepairPads(g, id, c.heightAt);   // repair pads: ring + canopy on the road, shown on the mini-map
  c.mapInfo = { ...c.mapInfo, pads: c.repair.pads };
  return c;
}
cities.harbor = makeCity('harbor');
let city = cities.harbor;

// ---------- game state ----------
const state = {
  screen: 'auth',      // auth | profile | start | city | vehicle | drive | pause
  city: 'harbor',
  vehicle: 'hatchback',
  paint: PAINTS.coral,
  view: 'outside',     // the driving view
  preview: 'outside',  // what the Choose Vehicle screen shows
  fromPause: false,    // Change City / Change Vehicle keep the current journey
  inJourney: false,
};
const prefs = loadPrefs(isTouchDevice() ? { quality: 'low' } : {}); // phones start on Low quality

const car = new CarPhysics(HATCHBACK, city.spawn);
let model = buildVehicle(VEHICLES.hatchback, state.paint);
world.scene.add(model.root);
let cockpit = buildCockpit(model.root, world.renderer, world.scene, VEHICLES.hatchback);
const rig = new CameraRig(world.camera, model.root, 'outside');
rig.attach(model.eyeRoot || model.root, cockpit.eye, cockpit.look, model.def.outside);
const turntable = createTurntable(state.paint);
const particles = createParticles(world.scene);

const atmosphere = createAtmosphere({
  world, car, particles,
  harbor: { setLook: o => city.setLook(o) }, // whichever city is active
  model: { setLights: v => model.setLights(v) }, // the player's model can be swapped
  clouds: createClouds(world.scene),
  weather: params.get('weather') || 'sunny',
  clock: params.get('time') || '10:00',
});

const audio = createAudio();
audio.setVolume(prefs.volume);
audio.setMuted(prefs.muted);
audio.attachUnlock(); // sound starts on the first tap, click or key press (and wakes again if the phone suspends it)

const drivingNow = () => state.screen === 'drive';

const hud = createHud({
  onWeather: name => { atmosphere.setWeather(name); hud.setWeather(atmosphere.weather); },
  onView: view => setView(view),
  canUse: () => drivingNow() && !chat.open,
});

// ---------- multiplayer (strictly additive: any failure leaves plain single-player) ----------
const fx = createDamageFx(world.scene);   // smoke + sparks
const remote = createRemoteCars({ scene: world.scene, camera: world.camera, tagsEl: document.getElementById('mp-tags'), fx });
let lastRoster = null, lastLights = -1;
const reactBtn = document.getElementById('react-btn'), reactPop = document.getElementById('react-pop'), reactSelf = document.getElementById('react-self');
reactPop.innerHTML = REACTIONS.map((e, i) => `<button type="button" data-react="${i}" aria-label="React ${e}">${e}<span class="key">${i + 5}</span></button>`).join('');
const chatOn = () => prefs.chat !== false && prefs.multiplayer !== false;
const chatAvailable = () => drivingNow() && chatOn() && mp.connected;
const nameOf = id => mp.displayName(id) || lastRoster?.players.find(p => p.id === id)?.name || 'Driver';
const chat = createChat({
  canSend: chatAvailable,
  onOpenChange: v => { if (v) { releaseKeys(); toggleReactPop(false); } },
  send: msg => {
    if (!chatAvailable()) return 'offline';
    const r = mp.sendChat(msg);
    if (r === 'ok') {
      const phrase = msg.q !== undefined;
      const text = phrase ? PHRASES[msg.q] : cleanText(msg.t);
      chat.add({ id: mp.myId, name: nameOf(mp.myId), text, phrase, at: Date.now() }, { mine: true });
    }
    return r;
  },
});
let chatInstance = '';
const mp = createMultiplayer({
  identity: () => ({ name: profile?.display_name, avatar: profile?.avatar_id }),
  onRoster: info => {
    lastRoster = info; remote.setRoster(info.players);
    if (info.status === 'online') { // a different instance means a different room: start the chat history fresh
      const key = `${state.city}-${info.instance}`;
      if (chatInstance && key !== chatInstance) chat.clear();
      chatInstance = key;
    }
     if (state.screen === 'pause') refreshPause(); refreshReact(); },
  onState: m => remote.onState(m),
  onReaction: m => remote.onReaction(m),
  onChat: m => {
    if (!chatOn()) return;
    const e = chat.receive(m, nameOf(m.id));
    if (e?.phrase && !chat.muted.has(e.id)) remote.onPhrase(e.id, e.text);
  },
  onStatus: () => { refreshReact(); if (state.screen === 'pause') refreshPause(); },
});
mp.setEnabled(prefs.multiplayer !== false);
const inWorld = () => state.screen === 'drive' || state.screen === 'pause';
/** Be in this city's channel while driving or paused; leave on every menu. */
function syncMultiplayer() {
  if (inWorld() && prefs.multiplayer !== false) mp.join(state.city, state.vehicle, state.paint);
  else { mp.leave(); remote.clear(); chat.clear(); chatInstance = ''; }
  remote.setVisible(inWorld() && prefs.multiplayer !== false);
  refreshReact();
}
function refreshReact() {
  const on = state.screen === 'drive' && prefs.multiplayer !== false && mp.connected;
  reactBtn.hidden = !on;
  if (!on) toggleReactPop(false);
  chat.setAvailable(chatAvailable());
}
function toggleReactPop(open = reactPop.hidden) {
  reactPop.hidden = !open;
  reactBtn.setAttribute('aria-expanded', String(open));
  if (open) reactPop.querySelectorAll('button').forEach(b => { b.disabled = !mp.reactionReady(); });
}
function react(i) {
  if (!drivingNow() || !mp.connected || !mp.sendReaction(i)) return;
  reactSelf.textContent = REACTIONS[i];
  reactSelf.classList.remove('pop'); void reactSelf.offsetWidth; reactSelf.classList.add('pop');
  toggleReactPop(false);
}
reactBtn.addEventListener('click', () => { toggleReactPop(); reactBtn.blur(); });
reactPop.addEventListener('click', e => { const b = e.target.closest('[data-react]'); if (b) { react(+b.dataset.react); b.blur(); } });

const hint = document.getElementById('hint');
const input = createInput({
  onFirstInput: () => audio.start(),
  onView: () => setView(state.view === 'driver' ? 'outside' : 'driver'),
  onHorn: on => audio.horn(on),
  onMute: () => { prefs.muted = audio.toggleMute(); savePrefs(prefs); },
  canDrive: () => drivingNow() && !chat.open,
});
const touch = createTouchControls(input, { onHorn: on => audio.horn(on), enabled: drivingNow });
const releaseKeys = () => { Object.keys(input).forEach(k => { input[k] = 0; }); touch.reset(); audio.horn(false); };

// ---------- settings ----------
function setView(view) {
  state.view = view;
  rig.set(view);
  hud.setView(view);
  if (state.screen === 'pause') refreshPause();
}
function setQuality(q) {
  prefs.quality = q;
  world.setQuality(q);
  particles.setQuality(q);
  if (cockpit) cockpit.mirrorInterval = q === 'low' ? 1 : 0;
  savePrefs(prefs);
}
/** Swap the player's car: model, driver seat, handling and engine sound. */
function setPlayerVehicle(id) {
  const def = VEHICLES[id];
  if (!def || model.def.id === id) return;
  model.dispose();
  cockpit.dispose();
  model = buildVehicle(def, shownPaint());
  world.scene.add(model.root);
  cockpit = buildCockpit(model.root, world.renderer, world.scene, def);
  cockpit.mirrorInterval = prefs.quality === 'low' ? 1 : 0;
  rig.attach(model.eyeRoot || model.root, cockpit.eye, cockpit.look, model.def.outside);
  car.spec = def.physics;
  audio.setProfile(def.audio);
  model.setLights(atmosphere.lights);
}
/** The player's paint as drawn: darkened a little for every few % of damage. */
const shownPaint = () => tintPaint(state.paint, Math.round(car.damage / 4) * 4);
let paintDamage = -1;
function setDamage(d) {
  car.damage = Math.min(100, Math.max(0, d));
  const q = Math.round(car.damage / 4) * 4;
  if (q !== paintDamage) { paintDamage = q; model.setPaint(shownPaint()); }
}
function setPaint(hex) {
  state.paint = hex;
  model.setPaint(shownPaint());
  turntable.setPaint(hex);
  menus.setPaint(hex);
}
function toggleFullscreen() {
  if (document.fullscreenElement) document.exitFullscreen?.();
  else document.documentElement.requestFullscreen?.().catch(() => {});
}

// ---------- journey memory ----------
function snapshot() {
  return {
    city: state.city, vehicle: state.vehicle, color: state.paint, view: state.view,
    weather: atmosphere.weather, clock: atmosphere.clockText, clockMinutes: atmosphere.clock.minutes,
    clockFrozen: atmosphere.clock.frozen, quality: prefs.quality, volume: audio.volume, muted: audio.muted,
    pos: { x: +car.x.toFixed(2), z: +car.z.toFixed(2), y: +(car.y || 0).toFixed(2), heading: +car.heading.toFixed(3) },
  };
}
/** Local save every time; the database copy is throttled to 30 s unless force (pause, leaving, closing the tab). */
function save(force = false, keepalive = false) {
  if (!state.inJourney) return Promise.resolve();
  return pushJourney(saveJourney(snapshot()), { force, keepalive });
}
function refreshContinue() {
  const j = loadJourney();
  menus.setContinue(j ? journeySummary(j) : null);
}
function resetCar(spawn = city.spawn) {
  Object.assign(car, { x: spawn.x, z: spawn.z, y: spawn.y || 0, heading: spawn.heading, vF: 0, vL: 0, steer: 0, yawRate: 0 });
  car.pullDir = Math.random() < 0.5 ? -1 : 1;
  setDamage(0);                // a new session or city starts with a whole car
  fx.clear();
  groundPose(car, city.heightAt);
}

/** Show a city (building it on first use): scenery, traffic, collisions, mini-map, Start-screen orbit. */
function setCity(id) {
  if (!cities[id]) cities[id] = makeCity(id);
  city = cities[id];
  car.y = 0;
  groundPose(car, city.heightAt);
  Object.values(cities).forEach(c => { c.group.visible = c === city; });
  state.city = id;
  trafficBoxes.boxes = city.trafficSys.boxes;
  orbitTarget.set(city.orbitTarget[0], 0, city.orbitTarget[1]);
  hud.setCity(CITY_NAMES[id], city.mapInfo);
  document.querySelector('#scr-start .pill').innerHTML = `<span class="dot"></span>Camera orbit · ${CITY_NAMES[id]}`;
}

// ---------- screens ----------
function go(screen) {
  const prev = state.screen;
  state.screen = screen;
  releaseKeys();
  document.body.classList.toggle('paused', screen === 'pause');
  if (screen !== 'drive') chat.close();
  menus.show(screen === 'drive' ? null : screen);
  syncMultiplayer();
  if (screen === 'pause') refreshPause();
  if (screen === 'vehicle') { menus.setCityName(CITY_NAMES[state.pickedCity || state.city]); applyPreview(); }
  if (screen === 'city') { state.pickedCity = state.pickedCity || state.city; menus.setCityPick(state.pickedCity); }
  if (screen === 'drive') {
    rig.set(state.view);
    rig.k = state.view === 'driver' ? 1 : 0;
    hud.setView(state.view);
    hud.setWeather(atmosphere.weather);
    hint.classList.remove('gone');
    clearTimeout(go.hintTimer);
    go.hintTimer = setTimeout(() => hint.classList.add('gone'), 6000);
  }
  audio.pause(screen !== 'drive');
  if (prev === 'drive' || screen === 'pause' || screen === 'start') save(true);
}

function applyPreview() {
  menus.setPreview(state.preview);
  if (state.preview === 'driver') { rig.set('driver'); rig.k = 1; }
}

function refreshPause() {
  menus.setPause({
    view: state.view, quality: prefs.quality, clockFrozen: atmosphere.clock.frozen, clockText: atmosphere.clockText,
    volume: audio.volume, muted: audio.muted,
    multiplayer: prefs.multiplayer !== false, collide: prefs.collide !== false, chat: prefs.chat !== false,
    chips: [CITY_NAMES[state.city], VEHICLE_NAMES[state.vehicle], WEATHER_NAMES[atmosphere.weather], atmosphere.clockText],
  });
  menus.setPlayers(lastRoster, CITY_NAMES[state.city], prefs.multiplayer !== false, chat.muted);
  chat.refreshPause(chatOn() && lastRoster?.status === 'online');
}

function startNewJourney() {
  clearJourney();
  deleteRemoteJourney();
  state.inJourney = false;
  state.fromPause = false;
  resetCar();
  atmosphere.snapWeather('sunny');
  atmosphere.clock.set('10:00');
  atmosphere.clock.frozen = false;
  menus.resetVehicle();
  go('city');
}

function continueJourney() {
  const j = loadJourney();
  if (!j) { startNewJourney(); return; }
  setCity(BUILDERS[j.city] ? j.city : 'harbor');
  state.pickedCity = state.city; state.inJourney = true; state.fromPause = false;
  state.vehicle = VEHICLES[j.vehicle] ? j.vehicle : 'hatchback';
  setPlayerVehicle(state.vehicle);
  setPaint(j.color || PAINTS.coral);
  resetCar({ x: j.pos.x, z: j.pos.z, y: j.pos.y, heading: j.pos.heading });
  atmosphere.snapWeather(j.weather || 'sunny');
  atmosphere.clock.set(typeof j.clockMinutes === 'number' ? j.clockMinutes : j.clock || '10:00');
  atmosphere.clock.frozen = !!j.clockFrozen;
  state.view = j.view === 'driver' ? 'driver' : 'outside';
  go('drive');
}

const menus = createMenus({
  continueJourney,
  newJourney: startNewJourney,
  fullscreen: toggleFullscreen,
  'city-back': () => { state.pickedCity = state.city; go(state.fromPause ? 'pause' : 'start'); },
  pickCity: id => { state.pickedCity = id; },
  'city-next': () => go('vehicle'),
  'veh-back': () => { setPlayerVehicle(state.vehicle); turntable.setVehicle(state.vehicle); go('city'); },
  vehicleShown: v => {
    if (!v.ready) return;
    state.shownVehicle = v.id;
    turntable.setVehicle(v.id);
    if (state.screen === 'vehicle' && state.preview === 'driver') setPlayerVehicle(v.id);
  },
  drive: () => {
    if (state.shownVehicle) { state.vehicle = state.shownVehicle; setPlayerVehicle(state.vehicle); }
    state.view = state.preview;
    state.inJourney = true;
    const newCity = state.pickedCity && state.pickedCity !== state.city;
    if (newCity) setCity(state.pickedCity);
    if (!state.fromPause || newCity) resetCar();
    state.fromPause = false;
    go('drive');
  },
  paint: hex => setPaint(hex),
  preview: v => {
    state.preview = v;
    if (v === 'driver' && state.shownVehicle) setPlayerVehicle(state.shownVehicle);
    applyPreview();
  },
  resume: () => go('drive'),
  'change-vehicle': () => { state.fromPause = true; state.preview = state.view; menus.showVehicle(state.vehicle); go('vehicle'); },
  'change-city': () => { state.fromPause = true; go('city'); },
  'main-menu': () => { save(true); state.fromPause = false; refreshContinue(); go('start'); },
  mute: () => { prefs.muted = audio.toggleMute(); savePrefs(prefs); refreshPause(); },
  setting: (key, value) => {
    if (key === 'view') setView(value);
    if (key === 'quality') setQuality(value);
    if (key === 'clock') atmosphere.clock.frozen = value === 'frozen';
    if (key === 'chat') { prefs.chat = value === 'on'; savePrefs(prefs); if (!prefs.chat) chat.clear(); }
    if (key === 'collide') { prefs.collide = value === 'on'; savePrefs(prefs); }
    if (key === 'mp') { prefs.multiplayer = value === 'on'; savePrefs(prefs); mp.setEnabled(prefs.multiplayer); syncMultiplayer(); }
    refreshPause();
  },
  mutePlayer: id => { chat.setMuted(id, !chat.muted.has(id)); refreshPause(); },
  volume: v => { audio.setVolume(v); prefs.volume = v; savePrefs(prefs); },
  signIn: email => signInWithEmail(email),
  saveProfile: async p => {
    const res = await saveProfile(p);
    if (!res.error) { profile = { ...profile, ...p }; menus.setAccount(profile); go('start'); }
    return res;
  },
  'edit-profile': () => { menus.openProfile(profile, false); go('profile'); },
  'profile-cancel': () => go('start'),
  'sign-out': async () => { await save(true); await signOut(); },
});

// ---------- account ----------
let profile = null, activeUser = null;
async function enterAccount(u) {
  if (activeUser === u.id) return;
  activeUser = u.id;
  setSaveUser(u.id);
  profile = (await loadProfile()) || { display_name: null, avatar_id: null, email: u.email };
  const remote = await fetchJourney();
  mergeRemoteJourney(remote);
  const local = loadJourney();
  if (!remote && !local) { const legacy = takeLegacyJourney(); if (legacy) pushJourney(legacy, { force: true }); }
  else if (!remote && local) pushJourney(local, { force: true });
  startSession();
  menus.setAccount(profile);
  refreshContinue();
  if (!profile.display_name) { menus.openProfile(profile, true); go('profile'); } else go('start');
}
function leaveAccount() {
  activeUser = null; profile = null;
  setSaveUser(null);
  state.inJourney = false; state.fromPause = false;
  refreshContinue();
  go('auth');
}
onAuthChange(u => { if (u) enterAccount(u); else if (activeUser) leaveAccount(); });

// phones and tablets: a map button opens a small mini-map (closed by default, remembered per device)
const mapBtn = document.getElementById('map-btn');
function applyMap() {
  const open = touch.isTouch && !!prefs.map;
  document.body.classList.toggle('map-open', open);
  mapBtn.setAttribute('aria-pressed', String(open));
  mapBtn.setAttribute('aria-label', open ? 'Hide mini-map' : 'Show mini-map');
  hud.setMapActive(!touch.isTouch || open);   // not drawn while hidden: saves battery
}
mapBtn.addEventListener('click', () => { prefs.map = !prefs.map; savePrefs(prefs); applyMap(); mapBtn.blur(); });
applyMap();
document.getElementById('pause-btn').addEventListener('click', e => { e.currentTarget.blur(); if (drivingNow()) go('pause'); });
document.getElementById('fs-btn').addEventListener('click', e => { e.currentTarget.blur(); toggleFullscreen(); });

addEventListener('keydown', e => {
  const rk = { Digit5: 0, Digit6: 1, Digit7: 2, Digit8: 3, Numpad5: 0, Numpad6: 1, Numpad7: 2, Numpad8: 3 }[e.code];
  if (rk !== undefined && !e.repeat && drivingNow() && !chat.open) { react(rk); return; }
  if (chat.open) { if (e.code === 'Escape') { e.preventDefault(); chat.close(); } return; }
  if ((e.code === 'Enter' || e.code === 'NumpadEnter') && !e.repeat && chatAvailable() && !(e.target instanceof HTMLButtonElement || e.target instanceof HTMLInputElement)) { e.preventDefault(); chat.show(); return; }
  if (e.code === 'Escape' || e.code === 'KeyP') {
    if (state.screen === 'drive') { e.preventDefault(); go('pause'); }
    else if (state.screen === 'pause') { e.preventDefault(); go('drive'); }
    else if (e.code === 'Escape' && state.screen === 'vehicle') go('city');
    else if (e.code === 'Escape' && state.screen === 'city') go(state.fromPause ? 'pause' : 'start');
  } else if (e.code === 'KeyF' && !e.repeat && !(e.target instanceof HTMLInputElement)) {
    toggleFullscreen();
  } else if ((e.code === 'Enter' || e.code === 'NumpadEnter') && !e.repeat && !(e.target instanceof HTMLButtonElement || e.target instanceof HTMLInputElement)) {
    // Enter always takes the screen's main step, even when no button has focus (e.g. after clicking the scene)
    e.preventDefault();
    if (state.screen === 'start') (loadJourney() ? continueJourney : startNewJourney)();
    else if (state.screen === 'city') document.querySelector('[data-action="city-next"]').click();
    else if (state.screen === 'vehicle') { const d = document.getElementById('btn-drive'); if (!d.disabled) d.click(); }
    else if (state.screen === 'pause') go('drive');
  }
});
// save when the tab is hidden or closed
addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') save(true, true); else resumeSessionIfEnded();
});
addEventListener('pagehide', () => { mp.leave(); save(true, true); endSession('tab_closed', true); });

setQuality(prefs.quality);
setPaint(state.paint);
setSaveUser(null);
refreshContinue();
menus.show('auth');
document.body.classList.add('in-menu');
(async () => {
  const { user: u, error } = await initAuth();
  if (u) await enterAccount(u);
  else if (!configured) menus.authNotice('Sign-in is not set up yet: add your Supabase URL and key to src/config.js (see README).', 'error');
  else if (error) menus.authNotice('Can\u2019t reach the server right now. Check your connection and reload.', 'error');
})();

// dev fps counter: on for localhost or ?fps
const fpsEl = document.getElementById('fps');
const showFps = ['localhost', '127.0.0.1'].includes(location.hostname) || params.has('fps');
fpsEl.hidden = !showFps;
let frames = 0, fpsTime = 0;

// dev helpers for quick checks in the console
window.__sd = {
  mp, remote, fx, car, setDamage, atmosphere, rig, audio, state, setCity, cities,
  get harbor() { return city; }, get city() { return city; }, get traffic() { return city.trafficSys; }, menus, setView, go, save, setPlayerVehicle, turntable, renderer: world.renderer,
  get cockpit() { return cockpit; }, get model() { return model; },
  simulate(seconds, keys = {}) {
    const held = { up: 0, down: 0, left: 0, right: 0, handbrake: 0, ...keys };
    for (let i = 0; i < Math.round(seconds * 60); i++) { physicsStep(1 / 60, held); }
    return { kmh: +car.speedKmh.toFixed(1), x: +car.x.toFixed(1), z: +car.z.toFixed(1), heading: +car.heading.toFixed(2) };
  },
  tick(seconds) {
    for (let i = 0; i < Math.round(seconds * 30); i++) {
      atmosphere.update(1 / 30); model.update(car, 1 / 30); rig.update(1 / 30, car); cockpit.update(1 / 30, car, atmosphere.values);
    }
  },
};

// ---------- loop ----------
const STEP = 1 / 60;
const dashPoint = new THREE.Vector3();
const orbitTarget = new THREE.Vector3(-150, 0, -40); // waterfront side, so the bay and lighthouse drift past
const playerSmoke = { t: 0 };
let acc = 0, last = performance.now(), t = 0, orbit = 0.6, autosave = 0;
const trafficBoxes = { boxes: city.trafficSys.boxes, circles: [] };
setCity('harbor');

const collideOn = () => prefs.multiplayer !== false && prefs.collide !== false;
let crashCool = 0, repairMode = '';

/** A hit: damage, thud, camera jolt and sparks, all scaled by how hard it was. */
function crash(closing, dmg) {
  if (dmg > 0) setDamage(addDamage(car.damage, dmg));
  const k = Math.min(1, closing / 16);
  if (crashCool > 0 || closing < 2) return;
  crashCool = 0.15;
  audio.thud(k);
  rig.shake(0.05 + 0.3 * k);
  if (closing > 4) fx.sparks(car.x + car.fx * car.spec.halfLength * 0.8, (car.y || 0) + 0.5, car.z + car.fz * car.spec.halfLength * 0.8, k);
}

function physicsStep(dt, keys) {
  car.step(dt, keys);
  crashCool -= dt;
  // walls, poles, trees and traffic: always (damage from the hardest hit this step)
  const hard = Math.max(resolveCollisions(car, city.colliders), resolveCollisions(car, trafficBoxes));
  if (hard > 0) crash(hard, impactDamage(hard));
  // other drivers (peer-side: only my own car moves). Needs the toggle on, theirs too (remoteCars filters by it)
  if (collideOn()) {
    for (const o of remote.collidables()) {
      const r = collideCar(car, o);
      if (r) crash(r.closing, impactDamage(r.closing, massFactor(o.mass, car.spec.mass)));
    }
  }
  groundPose(car, city.heightAt, 1.6, 0.9, 0.25); // hills and the Metro highway; at most 0.25 m a step, so hops between levels are smooth
  // repair pads: stop on one and the damage melts away
  const pad = car.damage > 0 || repairMode ? padUnder(city.repair.pads, car.x, car.z, car.y || 0) : null;
  if (isRepairing(pad, car.speedKmh, car.damage)) { setDamage(repairStep(car.damage, dt)); repairMode = 'repairing'; }
  else repairMode = pad && car.damage > 0 ? 'pad' : '';
}

function frame(now) {
  const dt = Math.min(0.1, (now - last) / 1000);
  last = now;
  const s = state.screen;
  const live = s !== 'pause';     // pause freezes the world
  const cityLife = s === 'drive' || s === 'start' || s === 'city' || s === 'auth' || s === 'profile';

  if (live) {
    acc += dt;
    let steps = 0;
    while (acc >= STEP && steps < 5) {
      if (s === 'drive') physicsStep(STEP, input);
      if (cityLife) { city.trafficSys.step(STEP, car); city.updateSignals(STEP); }
      acc -= STEP;
      steps++;
    }
    if (steps === 5) acc = 0;
    t += dt;
    atmosphere.update(dt);
    city.update(t, { clockMinutes: atmosphere.clock.minutes, camera: world.camera, fog: world.scene.fog });
    city.trafficSys.render(dt, atmosphere.lights);
    fx.update(dt);
    city.repair.pulse(t);
    if (s === 'drive') fx.smoke(playerSmoke, dt, { x: car.x + car.fx * car.spec.halfLength * 0.6, y: (car.y || 0) + 1, z: car.z + car.fz * car.spec.halfLength * 0.6 }, car.damage);
  }

  // camera + what to render
  let renderScene = world.scene, renderCam = world.camera;
  if (s === 'start' || s === 'city' || s === 'auth' || s === 'profile') {
    orbit += dt * 0.05;
    const o = city.orbit || { radius: 120, height: 55, lookY: 0 };
    world.camera.position.set(orbitTarget.x + Math.cos(orbit) * o.radius, o.height, orbitTarget.z + Math.sin(orbit) * o.radius);
    world.camera.lookAt(orbitTarget.x, o.lookY, orbitTarget.z);
    if (world.camera.fov !== 55) { world.camera.fov = 55; world.camera.updateProjectionMatrix(); }
    model.update(car, dt);
    cockpit.setVisible(false);
    world.follow(world.camera.position.x, world.camera.position.z);
  } else if (s === 'vehicle' && state.preview === 'outside') {
    turntable.update(dt);
    renderScene = turntable.scene; renderCam = turntable.camera;
  } else {
    // drive, pause, and the driver-seat preview on Choose Vehicle
    model.update(car, dt, 1 - rig.blend);
    rig.roll = model.leanAngle || 0;
    rig.update(dt, car);
    model.setRiderVisible?.(!rig.inside);
    world.follow(car.x, car.z, car.y);
    const inside = rig.inside;
    cockpit.setVisible(inside);
    if (inside && live) { cockpit.update(dt, car, atmosphere.values); cockpit.renderMirrors(dt); }
  }
  if (s === 'drive' || s === 'pause') {
    if (Math.abs(atmosphere.lights - lastLights) > 0.02) { lastLights = atmosphere.lights; remote.setLights(lastLights); }
    remote.update(s === 'drive' ? dt : 0, { heightAt: city.heightAt, me: car, advance: s === 'drive' });
  }
  world.renderer.render(renderScene, renderCam);

  if (s === 'drive' || s === 'pause') {
    let lift = 0;
    if (state.view === 'driver' && !touch.isTouch) { // on phones the bottom corners hold the pedals instead
      dashPoint.copy(cockpit.dashEdge).applyMatrix4(model.root.matrixWorld).project(world.camera);
      const dashY = (1 - (dashPoint.y * 0.5 + 0.5)) * innerHeight;
      lift = Math.max(0, innerHeight - dashY + 12 - 32);
    }
    hud.setDamage(car.damage, repairMode);
    hud.update(dt, { clock: atmosphere.clockText, speed: car.speedKmh, car, lift, others: remote.dots() });
  }
  if (s === 'drive') {
    const w = atmosphere.values;
    audio.update({ kmh: car.speedKmh, throttle: input.up || input.down ? 1 : 0, rain: w.rain, snow: w.snow, inside: rig.blend });
    mp.sendState(car, performance.now(), { d: car.damage, c: collideOn() ? 1 : 0 });
    autosave += dt;
    if (autosave > 10) { autosave = 0; save(); }
  }

  if (showFps) {
    frames++; fpsTime += dt;
    if (fpsTime >= 0.5) { fpsEl.textContent = Math.round(frames / fpsTime) + ' fps'; frames = 0; fpsTime = 0; }
  }
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
