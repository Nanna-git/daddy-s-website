// Menu screens (DOM overlays). This file only handles the markup; main.js decides what each choice does.

import { AVATARS, avatarById } from './auth.js';

export const VEHICLES = [
  { id: 'hatchback', name: 'Hatchback', note: 'Balanced, the default pick', speed: 3, handling: 4, size: 1, ready: true },
  { id: 'sports', name: 'Sports Car', note: 'Fast and low — slides on wet and snowy roads', speed: 5, handling: 3, size: 1, ready: true },
  { id: 'suv', name: 'SUV / Jeep', note: 'Best grip in snow, high seat', speed: 3, handling: 3, size: 2, ready: true },
  { id: 'bus', name: 'City Bus', note: 'Slow, wide turns, very high seat', speed: 2, handling: 2, size: 3, ready: true },
  { id: 'moto', name: 'Motorbike', note: 'Quick and nimble, tilts into turns', speed: 4, handling: 5, size: 0, ready: true },
];

const VEHICLE_LABEL = Object.fromEntries(VEHICLES.map(v => [v.id, v.name]));

export function createMenus(h) {
  const $ = id => document.getElementById(id);
  const screens = { auth: $('scr-auth'), profile: $('scr-profile'), start: $('scr-start'), city: $('scr-city'), vehicle: $('scr-vehicle'), pause: $('scr-pause') };
  const press = (els, test) => els.forEach(b => b.setAttribute('aria-pressed', String(test(b))));
  let current = null;
  let vIndex = 0;

  // ---- generic buttons ----
  document.getElementById('menus').addEventListener('click', e => {
    const b = e.target.closest('[data-action]');
    if (b && h[b.dataset.action]) h[b.dataset.action]();
  });
  $('btn-continue').addEventListener('click', () => h.continueJourney());
  $('btn-new').addEventListener('click', () => h.newJourney());
  $('btn-start').addEventListener('click', () => h.newJourney());

  // ---- sign in + profile ----
  const authMsg = (text, kind = '') => { $('auth-msg').textContent = text; $('auth-msg').className = 'form-msg ' + kind; };
  const profMsg = (text, kind = '') => { $('profile-msg').textContent = text; $('profile-msg').className = 'form-msg ' + kind; };
  const sendBtn = $('auth-send');
  $('auth-form').addEventListener('submit', async e => {
    e.preventDefault();
    const email = $('auth-email').value.trim();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { authMsg('Enter a valid email address.', 'error'); return; }
    sendBtn.disabled = true; sendBtn.textContent = 'Signing in…'; authMsg('');
    const { error } = await h.signIn(email);
    sendBtn.disabled = false; sendBtn.textContent = 'Continue';
    if (error) authMsg(error, 'error'); // on success the account change moves us off this screen
  });

  const grid = $('avatar-grid');
  let pickedAvatar = AVATARS[0].id;
  grid.innerHTML = AVATARS.map(a => `<button type="button" role="radio" aria-checked="false" aria-label="Avatar ${a.id.slice(4)}" data-avatar="${a.id}" style="background:${a.color}">${a.emoji}</button>`).join('');
  const avatarBtns = [...grid.children];
  const pickAvatar = id => { pickedAvatar = id; avatarBtns.forEach(b => b.setAttribute('aria-checked', String(b.dataset.avatar === id))); };
  avatarBtns.forEach(b => b.addEventListener('click', () => pickAvatar(b.dataset.avatar)));
  pickAvatar(pickedAvatar);
  $('profile-form').addEventListener('submit', async e => {
    e.preventDefault();
    const name = $('profile-name').value.trim().replace(/\s+/g, ' ');
    if (name.length < 2 || name.length > 24) { profMsg('Name must be 2–24 characters.', 'error'); return; }
    $('profile-save').disabled = true; profMsg('Saving…');
    const { error } = await h.saveProfile({ display_name: name, avatar_id: pickedAvatar });
    $('profile-save').disabled = false;
    if (error) profMsg(error, 'error'); else profMsg('');
  });
  const paintAvatar = (el, id) => { const a = avatarById(id); el.textContent = a.emoji; el.style.background = a.color; };

  // ---- city ----
  const cards = [...document.querySelectorAll('.card')];
  cards.forEach(c => c.addEventListener('click', () => {
    if (c.classList.contains('locked')) return;
    press(cards, b => b === c);
    h.pickCity?.(c.dataset.city);
  }));

  // ---- vehicle ----
  const dots = $('veh-dots');
  dots.innerHTML = VEHICLES.map(() => '<span></span>').join('');
  const bar = (el, n) => { el.innerHTML = [0, 1, 2, 3, 4].map(i => `<span class="${i < n ? 'on' : ''}"></span>`).join(''); };
  function renderVehicle() {
    const v = VEHICLES[vIndex];
    $('veh-name').textContent = v.name;
    $('veh-note').textContent = v.ready ? v.note : v.note + ' · coming soon';
    [...dots.children].forEach((d, i) => d.classList.toggle('on', i === vIndex));
    dots.setAttribute('aria-label', `Vehicle ${vIndex + 1} of ${VEHICLES.length}`);
    bar($('st-speed'), v.speed); $('st-speed-n').textContent = `${v.speed} / 5`;
    bar($('st-hand'), v.handling); $('st-hand-n').textContent = `${v.handling} / 5`;
    [...$('st-size').children].forEach((s, i) => s.classList.toggle('on', i === v.size));
    $('veh-soon').hidden = !!v.ready;
    $('btn-drive').disabled = !v.ready;
    h.vehicleShown?.(v);
  }
  h.vehPrev = () => { vIndex = (vIndex + VEHICLES.length - 1) % VEHICLES.length; renderVehicle(); };
  h.vehNext = () => { vIndex = (vIndex + 1) % VEHICLES.length; renderVehicle(); };
  // data-action names use dashes
  h['veh-prev'] = h.vehPrev; h['veh-next'] = h.vehNext;
  renderVehicle();

  const swatches = [...document.querySelectorAll('#swatches button')];
  swatches.forEach(s => s.addEventListener('click', () => h.paint(s.dataset.paint)));
  const previewBtns = [...document.querySelectorAll('[data-preview]')];
  previewBtns.forEach(b => b.addEventListener('click', () => h.preview(b.dataset.preview)));

  // ---- pause ----
  const setBtns = [...document.querySelectorAll('[data-set]')];
  setBtns.forEach(b => b.addEventListener('click', () => h.setting(b.dataset.set, b.dataset.value)));
  $('pause-players-list').addEventListener('click', e => { const b = e.target.closest('[data-mute]'); if (b) h.mutePlayer?.(b.dataset.mute); });
  // Pause scrolling. Touch devices and short windows get body.pause-2col (pinned buttons, only the settings scroll);
  // everything else scrolls the whole dialog. A fade + visible scrollbar show there is more below.
  const dialogBox = document.querySelector('#scr-pause .dialog'), settingsBox = $('pause-settings'), pauseScr = $('scr-pause');
  const twoCol = () => document.body.classList.contains('pause-2col');
  const scroller = () => (twoCol() ? settingsBox : dialogBox);
  const updateCompact = () => document.body.classList.toggle('pause-2col', document.body.classList.contains('touch') || innerHeight <= 520);
  const hasMore = el => getComputedStyle(el).overflowY === 'auto' && el.scrollHeight - el.clientHeight > 4 && el.scrollHeight - el.scrollTop - el.clientHeight > 4;
  const updateMore = () => { updateCompact(); settingsBox.classList.toggle('more', hasMore(settingsBox)); dialogBox.classList.toggle('more', hasMore(dialogBox)); };
  settingsBox.addEventListener('scroll', updateMore, { passive: true });
  dialogBox.addEventListener('scroll', updateMore, { passive: true });
  addEventListener('resize', updateMore);
  updateCompact();
  // wheel anywhere on the Pause screen (dimmed background, pinned buttons…) scrolls the dialog
  pauseScr.addEventListener('wheel', e => {
    const el = scroller();
    if (el.contains(e.target)) return;                // over the scrolling part: the browser handles it
    e.preventDefault();
    el.scrollTop += e.deltaY * (e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? el.clientHeight : 1);
  }, { passive: false });
  // keyboard: arrows and Page keys scroll it even when a button has focus (the volume slider keeps its arrows)
  addEventListener('keydown', e => {
    if (current !== 'pause' || e.altKey || e.ctrlKey || e.metaKey || e.target.matches?.('input')) return;
    const el = scroller();
    const step = { ArrowDown: 48, ArrowUp: -48, PageDown: el.clientHeight * 0.85, PageUp: -el.clientHeight * 0.85 }[e.key];
    if (step !== undefined) { e.preventDefault(); el.scrollBy({ top: step }); }
    else if (e.key === 'Home' || e.key === 'End') { e.preventDefault(); el.scrollTo({ top: e.key === 'Home' ? 0 : el.scrollHeight }); }
  });
  const vol = $('vol');
  vol.addEventListener('input', () => h.volume(vol.value / 100));

  const focusFirst = el => {
    const target = el.querySelector('.btn.primary:not([hidden]):not([disabled])') || el.querySelector('button:not([hidden])');
    target?.focus({ preventScroll: true });
  };

  return {
    get screen() { return current; },
    show(name) {
      Object.entries(screens).forEach(([k, el]) => { el.hidden = k !== name; });
      document.body.classList.toggle('in-menu', !!name && name !== 'pause');
      current = name;
      if (name === 'pause') requestAnimationFrame(updateMore);
      if (name) requestAnimationFrame(() => focusFirst(screens[name]));
      else document.activeElement?.blur?.();
    },
    setContinue(summary) {
      $('btn-continue').hidden = !summary;
      $('btn-new').hidden = !summary;
      $('btn-start').hidden = !!summary;
      $('continue-summary').textContent = summary || '';
    },
    /** Account bits shown on Start and Pause. profile = { display_name, avatar_id, email } */
    setAccount(profile) {
      const name = profile?.display_name || 'there';
      $('start-name').textContent = `Hi, ${name}`;
      paintAvatar($('start-avatar'), profile?.avatar_id);
      $('pause-user').textContent = name;
      $('pause-email').textContent = profile?.email || '';
    },
    /** Open the profile form. firstTime hides Cancel (a name is required before playing). */
    openProfile(profile, firstTime) {
      $('profile-name').value = profile?.display_name || '';
      pickAvatar(profile?.avatar_id || AVATARS[0].id);
      $('profile-title').textContent = firstTime ? 'Welcome aboard' : 'Your profile';
      $('profile-cancel').hidden = !!firstTime;
      profMsg('');
    },
    authNotice(text, kind) { authMsg(text, kind); },
    setCityName(name) { $('step-city').textContent = name; },
    setCityPick(id) { press(cards, b => b.dataset.city === id); },
    setPaint(hex) {
      press(swatches, s => s.dataset.paint === hex);
      const s = swatches.find(x => x.dataset.paint === hex);
      $('paint-name').textContent = s ? s.dataset.name : '';
    },
    setPreview(view) { press(previewBtns, b => b.dataset.preview === view); },
    resetVehicle() { vIndex = 0; renderVehicle(); },
    /** Show a given vehicle (e.g. the one you are driving when you open Change Vehicle). */
    showVehicle(id) { const i = VEHICLES.findIndex(v => v.id === id); if (i >= 0) { vIndex = i; renderVehicle(); } },
    /** Pause-menu roster. info = { players: [{ shown, avatar, vehicle, self }], label, count, max, status } or null when not connected. */
    setPlayers(info, cityName, enabled, muted = new Set()) {
      const box = $('pause-players');
      if (!enabled) { box.hidden = true; $('pause-mp-note').textContent = 'Off: nothing is sent or received'; return; }
      const st = info?.status;
      $('pause-mp-note').textContent = st === 'online' ? 'See and be seen by people in your city'
        : st === 'connecting' ? 'Connecting…' : 'Offline: playing solo, reconnecting';
      box.hidden = !info || !info.players.length;
      if (box.hidden) return;
      $('pause-players-title').textContent = `In ${cityName}${info.label}`;
      $('pause-players-count').textContent = `${info.count} / ${info.max}`;
      const esc = t => String(t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
      $('pause-players-list').innerHTML = info.players.map(p => {
        const a = avatarById(p.avatar);
        return `<li class="${p.self ? 'you' : ''}"><span class="em" style="background:${a.color}">${a.emoji}</span><span class="nm">${esc(p.shown || p.name)}</span><span class="veh">${esc(VEHICLE_LABEL[p.vehicle] || '')}</span>${p.self ? '' : `<button type="button" class="mute" data-mute="${esc(p.id)}" aria-pressed="${muted.has(p.id)}" aria-label="Mute chat from ${esc(p.shown || p.name)}">${muted.has(p.id) ? 'Muted' : 'Mute'}</button>`}</li>`;
      }).join('');
    },
    setPause({ view, quality, clockFrozen, clockText, volume, muted, chips, multiplayer, collide, chat }) {
      press(setBtns.filter(b => b.dataset.set === 'mp'), b => b.dataset.value === (multiplayer ? 'on' : 'off'));
      press(setBtns.filter(b => b.dataset.set === 'collide'), b => b.dataset.value === (collide ? 'on' : 'off'));
      press(setBtns.filter(b => b.dataset.set === 'chat'), b => b.dataset.value === (chat ? 'on' : 'off'));
      press(setBtns.filter(b => b.dataset.set === 'view'), b => b.dataset.value === view);
      press(setBtns.filter(b => b.dataset.set === 'quality'), b => b.dataset.value === quality);
      press(setBtns.filter(b => b.dataset.set === 'clock'), b => b.dataset.value === (clockFrozen ? 'frozen' : 'running'));
      $('pause-clock').textContent = clockFrozen ? `Stopped at ${clockText}` : `Now ${clockText}`;
      vol.value = Math.round(volume * 100);
      const mute = document.querySelector('[data-action="mute"]');
      mute.setAttribute('aria-pressed', String(muted));
      mute.textContent = muted ? 'Muted' : 'Mute';
      $('pause-chips').innerHTML = chips.map(c => `<span>${c}</span>`).join('');
    },
  };
}
