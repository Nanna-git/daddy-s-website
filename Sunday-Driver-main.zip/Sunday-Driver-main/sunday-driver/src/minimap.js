// Round mini-map: top-down roads, water, park and landmark of the current city; coral player arrow; north up (north = −Z).

const SCALE = 0.42;  // px per metre at 196 px → about 230 m radius

export function createMinimap(canvas) {
  const dpr = Math.min(devicePixelRatio || 1, 2);
  const size = canvas.clientWidth || 196;
  canvas.width = size * dpr; canvas.height = size * dpr;
  const ctx = canvas.getContext('2d');
  const R = size / 2;
  let acc = 1, M = null, active = true;

  return {
    /** The city to draw (its mapInfo). */
    setInfo(info) { M = info; acc = 1; },
    /** False while the map is hidden (phones): skip redrawing. */
    setActive(v) { active = !!v; acc = 1; },
    update(dt, car, others = []) {
      if (!M || !active) return;
      acc += dt;
      if (acc < 1 / 20) return; // 20 fps is plenty
      acc = 0;
      const s = SCALE;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, size, size);
      ctx.fillStyle = '#13203A';
      ctx.fillRect(0, 0, size, size);

      // world → map: x right, z down (so −Z is up), centred on the car
      ctx.setTransform(dpr * s, 0, 0, dpr * s, dpr * (R - s * car.x), dpr * (R - s * car.z));
      const rect = (r, color) => { if (r) { ctx.fillStyle = color; ctx.fillRect(r.minX, r.minZ, r.maxX - r.minX, r.maxZ - r.minZ); } };
      rect({ minX: -M.edge, maxX: M.edge, minZ: -M.edge, maxZ: M.edge }, '#2B3A57');  // city blocks
      rect(M.water, '#1E6FB4');
      rect(M.park, '#3D7A52');
      rect(M.pond, '#1E6FB4');
      rect(M.pier, '#B98A5E');
      ctx.strokeStyle = '#6E7C96';
      ctx.lineWidth = M.roadHalf * 2;
      ctx.beginPath();
      for (const L of M.lines) {
        ctx.moveTo(L, -M.edge + 6); ctx.lineTo(L, M.edge - 6);
        ctx.moveTo(-M.edge + 6, L); ctx.lineTo(M.edge - 6, L);
      }
      ctx.stroke();
      if (M.highway) { // elevated loop, drawn as a thin orange outline over the roads
        const h = M.highway;
        ctx.strokeStyle = '#F2A65A'; ctx.lineWidth = 5;
        ctx.strokeRect(-h, -h, h * 2, h * 2);
      }
      if (M.ramps) for (const r of M.ramps) rect(r, '#F2A65A');
      ctx.fillStyle = M.landmark.color;
      ctx.beginPath(); ctx.arc(M.landmark.x, M.landmark.z, 9, 0, Math.PI * 2); ctx.fill();

      // repair pads: green discs
      for (const p of M.pads || []) {
        if (Math.abs(p.x - car.x) > R / s + 12 || Math.abs(p.z - car.z) > R / s + 12) continue;
        ctx.fillStyle = '#2FD4A2'; ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 1.4 / s;
        ctx.beginPath(); ctx.arc(p.x, p.z, 8 / s * 0.9, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
        ctx.fillStyle = '#0E3B2E'; ctx.fillRect(p.x - 1.6 / s, p.z - 5 / s, 3.2 / s, 10 / s); ctx.fillRect(p.x - 5 / s, p.z - 1.6 / s, 10 / s, 3.2 / s);
      }

      // other drivers: a dot in their avatar colour (only those within the map's reach)
      for (const o of others) {
        if (Math.abs(o.x - car.x) > R / s || Math.abs(o.z - car.z) > R / s) continue;
        ctx.fillStyle = o.color; ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 1.6 / s;
        ctx.beginPath(); ctx.arc(o.x, o.z, 6 / s, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      }

      // player arrow, always at the centre
      ctx.setTransform(dpr, 0, 0, dpr, dpr * R, dpr * R);
      ctx.rotate(Math.atan2(car.fx, -car.fz));
      ctx.beginPath();
      ctx.moveTo(0, -12); ctx.lineTo(9, 10); ctx.lineTo(0, 5); ctx.lineTo(-9, 10); ctx.closePath();
      ctx.fillStyle = '#FF6A4D'; ctx.fill();
      ctx.lineWidth = 2; ctx.lineJoin = 'round'; ctx.strokeStyle = '#FFFFFF'; ctx.stroke();
    },
  };
}
