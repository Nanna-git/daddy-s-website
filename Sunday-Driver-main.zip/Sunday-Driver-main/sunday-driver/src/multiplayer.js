// Multiplayer: live ghost cars over Supabase Realtime (Broadcast for state, Presence for who is here).
// One channel per city instance ("harbor-1", "harbor-2"…), 12 players each. Strictly additive: if the SDK, the
// network or the config is missing, every call is a harmless no-op and the game stays single-player.
import { SUPABASE_URL, SUPABASE_ANON_KEY, CONFIGURED } from './config.js';
import { cleanText, canSendNow, PHRASES } from './chatCore.js';

export const MAX_PLAYERS = 12;
export const SEND_MS = 200;          // ~5 Hz
export const SILENT_MS = 5000;       // a car that sends nothing for this long is removed
export const REACTIONS = ['👋', '😀', '👍', '❤️'];
export const REACTION_COOLDOWN_MS = 2000;
const SDK_URL = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.110.9/+esm';
const MAX_INSTANCES = 20;

// ---------- pure helpers (unit-tested in tests/multiplayer.test.mjs) ----------

/** Players in join order (oldest first, ties broken by key) so every client agrees on the same order. */
export function joinOrder(list) {
  return [...list].sort((a, b) => (a.joinedAt - b.joinedAt) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
}

/** My 1-based place in the instance; above MAX_PLAYERS means it is full and I should try the next copy. */
export function rankOf(list, myId) {
  return joinOrder(list).findIndex(p => p.id === myId) + 1;
}

/** Same display name twice in one instance: the later joiner becomes "Sam #2", the next "Sam #3". Returns Map id → shown name. */
export function uniqueNames(list) {
  const seen = new Map(), out = new Map();
  for (const p of joinOrder(list)) {
    const base = (p.name || 'Driver').trim() || 'Driver';
    const key = base.toLowerCase();
    const n = (seen.get(key) || 0) + 1;
    seen.set(key, n);
    out.set(p.id, n === 1 ? base : `${base} #${n}`);
  }
  return out;
}

export const instanceName = (cityId, n) => `${cityId}-${n}`;
export const instanceLabel = n => (n > 1 ? ` ${n}` : '');

// ---------- the live connection ----------

export function createMultiplayer({ identity, onRoster, onState, onReaction, onChat, onStatus } = {}) {
  let enabled = true;
  let client = null, clientPromise = null;
  let channel = null;
  let joining = 0;                  // bumps on every join/leave so a stale async attempt can tell it was cancelled
  let want = null;                  // { city, vehicle, paint } while we should be connected
  let status = 'off';               // off | connecting | online | offline
  const myId = crypto.randomUUID();
  let joinedAt = Date.now();
  let instance = 0, roster = [], names = new Map();
  let lastSend = 0, lastReaction = 0, lastChat = -1e9, retryTimer = 0;

  const setStatus = s => { if (s !== status) { status = s; onStatus?.(s); } };

  async function getClient() {
    if (!CONFIGURED) return null;
    if (client) return client;
    clientPromise ||= import(SDK_URL).then(m => {
      client = m.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, { realtime: { params: { eventsPerSecond: 20 } }, auth: { persistSession: false, autoRefreshToken: false } });
      return client;
    }).catch(e => { console.warn('[multiplayer] could not load the Supabase SDK:', e?.message || e); clientPromise = null; return null; });
    return clientPromise;
  }

  const me = () => {
    const id = identity();
    return { name: id?.name || 'Driver', avatar: id?.avatar || 'car-1', vehicle: want.vehicle, paint: want.paint, joinedAt };
  };

  function readRoster() {
    if (!channel) return [];
    const st = channel.presenceState();
    const list = [];
    for (const [key, metas] of Object.entries(st)) {
      const m = metas[metas.length - 1];
      if (m) list.push({ id: key, name: String(m.name || 'Driver').slice(0, 24), avatar: m.avatar, vehicle: m.vehicle, paint: m.paint, joinedAt: +m.joinedAt || 0 });
    }
    return list;
  }

  function publishRoster() {
    roster = readRoster();
    names = uniqueNames(roster);
    onRoster?.({
      players: roster.map(p => ({ ...p, shown: names.get(p.id), self: p.id === myId })),
      instance, label: want ? instanceLabel(instance) : '', count: roster.length, max: MAX_PLAYERS, status,
    });
  }

  async function dropChannel() {
    const ch = channel; channel = null; roster = []; names = new Map();
    if (ch && client) { try { await client.removeChannel(ch); } catch { /* already gone */ } }
  }

  /** Try instance n of the city; resolves 'ok', 'full' or 'error'. */
  function tryInstance(token, n) {
    return new Promise(resolve => {
      const ch = client.channel(`sd-${instanceName(want.city, n)}`, { config: { broadcast: { self: false }, presence: { key: myId } } });
      channel = ch; instance = n;
      let settled = false;
      const done = r => { if (!settled) { settled = true; resolve(r); } };
      ch.on('presence', { event: 'sync' }, () => { if (channel === ch) publishRoster(); });
      ch.on('broadcast', { event: 'p' }, ({ payload }) => { if (channel === ch && payload?.id && payload.id !== myId) onState?.(payload); });
      ch.on('broadcast', { event: 'r' }, ({ payload }) => { if (channel === ch && payload?.id && payload.id !== myId) onReaction?.(payload); });
      ch.on('broadcast', { event: 'c' }, ({ payload }) => { if (channel === ch && payload?.id && payload.id !== myId) onChat?.(payload); });
      ch.subscribe(async (s, err) => {
        if (s !== 'SUBSCRIBED') console.warn('[multiplayer] channel', instanceName(want?.city, n), s, err?.message || err || '');
        if (token !== joining || channel !== ch) { done('error'); return; }
        if (s === 'SUBSCRIBED') {
          try { await ch.track(me()); } catch { done('error'); return; }
          setTimeout(() => { // give Presence a moment to deliver who was here first
            if (token !== joining || channel !== ch) { done('error'); return; }
            done(rankOf(readRoster(), myId) > MAX_PLAYERS ? 'full' : 'ok');
          }, 700);
        } else if (s === 'CHANNEL_ERROR' || s === 'TIMED_OUT') {
          if (!settled) done('error'); else if (token === joining) { setStatus('offline'); scheduleRetry(); }
        } else if (s === 'CLOSED' && settled && token === joining) { setStatus('offline'); scheduleRetry(); }
      });
    });
  }

  function scheduleRetry() {
    clearTimeout(retryTimer);
    if (!want || !enabled) return;
    retryTimer = setTimeout(() => { if (want && enabled) connect(); }, 4000);
  }

  async function connect() {
    const token = ++joining;
    clearTimeout(retryTimer);
    await dropChannel();
    if (!want || !enabled) { setStatus('off'); publishRoster(); return; }
    setStatus('connecting');
    const c = await getClient();
    if (token !== joining) return;
    if (!c) { setStatus('offline'); publishRoster(); scheduleRetry(); return; }
    joinedAt = Date.now();
    for (let n = 1; n <= MAX_INSTANCES; n++) {
      const r = await tryInstance(token, n);
      if (token !== joining) return;
      if (r === 'ok') { setStatus('online'); publishRoster(); return; }
      await dropChannel();
      if (token !== joining) return;
      if (r === 'error') { setStatus('offline'); publishRoster(); scheduleRetry(); return; }
      // 'full': try the next copy of this city
    }
    setStatus('offline'); publishRoster();
  }

  return {
    myId,
    get status() { return status; },
    get enabled() { return enabled; },
    get connected() { return status === 'online' && !!channel; },
    displayName: id => names.get(id),
    /** Turn multiplayer on or off. Off means nothing is sent or received. */
    setEnabled(v) {
      enabled = !!v;
      if (!enabled) { joining++; clearTimeout(retryTimer); dropChannel(); setStatus('off'); publishRoster(); }
      else if (want) connect();
    },
    /** Be present in this city with this look (call again when the city, vehicle or paint changes). */
    join(city, vehicle, paint) {
      const cityChanged = !want || want.city !== city;
      want = { city, vehicle, paint };
      if (!enabled) return;
      if (cityChanged || (!channel && status !== 'connecting')) connect();
      else if (channel && status === 'online') channel.track(me()).catch(() => {});
    },
    /** Stop broadcasting (menus, pause, sign-out): leaves the channel so others see you go. */
    leave() {
      want = null; joining++; clearTimeout(retryTimer);
      dropChannel(); setStatus('off'); publishRoster();
    },
    /** Send my car at ~5 Hz. car: { x, y, z, heading, vF, steer }; extra: { d: damage %, c: 1 if I collide with others } */
    sendState(car, now = performance.now(), extra = {}) {
      if (!channel || status !== 'online' || now - lastSend < SEND_MS) return;
      lastSend = now;
      channel.send({ type: 'broadcast', event: 'p', payload: {
        id: myId, x: +car.x.toFixed(2), y: +(car.y || 0).toFixed(2), z: +car.z.toFixed(2),
        h: +car.heading.toFixed(3), v: +car.vF.toFixed(2), s: +car.steer.toFixed(3),
        d: Math.round(extra.d || 0), c: extra.c === 0 ? 0 : 1,
      } }).catch(() => {});
    },
    /** index into REACTIONS; false if on cooldown or offline */
    sendReaction(index, now = performance.now()) {
      if (!channel || status !== 'online' || !REACTIONS[index] || now - lastReaction < REACTION_COOLDOWN_MS) return false;
      lastReaction = now;
      channel.send({ type: 'broadcast', event: 'r', payload: { id: myId, i: index } }).catch(() => {});
      return true;
    },
    /** Chat: { t: text } or { q: phrase index }. Returns 'ok', 'cooldown', 'empty' or 'offline'. */
    sendChat(msg, now = performance.now()) {
      if (!channel || status !== 'online') return 'offline';
      const payload = { id: myId };
      if (Number.isInteger(msg?.q)) { if (!PHRASES[msg.q]) return 'empty'; payload.q = msg.q; }
      else { const t = cleanText(msg?.t); if (!t) return 'empty'; payload.t = t; }
      if (!canSendNow(lastChat, now)) return 'cooldown';
      lastChat = now;
      channel.send({ type: 'broadcast', event: 'c', payload }).catch(() => {});
      return 'ok';
    },
    chatReady: (now = performance.now()) => canSendNow(lastChat, now),
    reactionReady: (now = performance.now()) => now - lastReaction >= REACTION_COOLDOWN_MS,
  };
}
