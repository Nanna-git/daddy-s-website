// Remote players: ghost cars (no collision) that glide between ~5 Hz updates, each with a name tag
// (avatar emoji + name, fades with distance) and a floating reaction. Tags are DOM elements projected every frame.
import * as THREE from 'three';
import { buildVehicle, PAINTS } from './vehicles/hatchback.js';
import { VEHICLES } from './vehicles/specs.js';
import { avatarById } from './auth.js';
import { REACTIONS, SILENT_MS } from './multiplayer.js';
import { TAG_RANGE, REACTION_MS, angleDiff, tagOpacity, predict } from './remoteMath.js';
import { SAY_MS } from './chatCore.js';
import { tintPaint, SMOKE_FROM, DEFAULT_MASS } from './damage.js';

export { TAG_RANGE, REACTION_MS };
const SNAP_DIST = 30;                // farther off than this: jump, don't glide
const COLLIDE_FRESH = 1.0;           // s: a car must have sent something this recently to bump into you
const SMOKE_CARS = 4;                // only the nearest damaged cars smoke (keeps phones smooth)
const PAINT_STEP = 4;                // % of damage per visible paint shade

export function createRemoteCars({ scene, camera, tagsEl, fx = null }) {
  const cars = new Map();   // id → entry
  const proj = new THREE.Vector3();
  let clock = 0, shown = true, lights = 0;

  function makeTag(entry) {
    const el = document.createElement('div');
    el.className = 'mp-tag';
    el.innerHTML = '<span class="mp-say" aria-hidden="true"></span><span class="mp-react" aria-hidden="true"></span><span class="mp-chip"><span class="mp-em"></span><span class="mp-nm"></span></span>';
    tagsEl.appendChild(el);
    entry.tag = el; entry.emEl = el.querySelector('.mp-em'); entry.nmEl = el.querySelector('.mp-nm'); entry.reactEl = el.querySelector('.mp-react'); entry.sayEl = el.querySelector('.mp-say');
    entry.chipEl = el.querySelector('.mp-chip');
  }

  function buildModel(entry) {
    entry.model?.dispose();
    const def = VEHICLES[entry.vehicle] || VEHICLES.hatchback;
    entry.model = buildVehicle(def, shownPaint(entry), { headlightBeam: false, shadows: false });
    entry.model.setLights(lights);
    entry.model.root.visible = false;
    scene.add(entry.model.root);
    const box = new THREE.Box3().setFromObject(entry.model.root);
    entry.tagHeight = Math.max(1.4, box.max.y - box.min.y) + 0.7;
    entry.builtVehicle = entry.vehicle; entry.builtPaint = shownPaint(entry);
    const spec = def.physics;
    Object.assign(entry.col, { hw: spec.halfWidth, hl: spec.halfLength, mass: spec.mass || DEFAULT_MASS });
  }

  /** The paint a car is drawn in: its own colour, darkened by its damage in a few steps. */
  function shownPaint(e) { return tintPaint(e.paint, Math.round((e.damage || 0) / PAINT_STEP) * PAINT_STEP); }
  function refreshPaint(e) {
    if (!e.model) return;
    const p = shownPaint(e);
    if (e.builtPaint !== p) { e.model.setPaint(p); e.builtPaint = p; }
  }

  function remove(id) {
    const e = cars.get(id);
    if (!e) return;
    e.model?.dispose();
    e.tag?.remove();
    cars.delete(id);
  }

  return {
    /** Roster from multiplayer.js: [{ id, shown, avatar, vehicle, paint, self }] */
    setRoster(players) {
      const keep = new Set();
      for (const p of players) {
        if (p.self) continue;
        keep.add(p.id);
        let e = cars.get(p.id);
        if (!e) { e = { id: p.id, state: null, lastMsg: -1e9, react: null, cur: null, prevH: 0, damage: 0, smoke: { t: 0 }, col: { x: 0, y: 0, z: 0, heading: 0, vx: 0, vz: 0, hw: 0.9, hl: 2, mass: DEFAULT_MASS, armed: false, collides: true } }; cars.set(p.id, e); makeTag(e); }
        e.vehicle = VEHICLES[p.vehicle] ? p.vehicle : 'hatchback';
        e.paint = typeof p.paint === 'string' && /^#[0-9a-f]{6}$/i.test(p.paint) ? p.paint : PAINTS.coral;
        const av = avatarById(p.avatar);
        e.emEl.textContent = av.emoji; e.nmEl.textContent = p.shown || p.name; e.chipEl.style.setProperty('--c', av.color);
        e.color = av.color;
        if (e.model && e.builtVehicle !== e.vehicle) buildModel(e);
        else refreshPaint(e);
      }
      for (const id of [...cars.keys()]) if (!keep.has(id)) remove(id);
    },
    /** A position message from someone in the roster. */
    onState(m) {
      const e = cars.get(m.id);
      if (!e || ![m.x, m.z, m.h, m.v].every(Number.isFinite)) return;
      e.state = { x: m.x, y: Number.isFinite(m.y) ? m.y : 0, z: m.z, h: m.h, v: m.v, s: Number.isFinite(m.s) ? m.s : 0 };
      e.damage = Number.isFinite(m.d) ? Math.min(100, Math.max(0, m.d)) : 0;
      e.col.collides = m.c !== 0;
      refreshPaint(e);
      e.lastMsg = clock;
      if (!e.model) buildModel(e);
    },
    onReaction(m) {
      const e = cars.get(m.id);
      if (!e || !REACTIONS[m.i]) return;
      e.react = { text: REACTIONS[m.i], until: clock + REACTION_MS / 1000 };
    },
    /** A quick phrase from someone: a short bubble over their car. */
    onPhrase(id, text) {
      const e = cars.get(id);
      if (e) e.say = { text, until: clock + SAY_MS / 1000 };
    },
    /** Cars my car can bump into right now (updated each frame): only ones that are driving, close to live, and opted in. */
    collidables() {
      const out = [];
      for (const e of cars.values()) {
        const c = e.col;
        if (!shown || !e.cur || !e.model?.root.visible || clock - e.lastMsg > COLLIDE_FRESH || !c.collides) { c.armed = false; continue; }
        c.x = e.cur.x; c.y = e.cur.y; c.z = e.cur.z; c.heading = e.cur.heading;
        c.vx = Math.sin(e.cur.heading) * e.cur.vF; c.vz = Math.cos(e.cur.heading) * e.cur.vF;
        out.push(c);
      }
      return out;
    },
    setLights(v) { lights = v; cars.forEach(e => e.model?.setLights(v)); },
    /** Hide everything (toggle off, menus). */
    setVisible(v) { shown = v; if (!v) cars.forEach(e => { if (e.model) e.model.root.visible = false; e.tag.style.opacity = 0; }); },
    clear() { [...cars.keys()].forEach(remove); },
    /** Positions for the mini-map: [{ x, z, color }] of cars that are currently drawn. */
    dots() {
      const out = [];
      for (const e of cars.values()) if (e.cur && e.model?.root.visible) out.push({ x: e.cur.x, z: e.cur.z, color: e.color });
      return out;
    },
    count: () => [...cars.values()].filter(e => e.model?.root.visible).length,
    /** dt = 0 while paused (silence timers freeze). me = the player's car, for distance fading. */
    update(dt, { heightAt, me, advance = true } = {}) {
      if (advance) clock += dt;
      const w = innerWidth, h = innerHeight;
      for (const e of cars.values()) {
        const fresh = shown && e.state && clock - e.lastMsg < SILENT_MS / 1000;
        if (!e.model) { e.tag.style.opacity = 0; continue; }
        const root = e.model.root;
        if (!fresh) { root.visible = false; e.tag.style.opacity = 0; e.col.armed = false; continue; }
        const st = e.state, age = clock - e.lastMsg;
        const tgt = predict({ x: st.x, z: st.z, h: st.h, v: st.v }, age);
        if (!e.cur || !root.visible || Math.hypot(tgt.x - e.cur.x, tgt.z - e.cur.z) > SNAP_DIST) {
          e.cur = { x: tgt.x, y: st.y, z: tgt.z, heading: st.h, vF: st.v, steer: st.s, pitch: 0, bank: 0, latAccel: 0, longAccel: 0 };
          e.prevH = st.h;
          e.col.armed = false;   // just appeared or jumped: pass through until we have been apart once
        } else if (dt > 0) {
          const k = 1 - Math.exp(-8 * dt);
          e.cur.x += (tgt.x - e.cur.x) * k;
          e.cur.z += (tgt.z - e.cur.z) * k;
          e.cur.y += (st.y - e.cur.y) * k;
          e.cur.heading += angleDiff(e.cur.heading, st.h) * k;
          e.cur.vF += (st.v - e.cur.vF) * k;
          e.cur.steer += (st.s - e.cur.steer) * k;
          const yawRate = angleDiff(e.prevH, e.cur.heading) / dt;
          e.cur.latAccel += (THREE.MathUtils.clamp(yawRate * e.cur.vF, -8, 8) - e.cur.latAccel) * k;
          e.prevH = e.cur.heading;
        }
        if (heightAt) { // slopes and the Metro highway: keep the car on the ground it is on
          const y0 = e.cur.y;
          const hh = heightAt(e.cur.x, e.cur.z, y0);
          if (Number.isFinite(hh) && Math.abs(hh - y0) < 6) e.cur.y = hh;
          const fx = Math.sin(e.cur.heading), fz = Math.cos(e.cur.heading);
          const at = (x, z) => heightAt(x, z, e.cur.y);
          e.cur.pitch = -Math.atan((at(e.cur.x + fx * 1.6, e.cur.z + fz * 1.6) - at(e.cur.x - fx * 1.6, e.cur.z - fz * 1.6)) / 3.2) || 0;
          e.cur.bank = Math.atan((at(e.cur.x + fz * 0.9, e.cur.z - fx * 0.9) - at(e.cur.x - fz * 0.9, e.cur.z + fx * 0.9)) / 1.8) || 0;
        }
        e.model.update(e.cur, dt || 1e-3);
        root.visible = true;

        // name tag + reaction
        const dist = me ? Math.hypot(e.cur.x - me.x, e.cur.z - me.z) : 0;
        let op = tagOpacity(dist);
        if (op > 0) {
          proj.set(e.cur.x, e.cur.y + e.tagHeight, e.cur.z).project(camera);
          if (proj.z > 1 || Math.abs(proj.x) > 1.1 || Math.abs(proj.y) > 1.1) op = 0;
          else e.tag.style.transform = `translate(${((proj.x * 0.5 + 0.5) * w).toFixed(1)}px, ${((1 - (proj.y * 0.5 + 0.5)) * h).toFixed(1)}px) translate(-50%, -100%)`;
        }
        e.tag.style.opacity = op.toFixed(2);
        const r = e.react && clock < e.react.until ? e.react : null;
        const text = r && dist < TAG_RANGE ? r.text : '';
        if (e.reactEl.textContent !== text) e.reactEl.textContent = text;
        const sy = e.say && clock < e.say.until && dist < TAG_RANGE ? e.say.text : '';
        if (e.sayEl.textContent !== sy) e.sayEl.textContent = sy;
        if (r && text) e.reactEl.style.setProperty('--t', String(1 - (r.until - clock) / (REACTION_MS / 1000)));
      }
      if (fx && advance && dt > 0 && me) { // smoke from the nearest few badly damaged cars
        const hurt = [];
        for (const e of cars.values()) if (e.cur && e.model?.root.visible && e.damage >= SMOKE_FROM) hurt.push([Math.hypot(e.cur.x - me.x, e.cur.z - me.z), e]);
        hurt.sort((a, b) => a[0] - b[0]);
        hurt.slice(0, SMOKE_CARS).forEach(([d, e]) => {
          const hl = e.col.hl, c = e.cur;
          if (d < 120) fx.smoke(e.smoke, dt, { x: c.x + Math.sin(c.heading) * hl * 0.6, y: c.y + 1, z: c.z + Math.cos(c.heading) * hl * 0.6 }, e.damage);
        });
      }
    },
  };
}
