// Pure math for remote cars (no browser or three.js needed, so it is unit-tested in node).
export const TAG_FADE_START = 100;   // metres: tag starts to fade
export const TAG_RANGE = 150;        // metres: tag and reactions hidden beyond this
export const REACTION_MS = 3000;
const EXTRAPOLATE_MAX = 0.4;         // seconds of dead-reckoning past the last update

// ---------- pure helpers (unit-tested) ----------
export function angleDiff(a, b) { // shortest signed turn from a to b, radians
  let d = (b - a) % (Math.PI * 2);
  if (d > Math.PI) d -= Math.PI * 2;
  if (d < -Math.PI) d += Math.PI * 2;
  return d;
}
/** 1 close, falling to 0 at TAG_RANGE. */
export function tagOpacity(dist) {
  if (dist >= TAG_RANGE) return 0;
  if (dist <= TAG_FADE_START) return 1;
  return 1 - (dist - TAG_FADE_START) / (TAG_RANGE - TAG_FADE_START);
}
/** Where a remote car should be drawn: its last update, carried forward along its heading by `age` seconds. */
export function predict(msg, age) {
  const t = Math.min(Math.max(age, 0), EXTRAPOLATE_MAX);
  return { x: msg.x + Math.sin(msg.h) * msg.v * t, z: msg.z + Math.cos(msg.h) * msg.v * t };
}

