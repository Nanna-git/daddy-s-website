// Repair pads: a marked ring on the road with a small canopy. Park on one (nearly stopped) and the damage melts away.
// Non-colliding. Pads sit mid-block on ground-level roads (never under Metro's highway).
import * as THREE from 'three';
import { REPAIR_RADIUS } from './damage.js';

export const REPAIR_PADS = {
  harbor: [[-120, -160], [160, 40], [0, 120]],
  metro: [[0, -120], [80, 40], [-120, 0]],
  mountain: [[-200, 80], [80, 120], [0, -200]],
};
const TEAL = '#2FD4A2';

/** Build the pad visuals into `parent`; returns the pads as [{ x, z, y }] for the repair check and the mini-map. */
export function createRepairPads(parent, cityId, heightAt) {
  const pads = [];
  const ringMat = new THREE.MeshBasicMaterial({ color: TEAL, transparent: true, opacity: 0.9, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -2 });
  const discMat = new THREE.MeshBasicMaterial({ color: TEAL, transparent: true, opacity: 0.22, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -1 });
  const white = new THREE.MeshLambertMaterial({ color: '#F4F6F8', flatShading: true });
  const stripe = new THREE.MeshBasicMaterial({ color: TEAL });
  const post = new THREE.BoxGeometry(0.28, 4.3, 0.28), roof = new THREE.BoxGeometry(10.6, 0.3, 10.6), bar = new THREE.BoxGeometry(10.7, 0.12, 0.5);
  const h = (x, z) => (heightAt ? heightAt(x, z, 0) : 0);

  for (const [x, z] of REPAIR_PADS[cityId] || []) {
    const y0 = h(x, z), g = new THREE.Group();
    g.position.set(x, y0, z);
    const drape = geo => { // lay a flat ring/disc on the ground: every vertex follows the slope
      geo.rotateX(-Math.PI / 2);
      const p = geo.attributes.position;
      for (let i = 0; i < p.count; i++) p.setY(i, h(x + p.getX(i), z + p.getZ(i)) - y0 + 0.12);
      return geo;
    };
    g.add(new THREE.Mesh(drape(new THREE.CircleGeometry(REPAIR_RADIUS - 0.8, 40)), discMat));
    g.add(new THREE.Mesh(drape(new THREE.RingGeometry(REPAIR_RADIUS - 0.8, REPAIR_RADIUS, 40)), ringMat));
    for (const [px, pz] of [[-4.9, -4.9], [4.9, -4.9], [-4.9, 4.9], [4.9, 4.9]]) {
      const m = new THREE.Mesh(post, white);
      m.position.set(px, h(x + px, z + pz) - y0 + 2.15, pz); g.add(m);
    }
    const r = new THREE.Mesh(roof, white); r.position.y = 4.45; g.add(r);
    for (const s of [-1, 1]) { const b = new THREE.Mesh(bar, stripe); b.position.set(0, 4.5, s * 5.3); g.add(b); const b2 = b.clone(); b2.rotation.y = Math.PI / 2; b2.position.set(s * 5.3, 4.5, 0); g.add(b2); }
    parent.add(g);
    pads.push({ x, z, y: y0 });
  }
  return { pads, pulse(t) { ringMat.opacity = 0.65 + 0.3 * Math.sin(t * 3); } };
}
