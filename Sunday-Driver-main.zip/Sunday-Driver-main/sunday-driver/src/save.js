// Journey memory (Reference I): one save in localStorage. Every read and write is guarded,
// so a blocked or empty storage just means "no saved journey".
const LEGACY_KEY = 'sundayDriver.journey.v1'; // the old anonymous save, adopted once by the first account that has none
let KEY = LEGACY_KEY;                           // becomes 'sundayDriver.journey.v1.<userId>' once someone signs in
const PREFS = 'sundayDriver.prefs.v1'; // quality / volume / mute survive "New journey"

export const CITY_NAMES = { harbor: 'Harbor Town', metro: 'Metro Downtown', mountain: 'Mountain Village' };
export const VEHICLE_NAMES = { hatchback: 'Hatchback', sports: 'Sports Car', suv: 'SUV / Jeep', bus: 'City Bus', moto: 'Motorbike' };
export const WEATHER_NAMES = { sunny: 'Sunny', cloudy: 'Cloudy', rainy: 'Rainy', snowy: 'Snowy' };

function read(key) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}
function write(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch { return false; }
}

/** Point journey storage at one account (or back at nothing when signed out). */
export function setSaveUser(userId) { KEY = userId ? `${LEGACY_KEY}.${userId}` : `${LEGACY_KEY}.signed-out`; }

/** Take the database copy if it is newer than this browser's copy (or the only one). */
export function mergeRemoteJourney(remote) {
  if (!remote || !remote.pos || !CITY_NAMES[remote.city]) return;
  const local = read(KEY);
  if (!local || !local.savedAt || (remote.savedAt && remote.savedAt > local.savedAt)) write(KEY, remote);
}

/** One-time: if this account has no journey anywhere, hand back the old anonymous one (and remove it). */
export function takeLegacyJourney() {
  const legacy = read(LEGACY_KEY);
  if (!legacy || !legacy.pos || !CITY_NAMES[legacy.city]) return null;
  try { localStorage.removeItem(LEGACY_KEY); } catch { /* storage blocked */ }
  write(KEY, legacy);
  return legacy;
}

export function loadJourney() {
  const j = read(KEY);
  if (!j || typeof j !== 'object' || !j.pos || !CITY_NAMES[j.city]) return null;
  return j;
}

/** Saves in this browser and returns the saved object (so it can also go to the database). */
export function saveJourney(j) { const saved = { ...j, savedAt: new Date().toISOString() }; write(KEY, saved); return saved; }

export function clearJourney() { try { localStorage.removeItem(KEY); } catch { /* storage blocked */ } }

/** defaults: e.g. { quality: 'low' } on phones; anything the player saved wins */
export function loadPrefs(defaults = {}) {
  return { quality: 'high', volume: 0.8, muted: false, multiplayer: true, collide: true, chat: true, map: false, ...defaults, ...(read(PREFS) || {}) };
}
export function savePrefs(p) { write(PREFS, p); }

export function journeySummary(j) {
  return [CITY_NAMES[j.city], VEHICLE_NAMES[j.vehicle] || 'Hatchback', WEATHER_NAMES[j.weather] || 'Sunny', j.clock].filter(Boolean).join(' · ');
}
