// Combines weather (what the sky is doing) with the clock (what time it is) into one look per frame,
// then hands it to the sky/lights, the city, clouds, particles and the car.
import * as THREE from 'three';
import { WeatherBlend } from './weather.js';
import { GameClock } from './daynight.js';

const SUN_WARM = new THREE.Color('#FFE27A'), SUN_LOW = new THREE.Color('#FF9E6B'), MOON = new THREE.Color('#AFC3E8');
const clamp01 = v => Math.min(1, Math.max(0, v));

export function createAtmosphere({ world, harbor, car, model, clouds, particles, weather = 'sunny', clock = '10:00' }) {
  const blend = new WeatherBlend(weather);
  const time = new GameClock();
  time.set(clock);

  const L = {
    sky: new THREE.Color(), horizon: new THREE.Color(), fog: new THREE.Color(),
    hemiSky: new THREE.Color(), hemiGround: new THREE.Color(), lightColor: new THREE.Color(), sunDiscColor: new THREE.Color(),
    lightDir: new THREE.Vector3(), sunDir: new THREE.Vector3(), moonDir: new THREE.Vector3(),
    fogNear: 60, fogFar: 220, hemiIntensity: 1, lightIntensity: 1, shadow: 1, sunDiscOpacity: 1, moonDiscOpacity: 0,
  };
  const cloudColor = new THREE.Color();
  const tinted = (out, c, d, k = 1) => out.copy(c).lerp(d.tint, d.amount * k);
  let lights = 0;

  function update(dt) {
    time.advance(dt);
    const w = blend.update(dt);
    const d = time.sample();

    tinted(L.sky, w.sky, d);
    tinted(L.horizon, w.horizon, d);
    tinted(L.fog, w.fog, d);
    tinted(L.hemiSky, w.hemiSky, d);
    tinted(L.hemiGround, w.hemiGround, d, 0.8);
    L.fogNear = w.fogNear;
    L.fogFar = w.fogFar * (0.8 + 0.2 * d.daylight);
    L.hemiIntensity = w.hemiIntensity * (0.3 + 0.7 * d.daylight);

    if (d.sunUp) {
      L.lightDir.copy(d.sunDir);
      tinted(L.lightColor, w.sun, d, 0.6);
      L.lightIntensity = w.sunIntensity * d.daylight;
      L.shadow = w.shadow * clamp01(d.daylight * 1.2);
    } else {
      L.lightDir.copy(d.moonDir);
      L.lightColor.copy(MOON);
      L.lightIntensity = 0.25 + 0.1 * (w.sunIntensity / 2.4);
      L.shadow = w.shadow * 0.4;
    }
    L.sunDir.copy(d.sunDir);
    L.moonDir.copy(d.moonDir);
    L.sunDiscOpacity = w.sunDisc * clamp01((d.daylight - 0.15) / 0.4) * (d.sunUp ? 1 : 0);
    L.sunDiscColor.copy(SUN_WARM).lerp(SUN_LOW, clamp01(d.amount * 2.5));
    L.moonDiscOpacity = w.sunDisc * clamp01((0.5 - d.daylight) / 0.3);
    world.applyLook(L);

    lights = Math.max(w.lights, d.lights);
    harbor.setLook({ road: w.road, snow: w.snow, puddles: w.rain, lights, dt });
    clouds.update(dt, w.clouds, tinted(cloudColor, w.cloud, d));
    particles.update(dt, world.camera.position, w.rain, w.snow);

    car.grip = w.grip;
    car.brakeMul = w.brake;
    model.setLights(lights);
  }

  return {
    update,
    setWeather: name => blend.set(name),
    snapWeather: name => blend.snap(name),
    get weather() { return blend.name; },
    /** Current blended weather numbers (rain, snow, grip …) */
    get values() { return blend.current; },
    get clockText() { return time.text; },
    get lights() { return lights; },
    clock: time,
  };
}
