// Flat low-poly cloud shapes high over the town. The weather sets how many show and their colour.
import * as THREE from 'three';
import { rng } from './props.js';

const MAX = 9;

export function createClouds(scene) {
  const rand = rng(7);
  const puff = new THREE.IcosahedronGeometry(1, 0);
  const clouds = [];
  for (let i = 0; i < MAX; i++) {
    const mat = new THREE.MeshLambertMaterial({ color: '#FFFFFF', flatShading: true, transparent: true, opacity: 0, fog: false, depthWrite: false });
    const g = new THREE.Group();
    const n = 3 + Math.floor(rand() * 3);
    for (let k = 0; k < n; k++) {
      const m = new THREE.Mesh(puff, mat);
      const s = 10 + rand() * 9;
      m.scale.set(s * 1.4, s * 0.45, s);
      m.position.set((k - n / 2) * 13 + rand() * 6, rand() * 3, rand() * 10 - 5);
      g.add(m);
    }
    // spread so the first few (shown in Sunny) sit where the camera usually looks
    const a = (i / MAX) * Math.PI * 2 + rand() * 0.5, r = 120 + rand() * 220;
    g.position.set(Math.cos(a) * r, 85 + rand() * 30, Math.sin(a) * r);
    g.userData = { mat, speed: 0.8 + rand() * 0.8 };
    scene.add(g);
    clouds.push(g);
  }

  return {
    update(dt, count, color) {
      clouds.forEach((g, i) => {
        const o = THREE.MathUtils.clamp(count - i, 0, 1) * 0.95;
        g.userData.mat.opacity = o;
        g.userData.mat.color.copy(color);
        g.visible = o > 0.01;
        g.position.x += g.userData.speed * dt;
        if (g.position.x > 420) g.position.x -= 840;
      });
    },
  };
}
