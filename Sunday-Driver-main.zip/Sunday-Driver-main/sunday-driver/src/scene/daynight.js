// Day / night cycle (Reference E): one game day = 20 real minutes.
// dawn 06:00–07:30 (2 min) · day 07:30–18:00 (12 min) · dusk 18:00–19:30 (2 min) · night 19:30–06:00 (4 min)
import * as THREE from 'three';

const H = h => h * 60;
// game minutes per real second in each phase
const RATE = { dawn: 90 / 120, day: 630 / 720, dusk: 90 / 120, night: 630 / 240 };

export function phaseOf(min) {
  if (min >= H(6) && min < H(7.5)) return 'dawn';
  if (min >= H(7.5) && min < H(18)) return 'day';
  if (min >= H(18) && min < H(19.5)) return 'dusk';
  return 'night';
}

// keyframes: tint colour + amount over the weather colours, daylight multiplier, lights on
const KEYS = [
  { m: H(0), tint: '#141C33', amt: 0.75, day: 0.14, lights: 1 },
  { m: H(5.25), tint: '#141C33', amt: 0.75, day: 0.14, lights: 1 },
  { m: H(6.75), tint: '#F6B38E', amt: 0.35, day: 0.65, lights: 0.5 },
  { m: H(7.5), tint: '#FFFFFF', amt: 0, day: 1, lights: 0 },
  { m: H(18), tint: '#FFFFFF', amt: 0, day: 1, lights: 0 },
  { m: H(18.75), tint: '#F28B74', amt: 0.4, day: 0.6, lights: 1 },
  { m: H(19.5), tint: '#141C33', amt: 0.75, day: 0.14, lights: 1 },
  { m: H(24), tint: '#141C33', amt: 0.75, day: 0.14, lights: 1 },
].map(k => ({ ...k, tint: new THREE.Color(k.tint) }));

export class GameClock {
  constructor(startMinutes = H(10)) {
    this.minutes = startMinutes;
    this.frozen = false;
    this.out = { tint: new THREE.Color(), amount: 0, daylight: 1, lights: 0, sunDir: new THREE.Vector3(), sunUp: true, moonDir: new THREE.Vector3(0.35, 0.8, -0.45).normalize() };
  }

  advance(dt) {
    if (this.frozen) return;
    this.minutes = (this.minutes + RATE[phaseOf(this.minutes)] * dt) % H(24);
  }

  set(hhmm) {
    if (typeof hhmm === 'number') { this.minutes = ((hhmm % 1440) + 1440) % 1440; return; }
    const [h, m] = String(hhmm).split(':').map(Number);
    this.minutes = (h * 60 + (m || 0)) % 1440;
  }

  get text() {
    const m = Math.floor(this.minutes);
    return String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0');
  }

  /** Tint, daylight and sun direction for the current time. */
  sample() {
    const m = this.minutes, o = this.out;
    let i = 0;
    while (i < KEYS.length - 2 && KEYS[i + 1].m <= m) i++;
    const a = KEYS[i], b = KEYS[i + 1];
    const t = (m - a.m) / (b.m - a.m || 1);
    o.tint.copy(a.tint).lerp(b.tint, t);
    o.amount = a.amt + (b.amt - a.amt) * t;
    o.daylight = a.day + (b.day - a.day) * t;
    o.lights = a.lights + (b.lights - a.lights) * t;
    // the sun rises in the east (+X) at 06:00 and sets over the bay (−X) at 18:00
    const ang = ((m - H(6)) / H(12)) * Math.PI;
    const elev = Math.sin(ang);
    o.sunUp = elev > -0.3;
    o.sunDir.set(Math.cos(ang), Math.max(elev, 0.08), 0.35).normalize();
    return o;
  }
}
