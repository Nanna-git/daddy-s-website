// Harbor Town: a 6 x 6 block grid inside a ring road, with the bay along the west side.
import * as THREE from 'three';
import { Batch, GEO, flat, mixHex, rng, ghost, snowMaterial } from './props.js';

export const LINES = [-240, -160, -80, 0, 80, 160, 240]; // road centre lines (both axes)
const ROAD_HALF = 6;          // 12 m roads, two 6 m lanes
const EDGE = 252;             // outer edge of the ring-road sidewalk
const RAIL_X = -262;          // seawall railing (west)
const CURB_Y = 0.15;          // sidewalk height

/** What the mini-map needs to draw the town. */
export const MAP_INFO = {
  lines: LINES, roadHalf: ROAD_HALF, edge: EDGE, railX: RAIL_X,
  park: { minX: LINES[3] + ROAD_HALF, maxX: LINES[4] - ROAD_HALF, minZ: LINES[2] + ROAD_HALF, maxZ: LINES[3] - ROAD_HALF },
  lighthouse: { x: -360, z: -150 },
  landmark: { x: -360, z: -150, color: '#FFE08A' },
  water: { minX: -2000, maxX: RAIL_X, minZ: -2000, maxZ: 2000 },
  pier: { minX: RAIL_X - 40, maxX: RAIL_X, minZ: -2.5, maxZ: 2.5 },
};

const C = {
  road: '#7B818C', line: '#F4F1E8', walk: '#DCD6CC', sand: '#EBD9B3', grass: '#B9D3A4', lawn: '#86B07E',
  water: '#1E6FB4', water2: '#4B98D8', stone: '#C9B48C', timber: '#B98A5E', pole: '#3A4656',
  buildings: ['#F6F2EA', '#9DD0EA', '#EBD8B0', '#F28B74', '#F6F2EA', '#9DD0EA'],
  greens: ['#4F9A58', '#5FA562', '#66B36C'],
};

export function buildHarbor(scene) {
  const rand = rng(42);
  const pick = arr => arr[Math.floor(rand() * arr.length)];
  const boxes = [];   // building / wall colliders: { minX, maxX, minZ, maxZ }
  const circles = []; // tree / pole colliders: { x, z, r }
  const add = obj => { scene.add(obj); return obj; };

  // ---------- ground ----------
  const plane = (w, d, color, x, y, z, receive = true) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d).rotateX(-Math.PI / 2), flat(color));
    m.position.set(x, y, z);
    m.receiveShadow = receive;
    return add(m);
  };
  plane(1062, 1600, C.grass, 269, -0.03, 0, false);         // land around the town (east of the seawall)
  const road = plane(EDGE * 2 - 12, EDGE * 2 - 12, C.road, 0, 0, 0); // asphalt for every road
  road.material = new THREE.MeshLambertMaterial({ color: C.road, flatShading: true });

  // weather layers, faded in by setLook()
  const snowMats = [];
  const snowMat = () => { const m = snowMaterial(); snowMats.push(m); return m; };
  const snowGround = new THREE.Mesh(new THREE.PlaneGeometry(1062, 1600).rotateX(-Math.PI / 2), snowMat());
  snowGround.position.set(269, -0.02, 0);
  add(snowGround);
  const snowLayers = [snowGround];

  const slabs = new Batch(GEO.box, C.walk, { receiveShadow: true });
  const blockSpan = (i) => [LINES[i] + ROAD_HALF, LINES[i + 1] - ROAD_HALF];
  const PARK = { ix: 3, iz: 2 };
  for (let ix = 0; ix < 6; ix++) for (let iz = 0; iz < 6; iz++) {
    const [x0, x1] = blockSpan(ix), [z0, z1] = blockSpan(iz);
    const park = ix === PARK.ix && iz === PARK.iz;
    slabs.add((x0 + x1) / 2, 0, (z0 + z1) / 2, x1 - x0, CURB_Y, z1 - z0, 0, park ? C.lawn : C.walk);
  }
  // outer sidewalk ring (N, S, E) and the sand promenade (W)
  const outer = EDGE - 6; // 246: where the ring road's asphalt ends
  slabs.add(0, 0, (outer + EDGE) / 2, EDGE * 2, CURB_Y, 6, 0, C.walk);
  slabs.add(0, 0, -(outer + EDGE) / 2, EDGE * 2, CURB_Y, 6, 0, C.walk);
  slabs.add((outer + EDGE) / 2, 0, 0, 6, CURB_Y, EDGE * 2, 0, C.walk);
  slabs.add(-(outer + EDGE) / 2, 0, 0, 6, CURB_Y, EDGE * 2, 0, C.walk);
  slabs.add((RAIL_X - EDGE) / 2, 0, 0, -RAIL_X - EDGE, CURB_Y, EDGE * 2 + 20, 0, C.sand);
  const slabMesh = add(slabs.build());
  snowLayers.push(add(ghost(slabMesh, snowMat(), 0.005)));

  // snow banks along every road edge (the road itself stays grey)
  const banks = new Batch(GEO.box, '#FFFFFF');
  for (const L of LINES) for (const s of [-1, 1]) {
    banks.add(L + s * (ROAD_HALF - 0.7), 0, 0, 1.4, 0.03, EDGE * 2 - 12);
    banks.add(0, 0, L + s * (ROAD_HALF - 0.7), EDGE * 2 - 12, 0.03, 1.4);
  }
  const bankMesh = banks.build();
  bankMesh.material = snowMat();
  bankMesh.visible = false;
  snowLayers.push(add(bankMesh));

  // rain puddles on the roads
  const puddleGeo = new THREE.CircleGeometry(1, 10).rotateX(-Math.PI / 2);
  const puddleMat = new THREE.MeshLambertMaterial({ color: '#9AA8BC', transparent: true, opacity: 0, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
  const puddles = new Batch(puddleGeo, '#9AA8BC');
  for (let i = 0; i < 160; i++) {
    const L = pick(LINES), along = -240 + rand() * 480, off = (rand() * 2 - 1) * 4;
    const r = 0.8 + rand() * 1.6;
    if (rand() < 0.5) puddles.add(L + off, 0.012, along, r * 1.6, 1, r, rand() * Math.PI);
    else puddles.add(along, 0.012, L + off, r * 1.6, 1, r, rand() * Math.PI);
  }
  const puddleMesh = puddles.build();
  puddleMesh.material = puddleMat;
  puddleMesh.visible = false;
  add(puddleMesh);

  // dashed centre lines, skipping junctions
  const dashes = new Batch(GEO.box, C.line, { receiveShadow: true });
  const nearJunction = v => LINES.some(L => Math.abs(v - L) < 8);
  for (const L of LINES) {
    for (let t = -EDGE + 8; t < EDGE - 8; t += 9) {
      const m = t + 1.5;
      if (nearJunction(m)) continue;
      dashes.add(L, 0.004, m, 0.25, 0.01, 3);
      dashes.add(m, 0.004, L, 3, 0.01, 0.25);
    }
  }
  add(dashes.build());

  // ---------- buildings ----------
  const walls = new Batch(GEO.box, '#ffffff');
  const caps = new Batch(GEO.box, '#ffffff');
  const windows = new Batch(GEO.plane, '#ffffff');
  const litWindows = new Batch(GEO.plane, '#FFD98A');
  const shops = new Batch(GEO.plane, '#3E5D78');
  const awnings = new Batch(GEO.box, '#ffffff');
  let awningFlip = false;

  const facade = (cx, cz, w, d, h, color) => {
    const winColor = mixHex(color, '#2E4A66', 0.6);
    const floors = Math.max(2, Math.round(h / 3));
    // n = outward normal, width = facade width, rot = plane rotation facing n
    const sides = [
      { nx: 0, nz: 1, half: d / 2, width: w, rot: 0 },
      { nx: 0, nz: -1, half: d / 2, width: w, rot: Math.PI },
      { nx: 1, nz: 0, half: w / 2, width: d, rot: Math.PI / 2 },
      { nx: -1, nz: 0, half: w / 2, width: d, rot: -Math.PI / 2 },
    ];
    for (const s of sides) {
      const tx = -s.nz, tz = s.nx; // tangent along the facade
      const ox = cx + s.nx * (s.half + 0.03), oz = cz + s.nz * (s.half + 0.03);
      const cols = Math.max(1, Math.floor((s.width - 2) / 3.2));
      const step = (s.width - 2) / cols;
      for (let f = 1; f < floors; f++) {
        const y = CURB_Y + f * 3 + 1.4;
        for (let i = 0; i < cols; i++) {
          const o = -s.width / 2 + 1 + step * (i + 0.5);
          windows.add(ox + tx * o, y, oz + tz * o, 1.3, 1.5, 1, s.rot, winColor);
          if (rand() < 0.35) litWindows.add(ox + tx * o + s.nx * 0.01, y, oz + tz * o + s.nz * 0.01, 1.3, 1.5, 1, s.rot);
        }
      }
      shops.add(ox, CURB_Y + 1.25, oz, s.width - 3, 1.8, 1, s.rot);
      const ax = cx + s.nx * (s.half + 0.55), az = cz + s.nz * (s.half + 0.55);
      const along = s.width - 2;
      awnings.add(ax, CURB_Y + 2.5, az, s.nz ? along : 1.1, 0.22, s.nz ? 1.1 : along, 0, awningFlip ? '#2F86C9' : '#F2674A');
      awningFlip = !awningFlip;
    }
  };

  for (let ix = 0; ix < 6; ix++) for (let iz = 0; iz < 6; iz++) {
    if (ix === PARK.ix && iz === PARK.iz) continue;
    const [x0, x1] = blockSpan(ix), [z0, z1] = blockSpan(iz);
    const lot = (x1 - x0 - 6) / 3;
    const heights = ix === 0 ? [6, 7.5, 9] : [6, 7.5, 9, 10.5, 12];
    for (let a = 0; a < 3; a++) for (let b = 0; b < 3; b++) {
      if (a === 1 && b === 1) continue; // courtyard
      const cx = x0 + 3 + lot * (a + 0.5), cz = z0 + 3 + lot * (b + 0.5);
      const w = 15 + rand() * 3.5, d = 15 + rand() * 3.5, h = pick(heights);
      const color = pick(C.buildings);
      walls.add(cx, CURB_Y, cz, w, h, d, 0, color);
      caps.add(cx, CURB_Y + h, cz, w + 0.4, 0.45, d + 0.4, 0, mixHex(color, '#000000', 0.14));
      facade(cx, cz, w, d, h, color);
      boxes.push({ minX: cx - w / 2, maxX: cx + w / 2, minZ: cz - d / 2, maxZ: cz + d / 2 });
    }
  }
  [walls, windows, shops, awnings].forEach(b => add(b.build()));
  const capMesh = add(caps.build());
  snowLayers.push(add(ghost(capMesh, snowMat(), 0.02)));
  const litWinMesh = litWindows.build();
  const litWinMat = new THREE.MeshBasicMaterial({ color: '#FFD98A', transparent: true, opacity: 0, depthWrite: false });
  litWinMesh.material = litWinMat;
  litWinMesh.visible = false;
  add(litWinMesh);

  // ---------- trees ----------
  const trunks = new Batch(GEO.cyl6, '#8A6A4A');
  const crowns = new Batch(GEO.crown, '#ffffff');
  const tree = (x, z, s = 1, solid = false) => {
    trunks.add(x, CURB_Y, z, 0.45 * s, 2.6 * s, 0.45 * s);
    crowns.add(x, CURB_Y + 2.6 * s + 1.5 * s, z, 2.2 * s, 2.0 * s, 2.2 * s, rand() * Math.PI, pick(C.greens));
    if (solid) circles.push({ x, z, r: 0.6 * s });
  };
  {
    const [x0, x1] = blockSpan(PARK.ix), [z0, z1] = blockSpan(PARK.iz);
    for (let a = 0; a < 4; a++) for (let b = 0; b < 4; b++) {
      tree(x0 + 10 + a * 16 + rand() * 4, z0 + 10 + b * 16 + rand() * 4, 0.9 + rand() * 0.4, true);
    }
  }
  for (let z = -236; z <= 236; z += 28) tree(-257, z, 1, true); // promenade
  for (let i = 0; i < 140; i++) {                               // countryside beyond the hedge
    const side = Math.floor(rand() * 3), along = -300 + rand() * 600, out = 262 + rand() * 60;
    if (side === 0) tree(along, out, 1 + rand() * 0.6);
    else if (side === 1) tree(along, -out, 1 + rand() * 0.6);
    else tree(out, along, 1 + rand() * 0.6);
  }
  add(trunks.build());
  const crownMesh = add(crowns.build());
  const crownSnow = ghost(crownMesh, snowMat(), 0.06);
  snowLayers.push(add(crownSnow));

  // ---------- street lamps ----------
  const poles = new Batch(GEO.cyl6, C.pole);
  const arms = new Batch(GEO.box, C.pole);
  const heads = new Batch(GEO.box, '#E8EEF2');
  const lamp = (x, z, dx, dz) => {
    poles.add(x, CURB_Y, z, 0.18, 6, 0.18);
    arms.add(x + dx * 0.7, CURB_Y + 5.9, z + dz * 0.7, dx ? 1.4 : 0.12, 0.12, dz ? 1.4 : 0.12);
    heads.add(x + dx * 1.3, CURB_Y + 5.75, z + dz * 1.3, dx ? 0.8 : 0.5, 0.18, dz ? 0.8 : 0.5);
    circles.push({ x, z, r: 0.3 });
  };
  for (const L of LINES) {
    for (let t = -220; t <= 220; t += 40) {
      if (nearJunction(t)) continue;
      lamp(L + 7.4, t, -1, 0); lamp(L - 7.4, t, 1, 0);
      lamp(t, L + 7.4, 0, -1); lamp(t, L - 7.4, 0, 1);
    }
  }
  [poles, arms].forEach(b => add(b.build()));
  const headMesh = add(heads.build());
  const lampMat = new THREE.MeshLambertMaterial({ color: '#E8EEF2', emissive: '#FFF1BF', emissiveIntensity: 0, flatShading: true });
  headMesh.material = lampMat;

  // ---------- traffic lights: cycle NS / EW (they stop AI cars only) ----------
  const tPoles = new Batch(GEO.cyl6, '#2F3946');
  const tBoxes = new Batch(GEO.box, '#1F252D');
  const bulbs = new THREE.InstancedMesh(GEO.sphere, new THREE.MeshBasicMaterial({ color: '#ffffff' }), 25 * 6);
  bulbs.frustumCulled = false;
  const bulbInfo = []; // { junction, axis, kind }
  const junctions = [];
  const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _s = new THREE.Vector3(0.3, 0.3, 0.3);
  for (const a of LINES.slice(1, -1)) for (const b of LINES.slice(1, -1)) {
    const x = a + 7.4, z = b + 7.4;
    const j = { x: a, z: b, offset: (((a + b) / 80) % 2 + 2) % 2 * 10 };
    junctions.push(j);
    tPoles.add(x, CURB_Y, z, 0.2, 4.6, 0.2);
    tBoxes.add(x, CURB_Y + 4.6, z, 0.5, 1.3, 0.5);
    // west face is seen by cars driving along X ("ew"), south face by cars driving along Z ("ns")
    for (const [ox, oz, axis] of [[-0.26, 0, 'ew'], [0, -0.26, 'ns']]) {
      [['red', 5.55], ['amber', 5.15], ['green', 4.75]].forEach(([kind, y]) => {
        _m.compose(new THREE.Vector3(x + ox, CURB_Y + y, z + oz), _q, _s);
        bulbs.setMatrixAt(bulbInfo.length, _m);
        bulbInfo.push({ j, axis, kind });
      });
    }
    circles.push({ x, z, r: 0.35 });
  }
  bulbs.count = bulbInfo.length;
  [tPoles, tBoxes].forEach(b => add(b.build()));
  add(bulbs);
  const BULB = {
    red: [new THREE.Color('#FF4D4D'), new THREE.Color('#4A2626')],
    amber: [new THREE.Color('#FFC845'), new THREE.Color('#4A4126')],
    green: [new THREE.Color('#3DDC84'), new THREE.Color('#1F3D2C')],
  };
  let lightTime = 0;
  /** 'green' | 'amber' | 'red' for traffic moving along an axis at a junction. 20 s cycle. */
  const signal = (j, axis) => {
    const p = (lightTime + j.offset) % 20;
    if (axis === 'ns') return p < 8 ? 'green' : p < 10 ? 'amber' : 'red';
    return p < 10 ? 'red' : p < 18 ? 'green' : 'amber';
  };
  const paintBulbs = () => {
    bulbInfo.forEach((b, i) => bulbs.setColorAt(i, BULB[b.kind][signal(b.j, b.axis) === b.kind ? 0 : 1]));
    bulbs.instanceColor.needsUpdate = true;
  };
  bulbs.setColorAt(0, BULB.red[1]);
  paintBulbs();

  // ---------- waterfront: railing, seawall, pier ----------
  const posts = new Batch(GEO.box, '#FFFFFF');
  for (let z = -EDGE - 8; z <= EDGE + 8; z += 2) posts.add(RAIL_X + 0.2, CURB_Y, z, 0.12, 1.0, 0.12);
  posts.add(RAIL_X + 0.2, CURB_Y + 0.95, 0, 0.1, 0.1, EDGE * 2 + 16);
  add(posts.build());
  const seawall = new THREE.Mesh(GEO.box, flat(C.stone));
  seawall.scale.set(2, 1.6, 1200); seawall.position.set(RAIL_X - 1, -1.45, 0);
  add(seawall);

  const timber = flat(C.timber);
  const deck = new THREE.Mesh(GEO.box, timber);
  deck.scale.set(40, 0.4, 5); deck.position.set(RAIL_X - 20, -0.2, 0);
  add(deck);
  const pierPosts = new Batch(GEO.cyl6, mixHex(C.timber, '#000000', 0.4));
  for (let x = RAIL_X - 4; x > RAIL_X - 40; x -= 6) { pierPosts.add(x, -1.6, -2.2, 0.3, 1.5, 0.3); pierPosts.add(x, -1.6, 2.2, 0.3, 1.5, 0.3); }
  add(pierPosts.build());

  // ---------- water (gentle colour shift) ----------
  const waterGeo = new THREE.PlaneGeometry(1740, 1600, 40, 40).rotateX(-Math.PI / 2);
  const wPos = waterGeo.attributes.position;
  const wCol = new Float32Array(wPos.count * 3);
  waterGeo.setAttribute('color', new THREE.BufferAttribute(wCol, 3));
  const water = new THREE.Mesh(waterGeo, new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true }));
  water.position.set(RAIL_X - 870, -1.0, 0);
  add(water);
  const cA = new THREE.Color(C.water), cB = new THREE.Color(C.water2), tmp = new THREE.Color();

  // ---------- lighthouse on a sand spit ----------
  const lh = new THREE.Group();
  lh.position.set(-360, 0, -150);
  const spit = new THREE.Mesh(GEO.box, flat(C.sand)); spit.scale.set(50, 1.4, 36); spit.position.y = -1.2; lh.add(spit);
  const grass = new THREE.Mesh(GEO.box, flat('#86B07E')); grass.scale.set(30, 0.2, 20); grass.position.set(4, 0.2, 2); lh.add(grass);
  const cyl = (rt, rb, h, color, y, basic = false) => {
    const m = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, 8).translate(0, h / 2, 0), basic ? new THREE.MeshBasicMaterial({ color }) : flat(color));
    m.position.y = y; lh.add(m); return m;
  };
  cyl(1.5, 2.1, 14, '#F7F5F0', 0.2);
  cyl(1.93, 2.0, 1.8, '#E8604C', 4.2);
  cyl(1.68, 1.76, 1.6, '#E8604C', 9.2);
  cyl(2.0, 2.0, 0.4, '#2B3A4D', 14.2);
  const lantern = cyl(1.1, 1.1, 1.8, '#FFE08A', 14.6, true);
  // rotating beam, only visible when the lights are on
  const beam = new THREE.Group();
  beam.position.y = 15.5;
  const beamMat = new THREE.MeshBasicMaterial({ color: '#FFF1BF', transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, fog: false });
  for (const s of [-1, 1]) {
    const b = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 3.2, 60, 8, 1, true).rotateZ(Math.PI / 2), beamMat);
    b.position.x = s * 31; if (s < 0) b.rotation.y = Math.PI;
    beam.add(b);
  }
  beam.visible = false;
  lh.add(beam);
  const cap = new THREE.Mesh(new THREE.ConeGeometry(1.5, 1.6, 8).translate(0, 0.8, 0), flat('#E8604C'));
  cap.position.y = 16.4; lh.add(cap);
  const hut = new THREE.Mesh(GEO.box, flat('#F7F5F0')); hut.scale.set(4, 2.6, 3.2); hut.position.set(5, 0.2, 2); lh.add(hut);
  const hutRoof = new THREE.Mesh(GEO.box, flat('#E8604C')); hutRoof.scale.set(4.4, 0.35, 3.6); hutRoof.position.set(5, 2.8, 2); lh.add(hutRoof);
  add(lh);

  // ---------- boats ----------
  const boats = [];
  const boat = (x, z, s, cabin, rot) => {
    const b = new THREE.Group();
    const hull = new THREE.Mesh(new THREE.CylinderGeometry(1, 0.75, 1, 4, 1).rotateY(Math.PI / 4).translate(0, 0.5, 0), flat('#FFFFFF'));
    hull.scale.set(2.4 * s, 0.9 * s, 1.0 * s); b.add(hull);
    const cab = new THREE.Mesh(GEO.box, flat(cabin)); cab.scale.set(1.6 * s, 1.0 * s, 1.1 * s); cab.position.set(-0.3 * s, 0.9 * s, 0); b.add(cab);
    const mast = new THREE.Mesh(GEO.cyl6, flat(C.pole)); mast.scale.set(0.1 * s, 3.5 * s, 0.1 * s); mast.position.set(0.6 * s, 0.9 * s, 0); b.add(mast);
    b.position.set(x, -1.3, z); b.rotation.y = rot;
    boats.push({ g: b, phase: rand() * 6.28 });
    add(b);
  };
  boat(-300, 40, 1.6, '#F2674A', 0.4);
  boat(-320, -60, 1.3, '#8ED1F2', 2.0);
  boat(-290, 140, 1.8, '#F2674A', -0.8);
  boat(-340, 90, 1.2, '#2F86C9', 1.2);

  // ---------- hedge boundary (N, S, E) + invisible walls ----------
  const hedge = new Batch(GEO.box, '#5E9C5A');
  hedge.add(0, 0, EDGE + 1, EDGE * 2 + 22, 0.9, 1.2);
  hedge.add(0, 0, -EDGE - 1, EDGE * 2 + 22, 0.9, 1.2);
  hedge.add(EDGE + 1, 0, 0, 1.2, 0.9, EDGE * 2 + 2);
  const hedgeMesh = add(hedge.build());
  snowLayers.push(add(ghost(hedgeMesh, snowMat(), 0.03)));

  const roadDry = new THREE.Color(C.road);
  const lanternOff = new THREE.Color('#F2E2B0'), lanternOn = new THREE.Color('#FFE08A');
  boxes.push({ minX: -400, maxX: 400, minZ: EDGE + 0.4, maxZ: 300 });
  boxes.push({ minX: -400, maxX: 400, minZ: -300, maxZ: -EDGE - 0.4 });
  boxes.push({ minX: EDGE + 0.4, maxX: 300, minZ: -400, maxZ: 400 });
  boxes.push({ minX: -400, maxX: RAIL_X + 0.4, minZ: -400, maxZ: 400 });

  return {
    colliders: { boxes, circles },
    mapInfo: MAP_INFO,
    orbitTarget: [-150, -40],          // Start-screen camera circles the waterfront
    orbit: { radius: 120, height: 55, lookY: 0 },
    traffic: { lane: 3, stopBack: 9 },
    junctions,
    signal,
    /** Advance the traffic-light cycle. */
    updateSignals(dt) { lightTime += dt; paintBulbs(); },
    spawn: { x: -237, z: 120, heading: Math.PI }, // waterfront road, heading south, bay on the left

    /** Weather + time look: road colour, snow cover 0..1, puddles 0..1, lights 0..1. */
    setLook({ road: roadColor, snow, puddles: wet, lights, dt }) {
      road.material.color.copy(roadColor || roadDry);
      snowMats.forEach(m => { m.opacity = snow * 0.92; });
      snowLayers.forEach(l => { l.visible = snow > 0.01; });
      crownSnow.material.opacity = snow * 0.7;
      puddleMat.opacity = wet * 0.55;
      puddleMesh.visible = wet > 0.01;
      litWinMat.opacity = lights * 0.95;
      litWinMesh.visible = lights > 0.01;
      lampMat.emissiveIntensity = lights * 1.2;
      lantern.material.color.copy(lanternOff).lerp(lanternOn, lights);
      beamMat.opacity = lights * 0.16;
      beam.visible = lights > 0.01;
      beam.rotation.y += (dt || 0) * 0.7;
    },
    update(t) {
      for (let i = 0; i < wPos.count; i++) {
        const k = 0.5 + 0.5 * Math.sin(t * 0.6 + wPos.getX(i) * 0.02 + wPos.getZ(i) * 0.027);
        tmp.copy(cA).lerp(cB, k * 0.55);
        wCol[i * 3] = tmp.r; wCol[i * 3 + 1] = tmp.g; wCol[i * 3 + 2] = tmp.b;
      }
      waterGeo.attributes.color.needsUpdate = true;
      for (const b of boats) {
        b.g.position.y = -1.3 + Math.sin(t * (Math.PI * 2 / 4) + b.phase) * 0.03 * 3;
        b.g.rotation.z = Math.sin(t * 1.3 + b.phase) * 0.03;
      }
    },
  };
}
