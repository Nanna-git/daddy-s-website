// Metro Downtown: a strict grid of wide avenues, towers built as box stacks, a central park,
// one elevated highway loop you can drive on (four on-ramps) and the city's tallest tower as the landmark.
// Same 7 × 7 road lines as Harbor Town (so traffic loops work), but 16 m roads and much taller blocks.
import * as THREE from 'three';
import { Batch, GEO, flat, mixHex, rng, ghost, snowMaterial } from './props.js';

export const LINES = [-240, -160, -80, 0, 80, 160, 240];
const ROAD_HALF = 8;          // 16 m avenues
const EDGE = 256;             // outer edge of the ring-road sidewalk
const CURB_Y = 0.15;
const HWY = 160;              // the elevated loop runs above the ±160 roads
const HWY_Y = 9;              // deck height (top)

// Four on-ramps, one per side, built beside the deck: each rises 9 m over 52 m, runs level for 12 m and merges
// onto the deck through a 32 m gap in its outer parapet (the last 32 m of the ramp). Written once in a base frame (east side, rising towards +z)
// and turned by 90° for the other three; ramp k is the base turned k times.
const RAMP = { x0: 167.2, x1: 181.2, z0: 88, z1: 152, climb: 52 };
const SURF0 = CURB_Y + 0.03;  // ramp surface where it leaves the pavement
const turn = (x, z) => [-z, x];      // base frame → next ramp
const unturn = (x, z) => [z, -x];    // and back
const turnRect = r => ({ ...r, minX: -r.maxZ, maxX: -r.minZ, minZ: r.minX, maxZ: r.maxX });
const rampRects = pad => [0, 1, 2, 3].map(k => {
  let r = { minX: RAMP.x0 - pad, maxX: RAMP.x1 + pad, minZ: RAMP.z0 - pad, maxZ: RAMP.z1 + pad };
  for (let i = 0; i < k; i++) r = turnRect(r);
  return r;
});
const inRect = (r, x, z) => x >= r.minX && x <= r.maxX && z >= r.minZ && z <= r.maxZ;
const onLoop = (x, z) => (Math.abs(Math.abs(x) - HWY) <= 7.2 && Math.abs(z) <= HWY + 7.2) || (Math.abs(Math.abs(z) - HWY) <= 7.2 && Math.abs(x) <= HWY + 7.2);

/** Driving height (m) at x, z for a car currently at height y: ramps are their own surface; the deck only
 *  carries cars that are already up there (below it you drive on the road). Flat everywhere else. */
export function heightAt(x, z, y = 0) {
  let px = x, pz = z;
  for (let k = 0; k < 4; k++) {
    if (px >= RAMP.x0 && px <= RAMP.x1 && pz >= RAMP.z0 && pz <= RAMP.z1) {
      return SURF0 + (HWY_Y - SURF0) * Math.min(1, (pz - RAMP.z0) / RAMP.climb);
    }
    [px, pz] = unturn(px, pz);
  }
  return y > HWY_Y / 2 && onLoop(x, z) ? HWY_Y : 0;
}

const C = {
  road: '#5E636B', line: '#F4F1E8', yellow: '#F2C94C', walk: '#B7BCC3', plaza: '#A3AAB2', lawn: '#7FAE76',
  greys: ['#8E99A6', '#A7B2BE', '#6F7B88', '#C3CBD3', '#9AA5B1'],
  glass: ['#5E86AE', '#7EA6CC', '#6C8FB3', '#4F7396', '#8FB3D6'],
  pole: '#3A4352', neon: ['#FF4FD8', '#3FE0FF', '#FFB020'],
};

const PARK = { ix: 2, iz: 3 };       // x −72…−8, z 8…72
const LANDMARK = { ix: 3, iz: 2 };   // x 8…72, z −72…−8 — tallest tower

export function buildMetro(group) {
  const rand = rng(2024);
  const pick = arr => arr[Math.floor(rand() * arr.length)];
  const boxes = [], circles = [];
  const add = o => { group.add(o); return o; };
  const blockSpan = i => [LINES[i] + ROAD_HALF, LINES[i + 1] - ROAD_HALF];
  const nearJunction = (v, gap = 10) => LINES.some(L => Math.abs(v - L) < gap);

  // ---------- ground ----------
  const plane = (w, d, color, x, y, z) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d).rotateX(-Math.PI / 2), new THREE.MeshLambertMaterial({ color, flatShading: true }));
    m.position.set(x, y, z); m.receiveShadow = true;
    return add(m);
  };
  plane(1800, 1800, C.plaza, 0, -0.03, 0);
  const road = plane(EDGE * 2 - 16, EDGE * 2 - 16, C.road, 0, 0, 0);

  const snowMats = [];
  const snowMat = () => { const m = snowMaterial(); snowMats.push(m); return m; };
  const snowLayers = [];
  const snowGround = new THREE.Mesh(new THREE.PlaneGeometry(1800, 1800).rotateX(-Math.PI / 2), snowMat());
  snowGround.position.y = -0.02; snowGround.visible = false;
  snowLayers.push(add(snowGround));

  const slabs = new Batch(GEO.box, C.walk, { receiveShadow: true });
  for (let ix = 0; ix < 6; ix++) for (let iz = 0; iz < 6; iz++) {
    const [x0, x1] = blockSpan(ix), [z0, z1] = blockSpan(iz);
    const park = ix === PARK.ix && iz === PARK.iz;
    slabs.add((x0 + x1) / 2, 0, (z0 + z1) / 2, x1 - x0, CURB_Y, z1 - z0, 0, park ? C.lawn : C.walk);
  }
  const outer = EDGE - 8;
  slabs.add(0, 0, (outer + EDGE) / 2, EDGE * 2, CURB_Y, 8, 0, C.walk);
  slabs.add(0, 0, -(outer + EDGE) / 2, EDGE * 2, CURB_Y, 8, 0, C.walk);
  slabs.add((outer + EDGE) / 2, 0, 0, 8, CURB_Y, EDGE * 2, 0, C.walk);
  slabs.add(-(outer + EDGE) / 2, 0, 0, 8, CURB_Y, EDGE * 2, 0, C.walk);
  const slabMesh = add(slabs.build());
  snowLayers.push(add(ghost(slabMesh, snowMat(), 0.005)));

  // markings: double yellow centre lines, white edge lines, zebra crossings at every junction
  const yellow = new Batch(GEO.box, C.yellow, { receiveShadow: true });
  const white = new Batch(GEO.box, C.line, { receiveShadow: true });
  for (const L of LINES) {
    for (let a = 0; a < LINES.length - 1; a++) {
      const t0 = LINES[a] + ROAD_HALF + 6, t1 = LINES[a + 1] - ROAD_HALF - 6, mid = (t0 + t1) / 2, len = t1 - t0;
      for (const o of [-0.2, 0.2]) { yellow.add(L + o, 0.004, mid, 0.14, 0.01, len); yellow.add(mid, 0.004, L + o, len, 0.01, 0.14); }
      for (const o of [-(ROAD_HALF - 0.6), ROAD_HALF - 0.6]) { white.add(L + o, 0.004, mid, 0.15, 0.01, len + 10); white.add(mid, 0.004, L + o, len + 10, 0.01, 0.15); }
    }
  }
  for (const a of LINES) for (const b of LINES) {
    for (const side of [-1, 1]) {
      for (let k = -ROAD_HALF + 1; k <= ROAD_HALF - 1; k += 1.4) {
        white.add(a + k, 0.004, b + side * (ROAD_HALF + 3), 0.7, 0.01, 4);   // crossing the N–S road
        white.add(a + side * (ROAD_HALF + 3), 0.004, b + k, 4, 0.01, 0.7);   // crossing the E–W road
      }
    }
  }
  add(yellow.build()); add(white.build());

  // snow banks along the road edges + rain puddles
  const banks = new Batch(GEO.box, '#FFFFFF');
  for (const L of LINES) for (const s of [-1, 1]) {
    banks.add(L + s * (ROAD_HALF - 0.8), 0, 0, 1.6, 0.03, EDGE * 2 - 16);
    banks.add(0, 0, L + s * (ROAD_HALF - 0.8), EDGE * 2 - 16, 0.03, 1.6);
  }
  const bankMesh = banks.build();
  bankMesh.material = snowMat(); bankMesh.visible = false;
  snowLayers.push(add(bankMesh));
  const puddleMat = new THREE.MeshLambertMaterial({ color: '#8F9DB2', transparent: true, opacity: 0, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
  const puddles = new Batch(new THREE.CircleGeometry(1, 10).rotateX(-Math.PI / 2), '#8F9DB2');
  for (let i = 0; i < 180; i++) {
    const L = pick(LINES), along = -240 + rand() * 480, off = (rand() * 2 - 1) * 6, r = 0.8 + rand() * 1.8;
    if (rand() < 0.5) puddles.add(L + off, 0.012, along, r * 1.6, 1, r, rand() * Math.PI);
    else puddles.add(along, 0.012, L + off, r * 1.6, 1, r, rand() * Math.PI);
  }
  const puddleMesh = puddles.build();
  puddleMesh.material = puddleMat; puddleMesh.visible = false;
  add(puddleMesh);

  // ---------- towers ----------
  const walls = new Batch(GEO.box, '#ffffff');
  const caps = new Batch(GEO.box, '#ffffff');
  const bands = new Batch(GEO.plane, '#ffffff');      // one glass strip per floor per side
  const litBands = new Batch(GEO.plane, '#FFE7A8');   // the strips that glow at night
  const neon = new Batch(GEO.box, '#ffffff');
  const roofKit = new Batch(GEO.box, '#7A8490');

  const sides = (w, d) => [
    { nx: 0, nz: 1, half: d / 2, width: w, rot: 0 },
    { nx: 0, nz: -1, half: d / 2, width: w, rot: Math.PI },
    { nx: 1, nz: 0, half: w / 2, width: d, rot: Math.PI / 2 },
    { nx: -1, nz: 0, half: w / 2, width: d, rot: -Math.PI / 2 },
  ];
  /** A box tier with floor bands; returns its top height. */
  function tier(cx, cz, w, d, y0, h, color, floor = 3.6) {
    walls.add(cx, y0, cz, w, h, d, 0, color);
    caps.add(cx, y0 + h, cz, w + 0.3, 0.5, d + 0.3, 0, mixHex(color, '#000000', 0.18));
    const glass = mixHex(color, '#1F3550', 0.55);
    for (const s of sides(w, d)) {
      const ox = cx + s.nx * (s.half + 0.03), oz = cz + s.nz * (s.half + 0.03);
      for (let y = y0 + 2.2; y < y0 + h - 1.4; y += floor) {
        bands.add(ox, y, oz, s.width - 1.4, 1.6, 1, s.rot, glass);
        if (rand() < 0.38) litBands.add(ox + s.nx * 0.01, y, oz + s.nz * 0.01, s.width - 1.4, 1.6, 1, s.rot);
      }
    }
    return y0 + h;
  }

  const centreDist = (x, z) => Math.hypot(x, z);
  for (let ix = 0; ix < 6; ix++) for (let iz = 0; iz < 6; iz++) {
    if (ix === PARK.ix && iz === PARK.iz) continue;
    if (ix === LANDMARK.ix && iz === LANDMARK.iz) continue;
    const [x0, x1] = blockSpan(ix), [z0, z1] = blockSpan(iz);
    const lot = (x1 - x0) / 2;
    for (let a = 0; a < 2; a++) for (let b = 0; b < 2; b++) {
      const kept = [walls, caps, bands, litBands, neon, roofKit].map(m => m.items.length), keptBoxes = boxes.length;
      const cx = x0 + lot * (a + 0.5), cz = z0 + lot * (b + 0.5);
      const w = 24 + rand() * 4, d = 24 + rand() * 4;
      const podiumH = 6 + Math.floor(rand() * 3) * 2.4;
      const podium = pick(C.greys);
      let top = tier(cx, cz, w, d, CURB_Y, podiumH, podium, 3.2);
      // neon strip along the podium top on the street sides
      const nc = pick(C.neon);
      for (const s of sides(w, d)) {
        if (rand() < 0.5) continue;
        neon.add(cx + s.nx * (s.half + 0.12), top - 0.6, cz + s.nz * (s.half + 0.12), s.nz ? s.width - 2 : 0.12, 0.22, s.nz ? 0.12 : s.width - 2, 0, nc);
      }
      // towers get taller towards the middle of town
      const k = Math.max(0.25, 1.25 - centreDist(cx, cz) / 300);
      const tw = w * (0.62 + rand() * 0.18), td = d * (0.62 + rand() * 0.18);
      const h1 = (18 + rand() * 70) * k;
      top = tier(cx, cz, tw, td, top, h1, pick(rand() < 0.6 ? C.glass : C.greys));
      if (rand() < 0.45) top = tier(cx, cz, tw * 0.7, td * 0.7, top, 8 + rand() * 24 * k, pick(C.glass));
      if (rand() < 0.6) roofKit.add(cx + (rand() - 0.5) * 4, top + 0.25, cz + (rand() - 0.5) * 4, 3 + rand() * 3, 1.6, 3 + rand() * 3);
      boxes.push({ minX: cx - w / 2, maxX: cx + w / 2, minZ: cz - d / 2, maxZ: cz + d / 2 });
      if (rampRects(2).some(r => cx + w / 2 > r.minX && cx - w / 2 < r.maxX && cz + d / 2 > r.minZ && cz - d / 2 < r.maxZ)) {
        [walls, caps, bands, litBands, neon, roofKit].forEach((m, i) => { m.items.length = kept[i]; }); // this lot is where a ramp goes
        boxes.length = keptBoxes;
      }
    }
  }

  // the landmark: Meridian Tower, ~180 m, stepped, with a spire and a blinking beacon
  let beacon;
  {
    const [x0, x1] = blockSpan(LANDMARK.ix), [z0, z1] = blockSpan(LANDMARK.iz);
    const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
    let top = tier(cx, cz, 52, 52, CURB_Y, 12, '#9AA5B1', 4);
    top = tier(cx, cz, 34, 34, top, 92, '#4F7396');
    top = tier(cx, cz, 26, 26, top, 48, '#6C8FB3');
    top = tier(cx, cz, 16, 16, top, 26, '#8FB3D6');
    const spire = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.8, 26, 6).translate(0, 13, 0), flat('#C9CED6'));
    spire.position.set(cx, top + 0.5, cz); add(spire);
    beacon = new THREE.Mesh(new THREE.SphereGeometry(1.1, 8, 6), new THREE.MeshBasicMaterial({ color: '#FF3B30' }));
    beacon.position.set(cx, top + 27, cz); add(beacon);
    for (const s of sides(52, 52)) neon.add(cx + s.nx * 26.12, CURB_Y + 11.2, cz + s.nz * 26.12, s.nz ? 48 : 0.12, 0.3, s.nz ? 0.12 : 48, 0, '#3FE0FF');
    boxes.push({ minX: cx - 26, maxX: cx + 26, minZ: cz - 26, maxZ: cz + 26 });
  }

  [walls, bands, roofKit].forEach(b => add(b.build()));
  const capMesh = add(caps.build());
  snowLayers.push(add(ghost(capMesh, snowMat(), 0.02)));
  const litMesh = litBands.build();
  const litMat = new THREE.MeshBasicMaterial({ color: '#FFE7A8', transparent: true, opacity: 0, depthWrite: false });
  litMesh.material = litMat; litMesh.visible = false;
  add(litMesh);
  const neonMesh = neon.build();
  const neonMat = new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0 });
  neonMesh.material = neonMat; neonMesh.visible = false;
  add(neonMesh);

  // ---------- central park: lawn, pond, paths, trees ----------
  const trunks = new Batch(GEO.cyl6, '#7A5A3A');
  const crowns = new Batch(GEO.crown, '#ffffff');
  const tree = (x, z, s = 1, solid = true) => {
    trunks.add(x, CURB_Y, z, 0.45 * s, 2.8 * s, 0.45 * s);
    crowns.add(x, CURB_Y + 2.8 * s + 1.5 * s, z, 2.2 * s, 2.0 * s, 2.2 * s, rand() * Math.PI, pick(['#4F9A58', '#5FA562', '#3F8A50']));
    if (solid) circles.push({ x, z, r: 0.6 * s });
  };
  const [px0, px1] = blockSpan(PARK.ix), [pz0, pz1] = blockSpan(PARK.iz);
  const pcx = (px0 + px1) / 2, pcz = (pz0 + pz1) / 2;
  const pond = new THREE.Mesh(new THREE.CircleGeometry(13, 16).rotateX(-Math.PI / 2), flat('#4B98D8'));
  pond.position.set(pcx + 6, CURB_Y + 0.01, pcz - 4); add(pond);
  const paths = new Batch(GEO.box, '#D8D2C4', { receiveShadow: true });
  paths.add(pcx, CURB_Y, pcz, px1 - px0, 0.02, 3); paths.add(pcx, CURB_Y, pcz, 3, 0.02, pz1 - pz0);
  add(paths.build());
  for (let i = 0; i < 26; i++) {
    const x = px0 + 4 + rand() * (px1 - px0 - 8), z = pz0 + 4 + rand() * (pz1 - pz0 - 8);
    if (Math.abs(x - pcx) < 3 || Math.abs(z - pcz) < 3 || Math.hypot(x - pcx - 6, z - pcz + 4) < 15) continue;
    tree(x, z, 0.9 + rand() * 0.5);
  }
  circles.push({ x: pcx + 6, z: pcz - 4, r: 13 }); // you drive around the pond, not into it
  add(trunks.build());
  const crownMesh = add(crowns.build());
  const crownSnow = ghost(crownMesh, snowMat(), 0.06);
  snowLayers.push(add(crownSnow));

  // ---------- street lamps ----------
  const poles = new Batch(GEO.cyl6, C.pole), arms = new Batch(GEO.box, C.pole), heads = new Batch(GEO.box, '#E8EEF2');
  const lamp = (x, z, dx, dz) => {
    if (rampRects(2).some(r => inRect(r, x, z))) return;
    poles.add(x, CURB_Y, z, 0.2, 7, 0.2);
    arms.add(x + dx * 1.0, CURB_Y + 6.9, z + dz * 1.0, dx ? 2.0 : 0.12, 0.12, dz ? 2.0 : 0.12);
    heads.add(x + dx * 1.9, CURB_Y + 6.75, z + dz * 1.9, dx ? 1.0 : 0.4, 0.16, dz ? 1.0 : 0.4);
    circles.push({ x, z, r: 0.3 });
  };
  for (const L of LINES) for (let t = -220; t <= 220; t += 40) {
    if (nearJunction(t, 12)) continue;
    lamp(L + ROAD_HALF + 1.2, t, -1, 0); lamp(L - ROAD_HALF - 1.2, t, 1, 0);
    lamp(t, L + ROAD_HALF + 1.2, 0, -1); lamp(t, L - ROAD_HALF - 1.2, 0, 1);
  }
  [poles, arms].forEach(b => add(b.build()));
  const headMesh = add(heads.build());
  const lampMat = new THREE.MeshLambertMaterial({ color: '#E8EEF2', emissive: '#FFF1BF', emissiveIntensity: 0, flatShading: true });
  headMesh.material = lampMat;

  // ---------- traffic lights (same 20 s cycle as Harbor Town) ----------
  const tPoles = new Batch(GEO.cyl6, '#2F3946'), tBoxes = new Batch(GEO.box, '#1F252D');
  const bulbs = new THREE.InstancedMesh(GEO.sphere, new THREE.MeshBasicMaterial({ color: '#ffffff' }), 25 * 6);
  bulbs.frustumCulled = false;
  const bulbInfo = [], junctions = [];
  const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _s = new THREE.Vector3(0.32, 0.32, 0.32);
  for (const a of LINES.slice(1, -1)) for (const b of LINES.slice(1, -1)) {
    const x = a + ROAD_HALF + 1.4, z = b + ROAD_HALF + 1.4;
    const j = { x: a, z: b, offset: (((a + b) / 80) % 2 + 2) % 2 * 10 };
    junctions.push(j);
    if (rampRects(2).some(r => inRect(r, x, z))) continue; // the signal still runs; this corner's lamp is where a ramp starts
    tPoles.add(x, CURB_Y, z, 0.22, 5.2, 0.22);
    tBoxes.add(x, CURB_Y + 5.2, z, 0.55, 1.4, 0.55);
    for (const [ox, oz, axis] of [[-0.29, 0, 'ew'], [0, -0.29, 'ns']]) {
      [['red', 6.2], ['amber', 5.78], ['green', 5.36]].forEach(([kind, y]) => {
        _m.compose(new THREE.Vector3(x + ox, CURB_Y + y, z + oz), _q, _s);
        bulbs.setMatrixAt(bulbInfo.length, _m);
        bulbInfo.push({ j, axis, kind });
      });
    }
    circles.push({ x, z, r: 0.35 });
  }
  bulbs.count = bulbInfo.length;
  [tPoles, tBoxes].forEach(b => add(b.build()));
  add(bulbs);
  const BULB = {
    red: [new THREE.Color('#FF4D4D'), new THREE.Color('#4A2626')],
    amber: [new THREE.Color('#FFC845'), new THREE.Color('#4A4126')],
    green: [new THREE.Color('#3DDC84'), new THREE.Color('#1F3D2C')],
  };
  let lightTime = 0;
  const signal = (j, axis) => {
    const p = (lightTime + j.offset) % 20;
    if (axis === 'ns') return p < 8 ? 'green' : p < 10 ? 'amber' : 'red';
    return p < 10 ? 'red' : p < 18 ? 'green' : 'amber';
  };
  const paintBulbs = () => {
    bulbInfo.forEach((b, i) => bulbs.setColorAt(i, BULB[b.kind][signal(b.j, b.axis) === b.kind ? 0 : 1]));
    bulbs.instanceColor.needsUpdate = true;
  };
  bulbs.setColorAt(0, BULB.red[1]);
  paintBulbs();

  // ---------- elevated highway loop (scenery: the game's physics is flat ground) ----------
  const deck = new Batch(GEO.box, '#8A929C', { receiveShadow: true });
  const deckTop = new Batch(GEO.box, '#5A5F67');
  const parapet = new Batch(GEO.box, '#B7BCC3');
  const pillars = new Batch(GEO.box, '#9AA1A9');
  const hwDash = new Batch(GEO.box, '#F4F1E8');
  const span = HWY * 2 + 14;
  for (const s of [-1, 1]) {
    deck.add(s * HWY, HWY_Y - 1.4, 0, 14, 1.2, span); deck.add(0, HWY_Y - 1.4, s * HWY, span, 1.2, 14);
    deckTop.add(s * HWY, HWY_Y - 0.2, 0, 13, 0.2, span); deckTop.add(0, HWY_Y - 0.2, s * HWY, span, 0.2, 13);
    for (let t = -HWY + 8; t <= HWY - 8; t += 9) { hwDash.add(s * HWY, HWY_Y + 0.005, t, 0.25, 0.02, 3.5); hwDash.add(t, HWY_Y + 0.005, s * HWY, 3.5, 0.02, 0.25); }
    for (let t = -HWY; t <= HWY; t += 40) {
      if (nearJunction(t, 14)) continue;
      pillars.add(s * HWY, 0, t, 1.6, HWY_Y - 1.4, 1.6); circles.push({ x: s * HWY, z: t, r: 1.0, lvl: 'low' });
      pillars.add(t, 0, s * HWY, 1.6, HWY_Y - 1.4, 1.6); circles.push({ x: t, z: s * HWY, r: 1.0, lvl: 'low' });
    }
  }
  // parapets: outer edges run the full loop, inner edges stop at the inner corners; the outer edge is open where
  // a ramp merges. Each one is also a wall (lvl 'deck': it only stops cars that are up on the deck).
  const wallSegments = (from, to, gaps) => {
    let segs = [[from, to]];
    for (const [g0, g1] of gaps) segs = segs.flatMap(([a, b]) => (g1 <= a || g0 >= b ? [[a, b]] : [[a, Math.min(b, g0)], [Math.max(a, g1), b]].filter(([p, q]) => q > p)));
    return segs;
  };
  const OUT = HWY + 6.8, IN = HWY - 6.8, GAP = [RAMP.z1 - 32, RAMP.z1];   // ramp gap: the last 32 m of the ramp
  for (const s of [-1, 1]) {
    const outerGaps = [[], []]; // [x = s·OUT edges, z = s·OUT edges]
    if (s === 1) { outerGaps[0].push(GAP); outerGaps[1].push([-GAP[1], -GAP[0]]); }   // ramps 0 (x = +) and 1 (z = +)
    else { outerGaps[0].push([-GAP[1], -GAP[0]]); outerGaps[1].push(GAP); }          // ramps 2 (x = −) and 3 (z = −)
    const edges = [
      { pos: s * OUT, a: -OUT - 0.2, b: OUT + 0.2, gaps: outerGaps[0], alongZ: true },
      { pos: s * IN, a: -IN, b: IN, gaps: [], alongZ: true },
      { pos: s * OUT, a: -OUT - 0.2, b: OUT + 0.2, gaps: outerGaps[1], alongZ: false },
      { pos: s * IN, a: -IN, b: IN, gaps: [], alongZ: false },
    ];
    for (const e of edges) for (const [a, b] of wallSegments(e.a, e.b, e.gaps)) {
      if (e.alongZ) { parapet.add(e.pos, HWY_Y, (a + b) / 2, 0.4, 0.9, b - a); boxes.push({ minX: e.pos - 0.2, maxX: e.pos + 0.2, minZ: a, maxZ: b, lvl: 'deck' }); }
      else { parapet.add((a + b) / 2, HWY_Y, e.pos, b - a, 0.9, 0.4); boxes.push({ minX: a, maxX: b, minZ: e.pos - 0.2, maxZ: e.pos + 0.2, lvl: 'deck' }); }
    }
  }
  [deck, deckTop, parapet, pillars, hwDash].forEach(b => add(b.build()));

  // ---------- the four on-ramps ----------
  const surf = u => SURF0 + (HWY_Y - SURF0) * Math.min(1, u / RAMP.climb);
  const RAMP_LEN = RAMP.z1 - RAMP.z0;
  /** Solid between the lines lo(u) and hi(u) for u0…u1 along the ramp, `width` wide, its +x face at x = xHi. */
  const rampPart = (u0, u1, lo, hi, width, xHi) => {
    const us = [u0, ...[RAMP.climb].filter(u => u > u0 && u < u1), u1];
    const pts = [...us.map(u => new THREE.Vector2(u, lo(u))), ...[...us].reverse().map(u => new THREE.Vector2(u, hi(u)))];
    return new THREE.ExtrudeGeometry(new THREE.Shape(pts), { depth: width, bevelEnabled: false }).rotateY(-Math.PI / 2).translate(xHi, 0, RAMP.z0);
  };
  const rampW = RAMP.x1 - RAMP.x0;
  const rampParts = [
    [rampPart(0, RAMP_LEN, () => -0.1, u => surf(u) - 0.2, rampW, RAMP.x1), flat('#8A929C')],                 // concrete body
    [rampPart(0, RAMP_LEN, u => surf(u) - 0.2, surf, rampW - 0.4, RAMP.x1 - 0.2), flat('#5A5F67')],           // asphalt
    [rampPart(0, RAMP_LEN, surf, u => surf(u) + 0.9, 0.4, RAMP.x1), flat('#B7BCC3')],                         // outer parapet
    [rampPart(0, RAMP_LEN - 32, surf, u => surf(u) + 0.9, 0.4, RAMP.x0 + 0.4), flat('#B7BCC3')],              // parapet next to the deck, up to the gap
  ];
  for (let k = 0; k < 4; k++) {
    const g = new THREE.Group();
    g.rotation.y = -k * Math.PI / 2;
    for (const [geo, mat] of rampParts) { const m = new THREE.Mesh(geo, mat); m.receiveShadow = true; g.add(m); }
    add(g);
    // walls (always): along both sides and across the far end; 'low' wall in the merge gap keeps road-level cars off the ramp
    const base = [
      { minX: RAMP.x0, maxX: RAMP.x0 + 0.5, minZ: RAMP.z0, maxZ: RAMP.z1 - 32 },
      { minX: RAMP.x1 - 0.4, maxX: RAMP.x1 + 0.1, minZ: RAMP.z0, maxZ: RAMP.z1 + 0.6 },
      { minX: RAMP.x0 + 3, maxX: RAMP.x1, minZ: RAMP.z1, maxZ: RAMP.z1 + 0.6 },
      { minX: RAMP.x0 - 0.6, maxX: RAMP.x0 + 0.5, minZ: RAMP.z1 - 32, maxZ: RAMP.z1, lvl: 'low' },
    ];
    for (let b of base) { for (let i = 0; i < k; i++) b = turnRect(b); boxes.push(b); }
  }
  // a few cars parked up on the deck so it reads as a road (and gives you something to steer round)
  const hwCars = new Batch(GEO.box, '#ffffff');
  for (let i = 0; i < 18; i++) {
    const s = rand() < 0.5 ? -1 : 1, along = -HWY + rand() * HWY * 2, lane = (rand() < 0.5 ? -3 : 3);
    const col = pick(['#FFC845', '#C9CED6', '#2F86C9', '#F4F4F0', '#FFC845']);
    const alongZ = rand() < 0.5;
    if (Math.abs(along) > 118) continue; // keep the corners and the ramp merges clear
    // parked cars are solid for anyone up on the deck
    if (alongZ) { hwCars.add(s * HWY + lane, HWY_Y, along, 1.8, 1.4, 4.0, 0, col); boxes.push({ minX: s * HWY + lane - 0.9, maxX: s * HWY + lane + 0.9, minZ: along - 2, maxZ: along + 2, lvl: 'deck' }); }
    else { hwCars.add(along, HWY_Y, s * HWY + lane, 4.0, 1.4, 1.8, 0, col); boxes.push({ minX: along - 2, maxX: along + 2, minZ: s * HWY + lane - 0.9, maxZ: s * HWY + lane + 0.9, lvl: 'deck' }); }
  }
  add(hwCars.build());

  // ---------- edge of town: jersey barrier + hazy skyline beyond ----------
  const barrier = new Batch(GEO.box, '#C3C8CE');
  barrier.add(0, 0, EDGE + 0.6, EDGE * 2 + 2, 0.9, 0.6); barrier.add(0, 0, -EDGE - 0.6, EDGE * 2 + 2, 0.9, 0.6);
  barrier.add(EDGE + 0.6, 0, 0, 0.6, 0.9, EDGE * 2 + 2); barrier.add(-EDGE - 0.6, 0, 0, 0.6, 0.9, EDGE * 2 + 2);
  const barrierMesh = add(barrier.build());
  snowLayers.push(add(ghost(barrierMesh, snowMat(), 0.03)));
  const skyline = new Batch(GEO.box, '#ffffff');
  for (let i = 0; i < 160; i++) {
    const ang = rand() * Math.PI * 2, r = 285 + rand() * 170;
    skyline.add(Math.cos(ang) * r, 0, Math.sin(ang) * r, 18 + rand() * 24, 15 + rand() * 90, 18 + rand() * 24, 0, pick([...C.greys, ...C.glass]));
  }
  add(skyline.build());
  for (const [minX, maxX, minZ, maxZ] of [[-400, 400, EDGE + 0.3, 300], [-400, 400, -300, -EDGE - 0.3], [EDGE + 0.3, 300, -400, 400], [-300, -EDGE - 0.3, -400, 400]]) {
    boxes.push({ minX, maxX, minZ, maxZ });
  }

  const roadDry = new THREE.Color(C.road);
  let t = 0;
  return {
    group,
    heightAt,
    colliders: { boxes, circles },
    spawn: { x: -236, z: 120, heading: Math.PI }, // west ring road, heading south
    orbitTarget: [0, 0],
    orbit: { radius: 200, height: 125, lookY: 25 }, // above the towers
    traffic: { lane: 4, stopBack: 10, taxis: 3, colors: ['#FFC845', '#FFC845', '#FFC845', '#C9CED6', '#2F86C9', '#F4F4F0'] },
    mapInfo: {
      lines: LINES, roadHalf: ROAD_HALF, edge: EDGE,
      park: { minX: px0, maxX: px1, minZ: pz0, maxZ: pz1 },
      pond: { minX: pcx - 7, maxX: pcx + 19, minZ: pcz - 17, maxZ: pcz + 9 },
      highway: HWY,
      ramps: rampRects(0),
      landmark: { x: (blockSpan(LANDMARK.ix)[0] + blockSpan(LANDMARK.ix)[1]) / 2, z: (blockSpan(LANDMARK.iz)[0] + blockSpan(LANDMARK.iz)[1]) / 2, color: '#8FB3D6' },
    },
    junctions,
    signal,
    updateSignals(dt) { lightTime += dt; paintBulbs(); },
    update(time) {
      t = time;
      beacon.visible = Math.sin(t * Math.PI) > 0; // blinks once a second
    },
    setLook({ road: roadColor, snow, puddles: wet, lights }) {
      road.material.color.copy(roadColor || roadDry).multiplyScalar(0.82); // darker asphalt than the harbour
      snowMats.forEach(m => { m.opacity = snow * 0.92; });
      snowLayers.forEach(l => { l.visible = snow > 0.01; });
      crownSnow.material.opacity = snow * 0.7;
      puddleMat.opacity = wet * 0.55;
      puddleMesh.visible = wet > 0.01;
      litMat.opacity = lights * 0.95;
      litMesh.visible = lights > 0.01;
      neonMat.opacity = lights * 0.95;
      neonMesh.visible = lights > 0.01;
      lampMat.emissiveIntensity = lights * 1.2;
    },
  };
}
