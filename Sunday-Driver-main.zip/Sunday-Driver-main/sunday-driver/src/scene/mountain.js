// Mountain Village: chalets on a hillside above a river, a stone bridge on every road that crosses it,
// pine forest all around and a church clock tower as the landmark. Snowy peaks stand on the horizon.
// Same 7 × 7 road lines as the other cities (so the traffic loops work), but 10 m village roads and
// the only city with slopes: heightAt(x, z) lifts roads, houses, traffic and the player up the hill.
import * as THREE from 'three';
import { Batch, GEO, flat, mixHex, rng, ghost, snowMaterial } from './props.js';

export const LINES = [-240, -160, -80, 0, 80, 160, 240];
const ROAD_HALF = 5;            // 10 m roads, two 5 m lanes
const EDGE = 250;               // town fence, just outside the ring road
const RIVER_Z = -40;            // the river flows west → east through the middle row of blocks
const RIVER_HALF = 12;          // water z −52 … −28
const WATER_Y = -1.4;
const SQUARE = { ix: 3, iz: 1 }; // x 5…75, z −155…−85: church, clock tower, fountain

const C = {
  road: '#6E7279', line: '#F4F1E8', grass: '#8DBA6E', meadow: '#9CC47A', forest: '#5E7F4A', rock: '#8C8F86',
  bank: '#A79C86', water: '#3A8BD0', cobble: '#B8AFA2', stone: '#9C968C', stoneDark: '#7E786F',
  plaster: ['#F3EDE2', '#EFE4CF', '#E8DCC6', '#F6F2EA'], timber: ['#8A5A36', '#7A4E2E', '#9A6A42'],
  roofs: ['#C8463C', '#B83C33', '#A9443A', '#8E3B32', '#C25A3E'], pines: ['#2F6B45', '#3A7A4E', '#285E3D'],
  glass: '#3B4A5A', pole: '#34302C',
};

const smooth = (a, b, v) => { const t = Math.min(1, Math.max(0, (v - a) / (b - a))); return t * t * (3 - 2 * t); };

/** Driving height (m): level along the river, climbing 16 m to the north edge and 5 m to the south, with gentle rolls. */
export function heightAt(x, z) {
  const d = Math.abs(z - RIVER_Z);
  const hill = z < RIVER_Z ? 16 * smooth(RIVER_Z, -245, z) : 5 * smooth(RIVER_Z, 245, z);
  return hill + 2.5 * Math.sin((x + 30) / 70) * Math.cos(z / 90) * smooth(20, 60, d);
}

/** Visible ground: the driving height, cut by the river channel, rising into forested slopes outside town. */
function groundAt(x, z) {
  const d = Math.abs(z - RIVER_Z);
  let h = heightAt(x, z) - 0.06;
  h -= 3.2 * (1 - smooth(RIVER_HALF - 3, RIVER_HALF + 3, d));
  const out = Math.max(0, Math.max(Math.abs(x), Math.abs(z)) - 262);
  return h + 60 * smooth(0, 230, out) * smooth(16, 60, d); // forested hills up to 60 m; the valley stays open where the river leaves town
}

export function buildMountain(group) {
  const rand = rng(1848);
  const pick = arr => arr[Math.floor(rand() * arr.length)];
  const boxes = [], circles = [];
  const add = o => { group.add(o); return o; };
  const blockSpan = i => [LINES[i] + ROAD_HALF, LINES[i + 1] - ROAD_HALF];
  const nearJunction = (v, gap) => LINES.some(L => Math.abs(v - L) < gap);
  const overRiver = (z, pad = 0) => Math.abs(z - RIVER_Z) < RIVER_HALF + pad;

  const snowMats = [], snowLayers = [];
  const snowMat = () => { const m = snowMaterial(); snowMats.push(m); return m; };

  // ---------- terrain: one displaced, vertex-coloured mesh ----------
  {
    const SIZE = 1400, SEG = 280;
    const g = new THREE.PlaneGeometry(SIZE, SIZE, SEG, SEG).rotateX(-Math.PI / 2);
    const p = g.attributes.position;
    const col = new Float32Array(p.count * 3), c = new THREE.Color(), tmp = new THREE.Color();
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), z = p.getZ(i), h = groundAt(x, z);
      p.setY(i, h);
      const r = Math.max(Math.abs(x), Math.abs(z)), d = Math.abs(z - RIVER_Z);
      c.set(C.grass).lerp(tmp.set(C.meadow), 0.5 + 0.5 * Math.sin(x * 0.05) * Math.cos(z * 0.043));
      c.lerp(tmp.set(C.forest), smooth(250, 268, r));
      c.lerp(tmp.set(C.rock), smooth(60, 140, h) * 0.8);
      c.lerp(tmp.set(C.bank), 1 - smooth(RIVER_HALF - 1, RIVER_HALF + 3, d));
      col.set([c.r, c.g, c.b], i * 3);
    }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    g.computeVertexNormals();
    const ground = new THREE.Mesh(g, new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true }));
    ground.receiveShadow = true;
    add(ground);
    const snowGround = new THREE.Mesh(g, snowMat());
    snowGround.position.y = 0.03; snowGround.visible = false;
    snowLayers.push(add(snowGround));
  }

  /** A flat rectangle draped over the hill (roads, the square). */
  const drape = (x0, x1, z0, z1, material, lift = 0, step = 2) => {
    const w = x1 - x0, d = z1 - z0, cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
    const g = new THREE.PlaneGeometry(w, d, Math.max(1, Math.ceil(w / step)), Math.max(1, Math.ceil(d / step))).rotateX(-Math.PI / 2);
    const p = g.attributes.position;
    for (let i = 0; i < p.count; i++) p.setY(i, heightAt(p.getX(i) + cx, p.getZ(i) + cz) + lift);
    g.computeVertexNormals();
    const m = new THREE.Mesh(g, material);
    m.position.set(cx, 0, cz); m.receiveShadow = true;
    return add(m);
  };
  /** Many small rectangles [x0, z0, x1, z1] in one mesh, each corner on the hill (road markings). */
  const quads = (rects, color, lift) => {
    const pos = [], idx = [];
    for (const [x0, z0, x1, z1] of rects) {
      const b = pos.length / 3;
      for (const [x, z] of [[x0, z0], [x1, z0], [x1, z1], [x0, z1]]) pos.push(x, heightAt(x, z) + lift, z);
      idx.push(b, b + 2, b + 1, b, b + 3, b + 2);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setIndex(idx); g.computeVertexNormals();
    return add(new THREE.Mesh(g, flat(color)));
  };
  /** Lowest and highest ground under a footprint. */
  const span = (x0, x1, z0, z1) => {
    const hs = [[x0, z0], [x1, z0], [x0, z1], [x1, z1], [(x0 + x1) / 2, (z0 + z1) / 2]].map(([x, z]) => heightAt(x, z));
    return [Math.min(...hs), Math.max(...hs)];
  };

  // ---------- roads, centre dashes, the square ----------
  const roadMat = new THREE.MeshLambertMaterial({ color: C.road, flatShading: true });
  const R = EDGE - 5;
  for (const L of LINES) {
    drape(L - ROAD_HALF, L + ROAD_HALF, -R, R, roadMat, 0);
    drape(-R, R, L - ROAD_HALF, L + ROAD_HALF, roadMat, 0.004);
  }
  const dashes = [];
  for (const L of LINES) for (let t = -238; t < 238; t += 7) {
    if (nearJunction(t, 9) || nearJunction(t + 3, 9)) continue;
    dashes.push([L - 0.12, t, L + 0.12, t + 3], [t, L - 0.12, t + 3, L + 0.12]);
  }
  quads(dashes, C.line, 0.03);
  const [sx0, sx1] = blockSpan(SQUARE.ix), [sz0, sz1] = blockSpan(SQUARE.iz);
  drape(sx0, sx1, sz0, sz1, flat(C.cobble), 0.02, 3);

  // ---------- river, bridges ----------
  const water = new THREE.Mesh(new THREE.PlaneGeometry(1400, RIVER_HALF * 2 + 6).rotateX(-Math.PI / 2), flat(C.water));
  water.position.set(0, WATER_Y, RIVER_Z);
  add(water);
  const deck = new Batch(GEO.box, C.stone), parapet = new Batch(GEO.box, C.stoneDark), piers = new Batch(GEO.box, C.stoneDark);
  const bridgeLen = (RIVER_HALF + 3) * 2;
  for (const L of LINES) {
    deck.add(L, -1.05, RIVER_Z, ROAD_HALF * 2 + 1.2, 1.0, bridgeLen);
    piers.add(L, WATER_Y - 2, RIVER_Z, 3, 2, 3);
    for (const s of [-1, 1]) {
      parapet.add(L + s * (ROAD_HALF + 0.4), -0.1, RIVER_Z, 0.6, 1.1, bridgeLen);
      boxes.push({ minX: L + s * (ROAD_HALF + 0.4) - 0.3, maxX: L + s * (ROAD_HALF + 0.4) + 0.3, minZ: RIVER_Z - bridgeLen / 2, maxZ: RIVER_Z + bridgeLen / 2 });
    }
  }
  [deck, piers].forEach(b => add(b.build()));
  const parapetMesh = add(parapet.build());
  snowLayers.push(add(ghost(parapetMesh, snowMat(), 0.03)));
  // you can't drive into the river: one collider between each pair of bridges
  for (let i = 0; i < LINES.length - 1; i++) {
    boxes.push({ minX: LINES[i] + ROAD_HALF + 0.7, maxX: LINES[i + 1] - ROAD_HALF - 0.7, minZ: RIVER_Z - RIVER_HALF - 1, maxZ: RIVER_Z + RIVER_HALF + 1 });
  }
  // the old covered bridge on the main street (x = 0): timber posts and a red roof over the road
  const timber = new Batch(GEO.box, C.timber[0]);
  for (const s of [-1, 1]) for (let z = RIVER_Z - 14; z <= RIVER_Z + 14; z += 4) timber.add(s * (ROAD_HALF + 0.4), 1.0, z, 0.35, 4.2, 0.35);
  for (const s of [-1, 1]) timber.add(s * (ROAD_HALF + 0.4), 5.0, RIVER_Z, 0.4, 0.4, bridgeLen);

  // ---------- houses ----------
  const prism = new THREE.ExtrudeGeometry(new THREE.Shape([new THREE.Vector2(-0.5, 0), new THREE.Vector2(0.5, 0), new THREE.Vector2(0, 1)]), { depth: 1, bevelEnabled: false }).translate(0, 0, -0.5);
  const plinths = new Batch(GEO.box, C.stone), walls = new Batch(GEO.box, '#ffffff'), roofs = new Batch(prism, '#ffffff');
  const windows = new Batch(GEO.plane, C.glass), lit = new Batch(GEO.plane, '#FFD98A'), chimneys = new Batch(GEO.box, C.stoneDark);
  const roof = (x, y, z, across, h, along, ridgeAlongX, color) => roofs.add(x, y, z, across, h, along, ridgeAlongX ? Math.PI / 2 : 0, color);
  roof(0, 5.2, RIVER_Z, ROAD_HALF * 2 + 2.4, 2.6, bridgeLen + 1, false, C.roofs[1]);
  add(timber.build());

  /** A chalet: stone plinth on the slope, plaster ground floor, timber upper floor, red gable roof.
   *  facing: the side its front faces ('n' = −Z, 's' = +Z, 'e' = +X, 'w' = −X); w runs along the street. */
  function house(cx, cz, w, d, facing) {
    const alongX = facing === 'n' || facing === 's';
    const sxW = alongX ? w : d, szW = alongX ? d : w;
    const [lo, hi] = span(cx - sxW / 2, cx + sxW / 2, cz - szW / 2, cz + szW / 2);
    const base = hi + 0.5;
    plinths.add(cx, lo - 0.6, cz, sxW + 0.4, base - lo + 0.6, szW + 0.4);
    const ground = 3.0, upper = rand() < 0.7 ? 2.8 : 0;
    walls.add(cx, base, cz, sxW, ground, szW, 0, pick(C.plaster));
    if (upper) walls.add(cx, base + ground, cz, sxW + 0.2, upper, szW + 0.2, 0, pick(C.timber));
    const top = base + ground + upper;
    roof(cx, top, cz, d + 1.4, 2.6 + d * 0.18, w + 1.2, alongX, pick(C.roofs));
    if (rand() < 0.6) chimneys.add(cx + (alongX ? w * 0.25 : 0), top + 1, cz + (alongX ? 0 : w * 0.25), 0.8, 2.6, 0.8);
    // windows on the two long sides, one row per floor; some glow at night
    const n = Math.max(2, Math.floor(w / 3));
    for (const side of [-1, 1]) {
      const rot = alongX ? (side > 0 ? 0 : Math.PI) : (side > 0 ? Math.PI / 2 : -Math.PI / 2);
      for (let k = 0; k < n; k++) {
        const a = (k + 0.5) / n * w - w / 2;
        for (const fy of upper ? [1.6, ground + 1.4] : [1.6]) {
          const off = (alongX ? szW : sxW) / 2 + (fy > ground ? 0.13 : 0.03);
          const x = alongX ? cx + a : cx + side * off, z = alongX ? cz + side * off : cz + a;
          windows.add(x, base + fy, z, 1.1, 1.2, 1, rot);
          if (rand() < 0.35) lit.add(x + (alongX ? 0 : side * 0.01), base + fy, z + (alongX ? side * 0.01 : 0), 1.1, 1.2, 1, rot);
        }
      }
    }
    boxes.push({ minX: cx - sxW / 2 - 0.2, maxX: cx + sxW / 2 + 0.2, minZ: cz - szW / 2 - 0.2, maxZ: cz + szW / 2 + 0.2 });
  }

  // ---------- pines ----------
  const CONE = new THREE.ConeGeometry(1, 1, 7).translate(0, 0.5, 0);
  const trunks = new Batch(GEO.cyl6, '#6A4A30'), lower = new Batch(CONE, '#ffffff'), upperCones = new Batch(CONE, '#ffffff');
  function pine(x, z, s, solid) {
    const y = groundAt(x, z) - 0.2, c = pick(C.pines);
    trunks.add(x, y, z, 0.5 * s, 1.8 * s, 0.5 * s);
    lower.add(x, y + 1.3 * s, z, 2.1 * s, 4.2 * s, 2.1 * s, rand() * Math.PI, c);
    upperCones.add(x, y + 3.6 * s, z, 1.4 * s, 3.4 * s, 1.4 * s, rand() * Math.PI, mixHex(c, '#ffffff', 0.06));
    if (solid) circles.push({ x, z, r: 0.5 * s });
  }

  for (let ix = 0; ix < 6; ix++) for (let iz = 0; iz < 6; iz++) {
    if (ix === SQUARE.ix && iz === SQUARE.iz) continue;
    const [x0, x1] = blockSpan(ix), [z0, z1] = blockSpan(iz);
    const mx = (x0 + x1) / 2, mz = (z0 + z1) / 2;
    const dense = Math.hypot(mx - 40, mz + 80) < 190 ? 0.85 : 0.55; // busier round the square
    const riverRow = overRiver(mz, 10);
    for (const off of [-22, 0, 22]) {
      for (const [facing, ok] of [['n', true], ['s', true]]) {
        if (!ok || rand() > dense) continue;
        const w = 8 + rand() * 4, d = riverRow ? 7 + rand() * 1.5 : 7 + rand() * 2.5;
        const cz = facing === 'n' ? z0 + 3 + d / 2 : z1 - 3 - d / 2;
        house(mx + off, cz, w, d, facing);
      }
    }
    if (!riverRow) for (const facing of ['w', 'e']) {
      if (rand() > dense) continue;
      const w = 8 + rand() * 3, d = 7 + rand() * 2;
      house(facing === 'w' ? x0 + 3 + d / 2 : x1 - 3 - d / 2, mz, w, d, facing);
    }
    // a few pines in the gardens (and along the river banks)
    const count = riverRow ? 10 : 4 + Math.floor(rand() * 5);
    for (let i = 0; i < count; i++) {
      const x = riverRow ? x0 + 4 + rand() * (x1 - x0 - 8) : x0 + 15 + rand() * (x1 - x0 - 30); // clear of the side houses
      const z = riverRow ? (rand() < 0.5 ? RIVER_Z - RIVER_HALF - 4 - rand() * 4 : RIVER_Z + RIVER_HALF + 4 + rand() * 4) : mz + (rand() - 0.5) * 22;
      if (!riverRow && Math.abs(x - mx) < 15 && rand() < 0.5) continue;
      pine(x, z, 0.8 + rand() * 0.5, true);
    }
  }
  // forest all round the town and up the slopes (not on the river)
  for (let i = 0; i < 6500; i++) {
    const x = (rand() * 2 - 1) * 640, z = (rand() * 2 - 1) * 640;
    if (Math.max(Math.abs(x), Math.abs(z)) < 258 || overRiver(z, 6)) continue;
    pine(x, z, 1 + rand() * 0.9, false);
  }

  // ---------- the square: church, clock tower, fountain ----------
  const hands = [];
  let landmark;
  {
    const nx = 48, nz = -118;                          // nave centre: 14 m wide, 28 m long, along Z
    let [lo, hi] = span(nx - 7, nx + 7, nz - 14, nz + 14);
    plinths.add(nx, lo - 0.6, nz, 14.6, hi - lo + 1.2, 28.6);
    walls.add(nx, hi + 0.6, nz, 14, 9, 28, 0, '#F3EDE2');
    roof(nx, hi + 9.6, nz, 16, 7, 29.5, false, '#8E3B32');
    for (const s of [-1, 1]) for (let k = 0; k < 4; k++) {
      windows.add(nx + s * 7.03, hi + 5.2, nz - 9 + k * 6, 1.4, 3.6, 1, s > 0 ? Math.PI / 2 : -Math.PI / 2);
      lit.add(nx + s * 7.04, hi + 5.2, nz - 9 + k * 6, 1.4, 3.6, 1, s > 0 ? Math.PI / 2 : -Math.PI / 2);
    }
    boxes.push({ minX: nx - 7.3, maxX: nx + 7.3, minZ: nz - 14.3, maxZ: nz + 14.3 });

    const tx = 48, tz = -100;                          // tower in front of the nave, facing the river
    [lo, hi] = span(tx - 3.5, tx + 3.5, tz - 3.5, tz + 3.5);
    const SHAFT = 26;
    plinths.add(tx, lo - 0.6, tz, 8, hi - lo + 1.2, 8);
    walls.add(tx, hi + 0.6, tz, 7, SHAFT, 7, 0, '#D9D1C2');
    walls.add(tx, hi + 0.6 + SHAFT, tz, 7.6, 0.6, 7.6, 0, C.stoneDark);
    const belfry = hi + 0.6 + SHAFT + 0.6;
    walls.add(tx, belfry, tz, 6.4, 4.4, 6.4, 0, '#D9D1C2');
    for (const r of [0, Math.PI / 2, Math.PI, -Math.PI / 2]) {
      windows.add(tx + Math.sin(r) * 3.22, belfry + 2.2, tz + Math.cos(r) * 3.22, 2, 3, 1, r);
    }
    const spire = new THREE.Mesh(new THREE.ConeGeometry(4.9, 13, 4).rotateY(Math.PI / 4).translate(0, 6.5, 0), flat('#3E6B5A'));
    spire.position.set(tx, belfry + 4.4, tz); add(spire);
    landmark = spire;
    const cross = new Batch(GEO.box, '#E8C35A');
    cross.add(tx, belfry + 17.4, tz, 0.25, 2.4, 0.25); cross.add(tx, belfry + 18.4, tz, 1.3, 0.25, 0.25);
    add(cross.build());
    // four clock faces showing the game's time
    const faceGeo = new THREE.CircleGeometry(1.9, 20), rimGeo = new THREE.RingGeometry(1.9, 2.15, 20);
    const hourGeo = new THREE.BoxGeometry(0.22, 1.05, 0.06).translate(0, 0.45, 0.06);
    const minGeo = new THREE.BoxGeometry(0.16, 1.6, 0.06).translate(0, 0.7, 0.1);
    for (const r of [0, Math.PI / 2, Math.PI, -Math.PI / 2]) {
      const f = new THREE.Group();
      f.position.set(tx + Math.sin(r) * 3.52, hi + 0.6 + SHAFT - 3.4, tz + Math.cos(r) * 3.52);
      f.rotation.y = r;
      f.add(new THREE.Mesh(faceGeo, flat('#FBF7EC')), new THREE.Mesh(rimGeo, flat('#C9A44C')));
      const hour = new THREE.Mesh(hourGeo, flat('#2A2622')), minute = new THREE.Mesh(minGeo, flat('#2A2622'));
      f.add(hour, minute); hands.push({ hour, minute });
      add(f);
    }
    boxes.push({ minX: tx - 4, maxX: tx + 4, minZ: tz - 4, maxZ: tz + 4 });

    const fx = 22, fz = -118, fy = heightAt(fx, fz);  // fountain
    const basin = new THREE.Mesh(new THREE.CylinderGeometry(4, 4.3, 0.9, 12).translate(0, 0.45, 0), flat(C.stone));
    basin.position.set(fx, fy - 0.1, fz); add(basin);
    const pool = new THREE.Mesh(new THREE.CircleGeometry(3.6, 12).rotateX(-Math.PI / 2), flat('#5FA8DE'));
    pool.position.set(fx, fy + 0.7, fz); add(pool);
    const column = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.6, 2.6, 8).translate(0, 1.3, 0), flat(C.stone));
    column.position.set(fx, fy, fz); add(column);
    circles.push({ x: fx, z: fz, r: 4.3 });
  }

  add(plinths.build()); add(walls.build()); add(windows.build()); add(chimneys.build());
  const roofMesh = add(roofs.build());
  snowLayers.push(add(ghost(roofMesh, snowMat(), 0.05)));
  const litMesh = lit.build();
  const litMat = new THREE.MeshBasicMaterial({ color: '#FFD98A', transparent: true, opacity: 0, depthWrite: false });
  litMesh.material = litMat; litMesh.visible = false;
  add(litMesh);
  add(trunks.build());
  const lowerMesh = add(lower.build()), upperMesh = add(upperCones.build());
  const pineSnow = [ghost(lowerMesh, snowMat(), 0.08), ghost(upperMesh, snowMat(), 0.08)];
  pineSnow.forEach(m => snowLayers.push(add(m)));

  // ---------- lantern posts ----------
  const posts = new Batch(GEO.cyl6, C.pole), lanterns = new Batch(GEO.box, '#F2E6C8');
  for (const L of LINES) for (let t = -220; t <= 220; t += 40) {
    if (nearJunction(t, 12) || overRiver(t, 6)) continue;
    for (const [x, z] of [[L + ROAD_HALF + 1.2, t], [t, L + ROAD_HALF + 1.2]]) {
      const y = heightAt(x, z) - 0.1;
      posts.add(x, y, z, 0.18, 4.4, 0.18);
      lanterns.add(x, y + 4.3, z, 0.55, 0.75, 0.55);
      circles.push({ x, z, r: 0.3 });
    }
  }
  add(posts.build());
  const lanternMesh = add(lanterns.build());
  const lanternMat = new THREE.MeshLambertMaterial({ color: '#F2E6C8', emissive: '#FFC86A', emissiveIntensity: 0, flatShading: true });
  lanternMesh.material = lanternMat;

  // ---------- traffic lights: only the nine junctions in the middle of the village ----------
  const MID = [-80, 0, 80];
  const tPoles = new Batch(GEO.cyl6, '#2F3946'), tBoxes = new Batch(GEO.box, '#1F252D');
  const bulbs = new THREE.InstancedMesh(GEO.sphere, new THREE.MeshBasicMaterial({ color: '#ffffff' }), MID.length * MID.length * 6);
  bulbs.frustumCulled = false;
  const bulbInfo = [], junctions = [];
  const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _s = new THREE.Vector3(0.32, 0.32, 0.32);
  for (const a of MID) for (const b of MID) {
    const x = a + ROAD_HALF + 1.4, z = b + ROAD_HALF + 1.4, y = heightAt(x, z) - 0.1;
    const j = { x: a, z: b, offset: (((a + b) / 80) % 2 + 2) % 2 * 10 };
    junctions.push(j);
    tPoles.add(x, y, z, 0.22, 5.2, 0.22);
    tBoxes.add(x, y + 5.2, z, 0.55, 1.4, 0.55);
    for (const [ox, oz, axis] of [[-0.29, 0, 'ew'], [0, -0.29, 'ns']]) {
      [['red', 6.2], ['amber', 5.78], ['green', 5.36]].forEach(([kind, by]) => {
        _m.compose(new THREE.Vector3(x + ox, y + by, z + oz), _q, _s);
        bulbs.setMatrixAt(bulbInfo.length, _m);
        bulbInfo.push({ j, axis, kind });
      });
    }
    circles.push({ x, z, r: 0.35 });
  }
  bulbs.count = bulbInfo.length;
  [tPoles, tBoxes].forEach(b => add(b.build()));
  add(bulbs);
  const BULB = {
    red: [new THREE.Color('#FF4D4D'), new THREE.Color('#4A2626')],
    amber: [new THREE.Color('#FFC845'), new THREE.Color('#4A4126')],
    green: [new THREE.Color('#3DDC84'), new THREE.Color('#1F3D2C')],
  };
  let lightTime = 0;
  const signal = (j, axis) => {
    const p = (lightTime + j.offset) % 20;
    if (axis === 'ns') return p < 8 ? 'green' : p < 10 ? 'amber' : 'red';
    return p < 10 ? 'red' : p < 18 ? 'green' : 'amber';
  };
  const paintBulbs = () => {
    bulbInfo.forEach((b, i) => bulbs.setColorAt(i, BULB[b.kind][signal(b.j, b.axis) === b.kind ? 0 : 1]));
    bulbs.instanceColor.needsUpdate = true;
  };
  bulbs.setColorAt(0, BULB.red[1]);
  paintBulbs();

  // ---------- town fence (timber posts and rails following the slope) + invisible edge walls ----------
  const fence = new Batch(GEO.box, '#8A6A48');
  for (let t = -EDGE; t < EDGE; t += 4) {
    for (const s of [-1, 1]) {
      const e = s * EDGE;
      if (!overRiver(t, 2)) {
        const h0 = heightAt(e, t), h1 = heightAt(e, t + 4);
        fence.add(e, h0 - 0.2, t, 0.25, 1.4, 0.25);
        fence.add(e, (h0 + h1) / 2 + 0.75, t + 2, 0.12, 0.14, 4.05, 0, null, -Math.atan2(h1 - h0, 4));
      }
      const g0 = heightAt(t, e), g1 = heightAt(t + 4, e);
      fence.add(t, g0 - 0.2, e, 0.25, 1.4, 0.25);
      fence.add(t + 2, (g0 + g1) / 2 + 0.75, e, 4.05, 0.14, 0.12, 0, null, 0, Math.atan2(g1 - g0, 4));
    }
  }
  const fenceMesh = add(fence.build());
  snowLayers.push(add(ghost(fenceMesh, snowMat(), 0.03)));
  for (const [minX, maxX, minZ, maxZ] of [[-400, 400, EDGE, 320], [-400, 400, -320, -EDGE], [EDGE, 320, -400, 400], [-320, -EDGE, -400, 400]]) {
    boxes.push({ minX, maxX, minZ, maxZ });
  }

  // ---------- snowy peaks on the horizon: they travel with the camera, like the sky ----------
  // Each peak fades into the haze colour towards its foot (and a little all over), so it rises out of the
  // fogged horizon instead of floating above it.
  const peaks = new THREE.Group();
  const haze = { hazeColor: { value: new THREE.Color('#D3F0FB') }, haze: { value: 0.3 } };
  const hazy = (color, fade) => {
    const m = new THREE.MeshLambertMaterial({ color, flatShading: true, fog: false });
    m.onBeforeCompile = sh => {
      Object.assign(sh.uniforms, haze, { fade: { value: fade } });
      sh.vertexShader = 'varying float vH;\n' + sh.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\nvH = position.y;');
      sh.fragmentShader = 'varying float vH;\nuniform vec3 hazeColor;\nuniform float haze;\nuniform float fade;\n' + sh.fragmentShader.replace(
        '#include <dithering_fragment>',
        '#include <dithering_fragment>\ngl_FragColor.rgb = mix(gl_FragColor.rgb, hazeColor, clamp(max(haze, fade * (1.0 - smoothstep(0.05, 0.62, vH))), 0.0, 1.0));');
    };
    return m;
  };
  const rockMats = ['#7A8F9E', '#8C9FAD', '#6F8494'].map(c => hazy(c, 1)), capMat = hazy('#F4F6F8', 0);
  const PEAK = new THREE.ConeGeometry(1, 1, 7).translate(0, 0.5, 0);
  for (let i = 0; i < 16; i++) {
    const ang = (i / 16) * Math.PI * 2 + rand() * 0.25, dist = 370 + rand() * 20; // well inside the 500 m sky dome
    const r = 100 + rand() * 50, h = 140 + rand() * 110, rot = rand() * Math.PI;
    const m = new THREE.Mesh(PEAK, pick(rockMats));
    m.position.set(Math.cos(ang) * dist, -40, Math.sin(ang) * dist); m.scale.set(r, h, r); m.rotation.y = rot;
    const cap = new THREE.Mesh(PEAK, capMat);
    cap.position.set(m.position.x, -40 + h * 0.68, m.position.z); cap.scale.set(r * 0.33, h * 0.33, r * 0.33); cap.rotation.y = rot;
    peaks.add(m, cap);
  }
  add(peaks);

  const roadDry = new THREE.Color(C.road);
  let murk = 0; // rain or snow thickens the haze on the peaks
  return {
    group,
    heightAt,
    colliders: { boxes, circles },
    spawn: { x: -237.4, z: 120, heading: Math.PI }, // west ring road, heading north towards the river
    orbitTarget: [40, -105],                     // Start-screen camera circles the church square
    orbit: { radius: 140, height: 70, lookY: 12 },
    traffic: { lane: 2.6, stopBack: 8, colors: ['#C8463C', '#2F6B45', '#F3EDE2', '#3A8BD0', '#E8C35A', '#8A5A36'] },
    mapInfo: {
      lines: LINES, roadHalf: ROAD_HALF, edge: EDGE,
      water: { minX: -2000, maxX: 2000, minZ: RIVER_Z - RIVER_HALF, maxZ: RIVER_Z + RIVER_HALF },
      park: { minX: sx0, maxX: sx1, minZ: sz0, maxZ: sz1 },
      landmark: { x: landmark.position.x, z: landmark.position.z, color: '#E8604C' },
    },
    junctions,
    signal,
    updateSignals(dt) { lightTime += dt; paintBulbs(); },
    /** time: seconds; clockMinutes: the game clock (for the tower); camera: keeps the peaks on the horizon */
    update(time, { clockMinutes = 600, camera, fog } = {}) {
      const m = ((clockMinutes % 1440) + 1440) % 1440;
      for (const h of hands) {
        h.hour.rotation.z = -((m % 720) / 720) * Math.PI * 2;
        h.minute.rotation.z = -((m % 60) / 60) * Math.PI * 2;
      }
      if (camera) peaks.position.set(camera.position.x, 0, camera.position.z);
      if (fog) { haze.hazeColor.value.copy(fog.color); haze.haze.value = 0.3 + 0.5 * murk; }
    },
    setLook({ road: roadColor, snow, puddles, lights }) {
      murk = Math.max(puddles, snow);
      roadMat.color.copy(roadColor || roadDry).multiplyScalar(0.9);
      snowMats.forEach(m => { m.opacity = snow * 0.92; });
      snowLayers.forEach(l => { l.visible = snow > 0.01; });
      pineSnow.forEach(l => { l.material.opacity = snow * 0.75; });
      litMat.opacity = lights * 0.95;
      litMesh.visible = lights > 0.01;
      lanternMat.emissiveIntensity = lights * 1.3;
    },
  };
}
