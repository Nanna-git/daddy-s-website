// Rain streaks (LineSegments) and snow flakes (Points) in a box that travels with the camera.
// Drops live in world space and wrap around the camera, so they keep proper parallax while driving.
import * as THREE from 'three';

const BOX = 25;     // half-size of the particle box around the camera (m)
const TOP = 22;     // height of the box (m)

function wrap(v, centre) {
  const d = v - centre;
  if (d > BOX) return v - BOX * 2;
  if (d < -BOX) return v + BOX * 2;
  return v;
}

export function createParticles(scene, { rainCount = 1400, snowCount = 1500 } = {}) {
  // ---- rain ----
  const rain = new Float32Array(rainCount * 3);
  for (let i = 0; i < rainCount; i++) {
    rain[i * 3] = (Math.random() * 2 - 1) * BOX;
    rain[i * 3 + 1] = Math.random() * TOP;
    rain[i * 3 + 2] = (Math.random() * 2 - 1) * BOX;
  }
  const rainPos = new Float32Array(rainCount * 6);
  const rainGeo = new THREE.BufferGeometry();
  rainGeo.setAttribute('position', new THREE.BufferAttribute(rainPos, 3));
  const rainMat = new THREE.LineBasicMaterial({ color: '#DCE6F2', transparent: true, opacity: 0, depthWrite: false });
  const rainLines = new THREE.LineSegments(rainGeo, rainMat);
  rainLines.frustumCulled = false;
  scene.add(rainLines);

  // ---- snow ----
  const snowPos = new Float32Array(snowCount * 3);
  const sway = new Float32Array(snowCount);
  for (let i = 0; i < snowCount; i++) {
    snowPos[i * 3] = (Math.random() * 2 - 1) * BOX;
    snowPos[i * 3 + 1] = Math.random() * TOP;
    snowPos[i * 3 + 2] = (Math.random() * 2 - 1) * BOX;
    sway[i] = Math.random() * Math.PI * 2;
  }
  const snowGeo = new THREE.BufferGeometry();
  snowGeo.setAttribute('position', new THREE.BufferAttribute(snowPos, 3));
  const snowMat = new THREE.PointsMaterial({ color: '#FFFFFF', size: 0.14, transparent: true, opacity: 0, depthWrite: false });
  const snowPoints = new THREE.Points(snowGeo, snowMat);
  snowPoints.frustumCulled = false;
  scene.add(snowPoints);

  let t = 0;
  return {
    /** Low quality draws half the particles. */
    setQuality(q) {
      const k = q === 'low' ? 0.5 : 1;
      rainGeo.setDrawRange(0, Math.floor(rainCount * k) * 2);
      snowGeo.setDrawRange(0, Math.floor(snowCount * k));
    },
    update(dt, camPos, rainAmount, snowAmount) {
      t += dt;
      rainLines.position.y = snowPoints.position.y = Math.max(0, camPos.y - 10); // hills: keep the box around the camera
      rainLines.visible = rainAmount > 0.01;
      rainMat.opacity = rainAmount * 0.55;
      if (rainLines.visible) {
        for (let i = 0; i < rainCount; i++) {
          let x = wrap(rain[i * 3], camPos.x), y = rain[i * 3 + 1] - 24 * dt, z = wrap(rain[i * 3 + 2], camPos.z);
          if (y < 0) y += TOP;
          rain[i * 3] = x; rain[i * 3 + 1] = y; rain[i * 3 + 2] = z;
          const j = i * 6;
          rainPos[j] = x; rainPos[j + 1] = y; rainPos[j + 2] = z;
          rainPos[j + 3] = x + 0.08; rainPos[j + 4] = y - 0.75; rainPos[j + 5] = z;
        }
        rainGeo.attributes.position.needsUpdate = true;
      }

      snowPoints.visible = snowAmount > 0.01;
      snowMat.opacity = snowAmount * 0.95;
      if (snowPoints.visible) {
        for (let i = 0; i < snowCount; i++) {
          const j = i * 3;
          let y = snowPos[j + 1] - 1.3 * dt;
          if (y < 0) y += TOP;
          snowPos[j] = wrap(snowPos[j] + Math.sin(t * 0.8 + sway[i]) * 0.5 * dt, camPos.x);
          snowPos[j + 1] = y;
          snowPos[j + 2] = wrap(snowPos[j + 2] + Math.cos(t * 0.6 + sway[i]) * 0.3 * dt, camPos.z);
        }
        snowGeo.attributes.position.needsUpdate = true;
      }
    },
  };
}
