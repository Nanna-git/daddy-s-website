// Shared low-poly props: one geometry + one material per kind, repeated with InstancedMesh.
import * as THREE from 'three';

const matCache = new Map();

/** Flat-shaded material, shared per colour. */
export function flat(hex, opts = {}) {
  const key = hex + JSON.stringify(opts);
  if (!matCache.has(key)) {
    matCache.set(key, new THREE.MeshLambertMaterial({ color: hex, flatShading: true, ...opts }));
  }
  return matCache.get(key);
}

export const GEO = {
  box: new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0), // base sits on y = 0
  plane: new THREE.PlaneGeometry(1, 1),                       // faces +Z
  cyl6: new THREE.CylinderGeometry(0.5, 0.5, 1, 6).translate(0, 0.5, 0),
  cyl8: new THREE.CylinderGeometry(0.5, 0.5, 1, 8).translate(0, 0.5, 0),
  crown: new THREE.IcosahedronGeometry(1, 0),
  sphere: new THREE.SphereGeometry(0.5, 8, 6),
};

const _m = new THREE.Matrix4();
const _q = new THREE.Quaternion();
const _e = new THREE.Euler();
const _p = new THREE.Vector3();
const _s = new THREE.Vector3();
const _c = new THREE.Color();

/**
 * Collects many copies of one geometry, then builds a single InstancedMesh.
 * If any copy has its own colour, the material is white and colours go per instance.
 */
export class Batch {
  constructor(geometry, color = '#ffffff', { castShadow = false, receiveShadow = false } = {}) {
    this.geometry = geometry;
    this.color = color;
    this.items = [];
    this.perInstanceColor = false;
    this.castShadow = castShadow;
    this.receiveShadow = receiveShadow;
  }

  add(x, y, z, sx = 1, sy = 1, sz = 1, rotY = 0, color = null, rotX = 0, rotZ = 0) {
    if (color) this.perInstanceColor = true;
    this.items.push({ x, y, z, sx, sy, sz, rotY, rotX, rotZ, color });
    return this;
  }

  build() {
    const material = this.perInstanceColor ? flat('#ffffff') : flat(this.color);
    const mesh = new THREE.InstancedMesh(this.geometry, material, Math.max(1, this.items.length));
    mesh.count = this.items.length;
    this.items.forEach((it, i) => {
      _e.set(it.rotX, it.rotY, it.rotZ);
      _q.setFromEuler(_e);
      _m.compose(_p.set(it.x, it.y, it.z), _q, _s.set(it.sx, it.sy, it.sz));
      mesh.setMatrixAt(i, _m);
      if (this.perInstanceColor) mesh.setColorAt(i, _c.set(it.color || this.color));
    });
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    mesh.castShadow = this.castShadow;
    mesh.receiveShadow = this.receiveShadow;
    mesh.frustumCulled = false; // instances spread across the whole map
    return mesh;
  }
}

/** A see-through white material for snow layers; set .opacity to fade it in. */
export function snowMaterial() {
  return new THREE.MeshLambertMaterial({
    color: '#FFFFFF', flatShading: true, transparent: true, opacity: 0, depthWrite: false,
    polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2,
  });
}

/** Copy of an InstancedMesh (same instances) with another material, lifted by dy. */
export function ghost(src, material, dy = 0.01) {
  const g = new THREE.InstancedMesh(src.geometry, material, src.count);
  g.instanceMatrix.array.set(src.instanceMatrix.array);
  g.instanceMatrix.needsUpdate = true;
  g.count = src.count;
  g.position.y = dy;
  g.frustumCulled = false;
  g.visible = false;
  return g;
}

/** Mix two hex colours, t = 0..1. */
export function mixHex(a, b, t) {
  return '#' + _c.set(a).lerp(new THREE.Color(b), t).getHexString();
}

/** Small deterministic random so the city looks the same every load. */
export function rng(seed = 1) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => (s = (s * 16807) % 2147483647) / 2147483647;
}

/** Height and tilt for a car-like object { x, z, fx, fz } on a city with slopes (heightAt), or flat ground.
 *  slew limits how far o.y may move per call. Sets o.y, o.pitch (nose up < 0, as rotation.x) and o.bank (as rotation.z). */
export function groundPose(o, h, half = 1.6, side = 0.9, slew = Infinity) {
  if (!h) { o.y = 0; o.pitch = 0; o.bank = 0; return o; }
  const fx = o.fx ?? Math.sin(o.heading), fz = o.fz ?? Math.cos(o.heading);
  const y0 = o.y || 0, heightAt = (x, z) => h(x, z, y0); // a city with a highway needs to know which level you are on
  o.y = y0 + Math.max(-slew, Math.min(slew, heightAt(o.x, o.z) - y0)); // slew: most the height may change in one call (steps between levels)
  o.pitch = -Math.atan((heightAt(o.x + fx * half, o.z + fz * half) - heightAt(o.x - fx * half, o.z - fz * half)) / (2 * half));
  o.bank = Math.atan((heightAt(o.x + fz * side, o.z - fx * side) - heightAt(o.x - fz * side, o.z + fx * side)) / (2 * side));
  return o;
}
