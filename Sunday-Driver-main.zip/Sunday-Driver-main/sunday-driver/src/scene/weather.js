// The 4 weather presets (Reference D) and a 2.5 s blend between them.
import * as THREE from 'three';

export const WEATHER_ORDER = ['sunny', 'cloudy', 'rainy', 'snowy'];

export const PRESETS = {
  sunny: {
    sky: '#8ED1F2', horizon: '#D3F0FB', fog: '#DCEFF8', fogNear: 60, fogFar: 220,
    sun: '#FFF1D6', sunIntensity: 2.4, hemiSky: '#CFEFFF', hemiGround: '#D9C9A3', hemiIntensity: 1.1,
    shadow: 1, sunDisc: 1, road: '#7B818C', clouds: 3, cloud: '#FFFFFF',
    rain: 0, snow: 0, lights: 0, grip: 1, brake: 1,
  },
  cloudy: {
    sky: '#C5CDD6', horizon: '#DFE4E9', fog: '#D9DEE4', fogNear: 50, fogFar: 170,
    sun: '#E8ECF0', sunIntensity: 0.9, hemiSky: '#DDE3EA', hemiGround: '#B8B4A8', hemiIntensity: 1.5,
    shadow: 0.25, sunDisc: 0.12, road: '#737983', clouds: 9, cloud: '#EEF1F4',
    rain: 0, snow: 0, lights: 0, grip: 1, brake: 1,
  },
  rainy: {
    sky: '#5A6777', horizon: '#7A8694', fog: '#7C8896', fogNear: 30, fogFar: 120,
    sun: '#C5D0DC', sunIntensity: 0.5, hemiSky: '#8E9AAA', hemiGround: '#5E5A52', hemiIntensity: 1.25,
    shadow: 0.1, sunDisc: 0, road: '#444A54', clouds: 9, cloud: '#4A5563',
    rain: 1, snow: 0, lights: 1, grip: 0.7, brake: 1.4,
  },
  snowy: {
    sky: '#D8DFE6', horizon: '#EEF2F5', fog: '#E9EEF2', fogNear: 20, fogFar: 90,
    sun: '#E6EEF8', sunIntensity: 0.8, hemiSky: '#E8EEF5', hemiGround: '#B9C0C8', hemiIntensity: 1.5,
    shadow: 0.2, sunDisc: 0.08, road: '#8A9099', clouds: 7, cloud: '#F4F6F8',
    rain: 0, snow: 1, lights: 1, grip: 0.45, brake: 1.8,
  },
};

const BLEND_SECONDS = 2.5;
const isColor = v => typeof v === 'string' && v[0] === '#';

/** Holds the current mixed weather values and fades to a new preset over 2.5 s. */
export class WeatherBlend {
  constructor(name = 'sunny') {
    this.name = name;
    this.from = this.snapshot(PRESETS[name]);
    this.to = this.from;
    this.t = 1;
    this.current = this.snapshot(PRESETS[name]);
  }

  snapshot(p) {
    const o = {};
    for (const [k, v] of Object.entries(p)) o[k] = isColor(v) ? new THREE.Color(v) : v;
    return o;
  }

  clone(values) {
    const o = {};
    for (const [k, v] of Object.entries(values)) o[k] = v instanceof THREE.Color ? v.clone() : v;
    return o;
  }

  set(name) {
    if (!PRESETS[name] || name === this.name) return;
    this.name = name;
    this.from = this.clone(this.current); // start from wherever a running blend is
    this.to = this.snapshot(PRESETS[name]);
    this.t = 0;
  }

  /** Jump straight to a preset (restoring a saved journey). */
  snap(name) {
    if (!PRESETS[name]) return;
    this.name = name;
    this.from = this.snapshot(PRESETS[name]);
    this.to = this.snapshot(PRESETS[name]);
    this.current = this.snapshot(PRESETS[name]);
    this.t = 1;
  }

  update(dt) {
    if (this.t < 1) this.t = Math.min(1, this.t + dt / BLEND_SECONDS);
    const e = this.t * this.t * (3 - 2 * this.t); // smoothstep
    for (const k of Object.keys(this.to)) {
      const a = this.from[k], b = this.to[k];
      if (b instanceof THREE.Color) this.current[k].copy(a).lerp(b, e);
      else this.current[k] = a + (b - a) * e;
    }
    return this.current;
  }
}
