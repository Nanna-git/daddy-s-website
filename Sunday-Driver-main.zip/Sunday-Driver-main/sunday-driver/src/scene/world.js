// Renderer, camera, sky dome with sun + moon discs, hemisphere + sun light, fog.
// Colours and light come from atmosphere.js every frame via applyLook().
import * as THREE from 'three';

export function createWorld(canvas) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color('#D3F0FB');
  scene.fog = new THREE.Fog('#D3F0FB', 60, 220);

  const camera = new THREE.PerspectiveCamera(60, 1, 0.1, 700);

  // sky dome: vertex colours recomputed from top/horizon each frame (only ~300 vertices)
  const sky = new THREE.Group();
  const domeGeo = new THREE.SphereGeometry(500, 24, 12);
  const p = domeGeo.attributes.position;
  const heightT = new Float32Array(p.count);
  for (let i = 0; i < p.count; i++) heightT[i] = Math.pow(THREE.MathUtils.clamp(p.getY(i) / 500, 0, 1), 0.45);
  const domeCol = new Float32Array(p.count * 3);
  domeGeo.setAttribute('color', new THREE.BufferAttribute(domeCol, 3));
  sky.add(new THREE.Mesh(domeGeo, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, fog: false, depthWrite: false })));

  const discMat = (c) => new THREE.MeshBasicMaterial({ color: c, fog: false, depthWrite: false, transparent: true });
  const sunDisc = new THREE.Mesh(new THREE.CircleGeometry(16, 20), discMat('#FFE27A'));
  const moonDisc = new THREE.Mesh(new THREE.CircleGeometry(10, 20), discMat('#E8EEF8'));
  sky.add(sunDisc, moonDisc);
  scene.add(sky);

  const hemi = new THREE.HemisphereLight('#CFEFFF', '#D9C9A3', 1.1);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight('#FFF1D6', 2.4);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  Object.assign(sun.shadow.camera, { left: -10, right: 10, top: 10, bottom: -10, near: 1, far: 120 });
  sun.shadow.bias = -0.0005;
  scene.add(sun, sun.target);

  const lightDir = new THREE.Vector3(-0.55, 0.68, 0.48).normalize();
  const top = new THREE.Color(), hor = new THREE.Color(), tmp = new THREE.Color();

  const resize = () => {
    renderer.setSize(innerWidth, innerHeight, false);
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
  };
  addEventListener('resize', resize);
  resize();

  let shadowsAllowed = true;
  return {
    renderer, scene, camera,

    /** 'low': no shadows, pixel ratio 1 · 'high': car shadow, pixel ratio up to 2 */
    setQuality(q) {
      shadowsAllowed = q !== 'low';
      renderer.setPixelRatio(q === 'low' ? 1 : Math.min(devicePixelRatio, 2));
      renderer.shadowMap.enabled = shadowsAllowed;
      sun.castShadow = shadowsAllowed;
      scene.traverse(o => { if (o.material) o.material.needsUpdate = true; }); // recompile with/without shadows
      resize();
    },

    /** L: final colours (THREE.Color), numbers and directions from atmosphere.js */
    applyLook(L) {
      top.copy(L.sky); hor.copy(L.horizon);
      for (let i = 0; i < heightT.length; i++) {
        tmp.copy(hor).lerp(top, heightT[i]);
        domeCol[i * 3] = tmp.r; domeCol[i * 3 + 1] = tmp.g; domeCol[i * 3 + 2] = tmp.b;
      }
      domeGeo.attributes.color.needsUpdate = true;
      scene.background.copy(L.horizon);
      scene.fog.color.copy(L.fog);
      scene.fog.near = L.fogNear;
      scene.fog.far = L.fogFar;

      hemi.color.copy(L.hemiSky);
      hemi.groundColor.copy(L.hemiGround);
      hemi.intensity = L.hemiIntensity;
      sun.color.copy(L.lightColor);
      sun.intensity = L.lightIntensity;
      lightDir.copy(L.lightDir);
      if ('intensity' in sun.shadow) sun.shadow.intensity = L.shadow;
      sun.castShadow = shadowsAllowed && L.shadow > 0.02;

      sunDisc.position.copy(L.sunDir).multiplyScalar(460);
      sunDisc.lookAt(0, 0, 0);
      sunDisc.material.opacity = L.sunDiscOpacity;
      sunDisc.material.color.copy(L.sunDiscColor);
      sunDisc.visible = L.sunDiscOpacity > 0.01;
      moonDisc.position.copy(L.moonDir).multiplyScalar(460);
      moonDisc.lookAt(0, 0, 0);
      moonDisc.material.opacity = L.moonDiscOpacity;
      moonDisc.visible = L.moonDiscOpacity > 0.01;
    },

    /** Keep the sky around the camera and the (car-only) shadow box on the car. */
    follow(x, z, y = 0) {
      sky.position.copy(camera.position);
      sun.target.position.set(x, y, z);
      sun.position.set(x, y, z).addScaledVector(lightDir, 60);
    },
  };
}
