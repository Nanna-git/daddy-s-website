// Phone / tablet controls (briefing §7–8): steering arrows bottom left, gas + brake bottom right,
// horn above the gas. Each button tracks its own finger, so you can steer and accelerate at once.

export const isTouchDevice = () =>
  matchMedia('(pointer: coarse)').matches || (navigator.maxTouchPoints || 0) > 0;

export function createTouchControls(input, { onHorn, enabled = () => true } = {}) {
  if (!isTouchDevice()) return { isTouch: false, reset() {} };
  document.body.classList.add('touch');
  const tip = document.querySelector('.start .bottombar span:last-child');
  if (tip) tip.textContent = 'Arrows to steer · pedals on the right';

  const buttons = [...document.querySelectorAll('#touch [data-key]')];
  const release = [];
  for (const b of buttons) {
    const key = b.dataset.key;
    const fingers = new Set();
    const set = on => {
      b.classList.toggle('on', on);
      if (key === 'horn') onHorn?.(on);
      else input[key] = on ? 1 : 0;
    };
    b.addEventListener('pointerdown', e => {
      if (!enabled()) return;
      e.preventDefault();
      fingers.add(e.pointerId);
      set(true);
      try { b.setPointerCapture(e.pointerId); } catch { /* keep the press even if capture is refused */ }
    });
    const up = e => { if (fingers.delete(e.pointerId) && fingers.size === 0) set(false); };
    b.addEventListener('pointerup', up);
    b.addEventListener('pointercancel', up);
    b.addEventListener('lostpointercapture', up);
    b.addEventListener('contextmenu', e => e.preventDefault());
    release.push(() => { fingers.clear(); set(false); });
  }

  // no page scrolling, pull-to-refresh or pinch zoom while playing (the volume slider still works)
  document.addEventListener('touchmove', e => {
    if (!(e.target instanceof HTMLInputElement)) e.preventDefault();
  }, { passive: false });
  document.addEventListener('gesturestart', e => e.preventDefault());
  document.addEventListener('dblclick', e => e.preventDefault());

  return { isTouch: true, reset() { release.forEach(r => r()); } };
}
