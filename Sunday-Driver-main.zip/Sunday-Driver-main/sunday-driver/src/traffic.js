// City life: 6 AI hatchbacks looping the streets in the right-hand lane.
// They stop for red lights and for anything in front of them (including you). No damage.
import { buildVehicle } from './vehicles/hatchback.js';
import { VEHICLES } from './vehicles/specs.js';
import { groundPose } from './scene/props.js';

const ACCEL = 2.5, BRAKE = 6;

// loops of road centre-line corners, driven in order
const LOOPS = [
  { pts: [[-160, -160], [80, -160], [80, 80], [-160, 80]], color: '#FFC845', speed: 40, start: [0, 0.3] },
  { pts: [[-80, 0], [160, 0], [160, 160], [-80, 160]], color: '#8ED1F2', speed: 38, start: [2, 0.5] },
  { pts: [[-240, -240], [-240, 240], [240, 240], [240, -240]], color: '#2FB59A', speed: 46, start: [2, 0.4] },
  { pts: [[0, -240], [160, -240], [160, -80], [0, -80]], color: '#F4F4F0', speed: 36, start: [1, 0.2] },
  { pts: [[-160, -80], [-160, 160], [0, 160], [0, -80]], color: '#2F86C9', speed: 40, start: [3, 0.6] },
  { pts: [[80, 80], [80, 240], [240, 240], [240, 80]], color: '#C9CED6', speed: 42, start: [2, 0.7] },
];

const right = (dx, dz) => [-dz, dx]; // right-hand side of a direction (car faces +Z → right is −X)

function lanePath(pts, LANE) {
  const n = pts.length, out = [];
  for (let i = 0; i < n; i++) {
    const p = pts[i], a = pts[(i - 1 + n) % n], b = pts[(i + 1) % n];
    const din = norm(p[0] - a[0], p[1] - a[1]), dout = norm(b[0] - p[0], b[1] - p[1]);
    const ri = right(...din), ro = right(...dout);
    out.push([p[0] + (ri[0] + ro[0]) * LANE, p[1] + (ri[1] + ro[1]) * LANE]);
  }
  return out.map((p, i) => {
    const q = out[(i + 1) % n], dx = q[0] - p[0], dz = q[1] - p[1], len = Math.hypot(dx, dz);
    return { x: p[0], z: p[1], dx: dx / len, dz: dz / len, len, axis: Math.abs(dx) > Math.abs(dz) ? 'ew' : 'ns', cx: pts[i], cxNext: pts[(i + 1) % n] };
  });
}
function norm(x, z) { const l = Math.hypot(x, z) || 1; return [x / l, z / l]; }

/** opts (per city): lane (m right of centre), stopBack (stop line before a junction centre), colors, taxis (how many are taxis),
 *  heightAt (cities with slopes) */
export function createTraffic(scene, harbor, { lane = 3, stopBack = 9, colors = null, taxis = 0, heightAt = null } = {}) {
  const STOP_BACK = stopBack;
  const cars = LOOPS.map((L, i) => {
    const segs = lanePath(L.pts, lane);
    const def = i < taxis ? VEHICLES.taxi : VEHICLES.hatchback;
    const model = buildVehicle(def, colors ? colors[i] : L.color, { headlightBeam: false });
    scene.add(model.root);
    const seg = L.start[0], s = segs[seg].len * L.start[1];
    const car = {
      segs, seg, s, v: L.speed / 3.6, cruise: L.speed / 3.6, model,
      x: 0, z: 0, heading: 0, vF: 0, steer: 0, latAccel: 0, longAccel: 0,
      fx: 0, fz: 1,
    };
    place(car);
    return car;
  });

  function place(c) {
    const g = c.segs[c.seg];
    c.x = g.x + g.dx * c.s; c.z = g.z + g.dz * c.s;
    // ease the heading into the next segment over the last 6 m (a simple turn)
    const next = c.segs[(c.seg + 1) % c.segs.length];
    const left = g.len - c.s;
    let h = Math.atan2(g.dx, g.dz);
    if (left < 6) {
      const hn = Math.atan2(next.dx, next.dz);
      let d = Math.atan2(Math.sin(hn - h), Math.cos(hn - h));
      h += d * (1 - left / 6) * 0.5;
    }
    c.heading = h; c.fx = Math.sin(h); c.fz = Math.cos(h);
    groundPose(c, heightAt);
  }

  /** Distance from the car to the next junction stop line on its current segment, and that junction. */
  function nextJunction(c) {
    const g = c.segs[c.seg];
    let best = null;
    for (const j of harbor.junctions) {
      // junction centre relative to the car, along and across its direction
      const rx = j.x - c.x, rz = j.z - c.z;
      const along = rx * g.dx + rz * g.dz, across = Math.abs(rx * g.dz - rz * g.dx);
      if (across > 7 || along < STOP_BACK - 2) continue;
      if (!best || along < best.along) best = { j, along };
    }
    return best;
  }

  function blockedAhead(c, others) {
    let nearest = Infinity;
    for (const o of others) {
      if (o === c || Math.abs((o.y || 0) - (c.y || 0)) > 3) continue;
      const rx = o.x - c.x, rz = o.z - c.z;
      const along = rx * c.fx + rz * c.fz, across = Math.abs(rx * c.fz - rz * c.fx);
      if (along > 0 && along < 24 && across < 2.6) nearest = Math.min(nearest, along);
    }
    return nearest;
  }

  const obstacleBoxes = cars.map(() => ({ minX: 0, maxX: 0, minZ: 0, maxZ: 0 }));

  return {
    cars,
    /** Fixed-step update. player: { x, z } so AI cars stop for you too. */
    step(dt, player) {
      const others = [...cars, player];
      for (const c of cars) {
        let target = c.cruise;
        const g = c.segs[c.seg];
        const nj = nextJunction(c);
        c.toLine = nj ? nj.along - STOP_BACK : Infinity; // exposed for checks
        c.signalAhead = nj ? harbor.signal(nj.j, g.axis) : null;
        if (nj) {
          const toLine = nj.along - STOP_BACK;
          const sig = harbor.signal(nj.j, g.axis);
          // stop zone runs right up to (and just past) the line, so a stopped car never creeps through on red
          if (sig !== 'green' && toLine > -1.5 && toLine < 30 && !(sig === 'amber' && toLine < 4 && c.v > 4)) {
            target = Math.min(target, Math.max(0, Math.sqrt(2 * BRAKE * 0.6 * Math.max(0, toLine - 0.5))));
          }
        }
        const gap = blockedAhead(c, others);
        if (gap < 24) target = Math.min(target, Math.sqrt(2 * BRAKE * 0.8 * Math.max(0, gap - 6)));

        const prevV = c.v;
        if (c.v < target) c.v = Math.min(target, c.v + ACCEL * dt);
        else c.v = Math.max(target, c.v - BRAKE * dt);
        c.longAccel = (c.v - prevV) / dt;
        c.vF = c.v;

        c.s += c.v * dt;
        while (c.s >= c.segs[c.seg].len) { c.s -= c.segs[c.seg].len; c.seg = (c.seg + 1) % c.segs.length; }
        place(c);
      }
      cars.forEach((c, i) => {
        const ex = Math.abs(c.fx) * 2.0 + Math.abs(c.fz) * 0.9, ez = Math.abs(c.fz) * 2.0 + Math.abs(c.fx) * 0.9;
        Object.assign(obstacleBoxes[i], { minX: c.x - ex, maxX: c.x + ex, minZ: c.z - ez, maxZ: c.z + ez, y: c.y || 0 });
      });
    },
    /** AI cars as boxes the player bumps off. */
    get boxes() { return obstacleBoxes; },
    render(dt, lights) {
      for (const c of cars) { c.model.update(c, dt); c.model.setLights(lights); }
    },
  };
}
