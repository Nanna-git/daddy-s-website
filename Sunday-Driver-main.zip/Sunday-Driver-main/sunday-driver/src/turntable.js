// Choose Vehicle stage: the car spins slowly on a disc under a soft spotlight.
import * as THREE from 'three';
import { buildVehicle } from './vehicles/hatchback.js';
import { VEHICLES } from './vehicles/specs.js';
import { flat } from './scene/props.js';

export function createTurntable(paint) {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color('#13203A');
  scene.fog = new THREE.Fog('#13203A', 9, 22);

  const camera = new THREE.PerspectiveCamera(34, 1, 0.1, 60);

  scene.add(new THREE.HemisphereLight('#CFE3FF', '#1B2742', 1.4));
  const key = new THREE.DirectionalLight('#FFF1D6', 2.6);
  key.position.set(-4, 7, 5);
  key.castShadow = true;
  key.shadow.mapSize.set(1024, 1024);
  Object.assign(key.shadow.camera, { left: -4, right: 4, top: 4, bottom: -4, near: 1, far: 20 });
  scene.add(key);
  const rim = new THREE.DirectionalLight('#8ED1F2', 0.8);
  rim.position.set(5, 3, -6);
  scene.add(rim);

  const floor = new THREE.Mesh(new THREE.CircleGeometry(30, 32).rotateX(-Math.PI / 2), flat('#16243F'));
  floor.position.y = -0.2;
  scene.add(floor);
  const disc = new THREE.Mesh(new THREE.CylinderGeometry(3.1, 3.1, 0.2, 48).translate(0, -0.1, 0), flat('#2B3A57'));
  disc.receiveShadow = true;
  scene.add(disc);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(3.1, 0.03, 4, 64).rotateX(Math.PI / 2), new THREE.MeshBasicMaterial({ color: '#FF6A4D' }));
  scene.add(ring);

  let model = buildVehicle(VEHICLES.hatchback, paint, { headlightBeam: false });
  const fit = m => m.root.scale.setScalar(m.def.showcaseScale || 1); // the bus is shrunk, the bike enlarged
  let paintNow = paint;
  scene.add(model.root);
  const pose = { x: 0, z: 0, heading: 0.6, vF: 0, steer: 0, latAccel: 0, longAccel: 0 };

  const resize = () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); };
  addEventListener('resize', resize);
  resize();

  return {
    scene, camera,
    get model() { return model; },
    setPaint: hex => { paintNow = hex; model.setPaint(hex); },
    /** Put another vehicle on the disc. */
    setVehicle(id) {
      if (!VEHICLES[id] || model.def.id === id) return;
      model.dispose();
      model = buildVehicle(VEHICLES[id], paintNow, { headlightBeam: false });
      fit(model);
      scene.add(model.root);
    },
    update(dt) {
      pose.heading += dt * 0.47; // ~27° per second
      model.update(pose, dt);
      // car sits left of centre; the stats panel is on the right
      camera.position.set(8.4, 3.4, 10.2);
      camera.lookAt(2.6, 0.2, 0);
    },
  };
}
