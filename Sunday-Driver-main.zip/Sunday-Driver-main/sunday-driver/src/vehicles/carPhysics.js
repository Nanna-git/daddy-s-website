// Arcade car model (Reference C). Fixed-step: call step(dt, input) at 60 Hz.
// Heading 0 faces +Z; increasing heading turns left (towards +X).

import { VEHICLES } from './specs.js';
import { performanceFactor } from '../damage.js';

/** Kept for older callers; every vehicle's numbers live in specs.js. */
export const HATCHBACK = VEHICLES.hatchback.physics;

export class CarPhysics {
  constructor(spec = HATCHBACK, spawn = { x: 0, z: 0, heading: 0 }) {
    this.spec = spec;
    this.x = spawn.x;
    this.z = spawn.z;
    this.heading = spawn.heading;
    this.vF = 0;        // forward speed (m/s, negative = reversing)
    this.vL = 0;        // sideways speed (m/s)
    this.steer = 0;     // front wheel angle (rad)
    this.yawRate = 0;
    this.latAccel = 0;
    this.longAccel = 0;
    this.grip = 1;      // weather: sideways grip and cornering limit
    this.brakeMul = 1;  // weather: braking distance multiplier
    this.damage = 0;    // 0–100 %: slows the car a little and makes it pull to one side (damage.js)
    this.pullDir = 1;   // which way a damaged car pulls
  }

  get fx() { return Math.sin(this.heading); }
  get fz() { return Math.cos(this.heading); }
  get speedKmh() { return Math.abs(this.vF) * 3.6; }

  step(dt, input) {
    const s = this.spec;
    const vF0 = this.vF;
    const perf = performanceFactor(this.damage), speedMax = s.speedMax * perf;

    // weather stretches braking more for grippy-sensitive cars (sports) and less for the SUV
    const brakeMul = 1 + (this.brakeMul - 1) * ((s.gripPow ?? 1.6) / 1.6);
    // throttle / brake / reverse
    let a = 0;
    if (input.up) {
      a = this.vF < -0.5 ? s.brake / brakeMul : s.accel * perf * (1 - Math.max(0, this.vF) / speedMax);
    } else if (input.down) {
      a = this.vF > 0.5 ? -s.brake / brakeMul : -s.accel * 0.7 * (1 - Math.max(0, -this.vF) / s.reverseMax);
    } else {
      a = -Math.sign(this.vF) * Math.min(Math.abs(this.vF) / dt, 1.5); // rolling drag
    }
    if (input.handbrake) a -= Math.sign(this.vF) * Math.min(Math.abs(this.vF) / dt, 4);
    this.vF += a * dt;
    if (!input.up && !input.down && Math.abs(this.vF) < 0.05) this.vF = 0;

    // steering: less lock at speed, eased toward the target
    const k = Math.min(1, Math.abs(this.vF) / speedMax);
    const lock = s.steerMaxLow + (s.steerMaxHigh - s.steerMaxLow) * k;
    const pull = this.pullDir * 0.035 * (1 - perf) / 0.3 * Math.min(1, Math.abs(this.vF) / 8); // up to ~2° of drift at 100 %
    const target = (input.left - input.right) * lock + pull;
    const rate = 3.5 * dt;
    this.steer += Math.max(-rate, Math.min(rate, target - this.steer));

    this.yawRate = (this.vF * Math.tan(this.steer)) / s.wheelbase * (input.handbrake ? 1.35 : 1);
    // keep turns sane at speed: limit sideways acceleration (handbrake allows more rotation)
    // low grip limits turning only a little (sqrt) but loosens the sideways hold a lot (below), so it slides
    const maxYaw = (s.maxLatAccel * Math.pow(this.grip, s.yawGripPow ?? 0.5) * (input.handbrake ? 1.6 : 1)) / Math.max(Math.abs(this.vF), 1);
    this.yawRate = Math.max(-maxYaw, Math.min(maxYaw, this.yawRate));
    this.heading += this.yawRate * dt;

    // sideways slip: velocity keeps pointing the old way, grip pulls it back in line
    const grip = s.lateralGrip * Math.pow(this.grip, s.gripPow ?? 1.6) * (input.handbrake ? 0.3 : 1);
    const slip = -this.yawRate * this.vF * dt; // the body turned, the old velocity now points slightly outward
    this.vL = (this.vL + slip) * Math.exp(-grip * dt);

    this.latAccel = this.yawRate * this.vF;
    this.longAccel = (this.vF - vF0) / dt;

    // move: forward axis f, left axis l
    const fx = this.fx, fz = this.fz, lx = fz, lz = -fx;
    this.x += (fx * this.vF + lx * this.vL) * dt;
    this.z += (fz * this.vF + lz * this.vL) * dt;
  }

  /** World-space velocity. */
  velocity() {
    const fx = this.fx, fz = this.fz;
    return { x: fx * this.vF + fz * this.vL, z: fz * this.vF - fx * this.vL };
  }

  setVelocity(vx, vz) {
    const fx = this.fx, fz = this.fz;
    this.vF = vx * fx + vz * fz;
    this.vL = vx * fz - vz * fx;
  }
}
