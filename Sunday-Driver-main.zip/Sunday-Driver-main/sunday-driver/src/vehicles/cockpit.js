// Driver-view interior (left-hand drive) in car-local coordinates, laid out from the vehicle's spec.
// The car faces +Z, so the driver's left is +X.
import * as THREE from 'three';
import { flat } from '../scene/props.js';
import { createWindshield } from './windshield.js';
import { buildBikeCockpit } from './motorbike.js';

const V3 = a => new THREE.Vector3(...a);

function boxAt(w, h, d, color, x, y, z, parent) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), flat(color));
  m.position.set(x, y, z);
  parent.add(m);
  return m;
}

/** Thin box from a to b (pillars). */
function beam(a, b, t, color, parent) {
  const dir = new THREE.Vector3().subVectors(b, a);
  const m = new THREE.Mesh(new THREE.BoxGeometry(t, dir.length(), t), flat(color));
  m.position.copy(a).add(b).multiplyScalar(0.5);
  m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
  parent.add(m);
  return m;
}

function facePlane(w, h, mat, pos, rotY, parent) {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
  m.position.copy(pos);
  m.rotation.y = rotY;
  parent.add(m);
  return m;
}

export function buildCockpit(root, renderer, scene, def) {
  if (def.kind === 'bike') return buildBikeCockpit(root, renderer, scene, def);
  const C = def.cockpit;
  const steerToWheel = (Math.PI / 2) / def.physics.steerMaxLow; // full lock = wheel turned 90°
  const g = new THREE.Group();
  g.visible = false;
  root.add(g);

  // dashboard, binnacle, centre screen, vents
  const d = C.dash, dashTop = d.y + d.h / 2, dashBack = d.z - d.d / 2, dashFront = d.z + d.d / 2;
  boxAt(d.w, d.h, d.d, '#2D323B', 0, d.y, d.z, g);
  boxAt(d.w, 0.02, 0.06, '#3A404A', 0, dashTop + 0.005, dashFront - 0.03, g);
  boxAt(0.36, 0.06, 0.2, '#24282F', C.wheel.x, dashTop + 0.03, dashBack + 0.1, g);
  facePlane(0.22, 0.1, flat('#1C2633'), new THREE.Vector3(-0.05, d.y + 0.03, dashBack - 0.005), Math.PI, g);
  facePlane(0.24, 0.05, flat('#1C1F24'), new THREE.Vector3(-0.5, d.y + 0.05, dashBack - 0.005), Math.PI, g);

  // cabin floor / seats, just above the body block so its paint never shows inside
  const floorLen = dashBack - C.floor.zb;
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(d.w, floorLen).rotateX(-Math.PI / 2), flat('#262A31'));
  floor.position.set(0, C.floor.y, C.floor.zb + floorLen / 2);
  g.add(floor);

  // roof lining, roof front edge, A-pillars, door sills
  const L = C.lining, liningLen = L.zf - L.zb;
  const lining = new THREE.Mesh(new THREE.PlaneGeometry(L.w, liningLen).rotateX(Math.PI / 2), flat('#363C46'));
  lining.position.set(0, L.y, L.zb + liningLen / 2);
  g.add(lining);
  boxAt(L.w - 0.02, 0.07, 0.08, '#2A2F37', 0, L.y - 0.005, L.zf, g);
  if (C.header) boxAt(L.w, C.header.h, 0.06, '#2A2F37', 0, C.header.y, C.header.z, g);
  const doorLen = dashFront - C.floor.zb;
  for (const s of [1, -1]) {
    const pb = V3(C.pillar.b), pt = V3(C.pillar.t);
    pb.x *= s; pt.x *= s;
    beam(pb, pt, 0.055, '#2A2F37', g);
    const door = new THREE.Mesh(new THREE.PlaneGeometry(doorLen, C.sill.y - C.floor.y), flat('#30353E', { side: THREE.DoubleSide }));
    door.position.set(s * (C.sill.x + 0.015), (C.sill.y + C.floor.y) / 2, C.floor.zb + doorLen / 2);
    door.rotation.y = Math.PI / 2;
    g.add(door);
    boxAt(0.05, 0.04, doorLen, '#3A404A', s * C.sill.x, C.sill.y, C.floor.zb + doorLen / 2, g); // sill / armrest
  }
  boxAt(0.36, 0.05, 0.06, '#3F4651', C.wheel.x, C.visor.y, C.visor.z, g); // driver sun visor (folded)

  // steering wheel: tilted towards the driver, inner group turns
  const Wh = C.wheel;
  const wheelTilt = new THREE.Group();
  wheelTilt.position.set(Wh.x, Wh.y, Wh.z);
  wheelTilt.rotation.x = Wh.tilt;
  const wheel = new THREE.Group();
  wheelTilt.add(wheel);
  wheel.add(new THREE.Mesh(new THREE.TorusGeometry(Wh.r, 0.02, 6, 18), flat('#1B1E23')));
  wheel.add(new THREE.Mesh(new THREE.BoxGeometry(Wh.r * 1.9, 0.03, 0.02), flat('#262A31')));
  const down = new THREE.Mesh(new THREE.BoxGeometry(0.03, Wh.r * 0.95, 0.02), flat('#262A31'));
  down.position.y = -Wh.r * 0.47;
  wheel.add(down);
  wheel.add(new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.04, 10).rotateX(Math.PI / 2), flat('#2E333B')));
  const dot = new THREE.Mesh(new THREE.CircleGeometry(0.014, 10), new THREE.MeshBasicMaterial({ color: '#FF6A4D' }));
  dot.position.z = -0.021; dot.rotation.y = Math.PI;
  wheel.add(dot);
  const column = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.04, 0.25, 8).rotateX(Math.PI / 2), flat('#24282F'));
  column.position.z = 0.13;
  column.visible = Wh.tilt > -0.8; // a nearly flat bus wheel sits on its pedestal, no visible column
  wheelTilt.add(column);
  g.add(wheelTilt);

  // speed dial behind the wheel (tiny canvas texture: arc + number)
  const dialCanvas = document.createElement('canvas');
  dialCanvas.width = 256; dialCanvas.height = 80;
  const dctx = dialCanvas.getContext('2d');
  const dialTex = new THREE.CanvasTexture(dialCanvas);
  dialTex.colorSpace = THREE.SRGBColorSpace;
  facePlane(0.16, 0.05, new THREE.MeshBasicMaterial({ map: dialTex }), new THREE.Vector3(Wh.x, dashTop + 0.03, dashBack - 0.002), Math.PI, g);
  const dialMax = Math.ceil(def.physics.speedMax * 3.6 / 20) * 20 + 40;
  let lastSpeed = -1;
  function drawDial(kmh) {
    const s = Math.round(kmh);
    if (s === lastSpeed) return;
    lastSpeed = s;
    dctx.fillStyle = '#14171C'; dctx.fillRect(0, 0, 256, 80);
    const cx = 50, cy = 44, r = 28, a0 = Math.PI * 0.75, span = Math.PI * 1.5;
    dctx.lineWidth = 8; dctx.lineCap = 'round';
    dctx.strokeStyle = '#3A404A'; dctx.beginPath(); dctx.arc(cx, cy, r, a0, a0 + span); dctx.stroke();
    dctx.strokeStyle = '#FF6A4D'; dctx.beginPath(); dctx.arc(cx, cy, r, a0, a0 + span * Math.min(1, s / dialMax)); dctx.stroke();
    dctx.fillStyle = '#FFFFFF'; dctx.font = '600 52px Fredoka, sans-serif'; dctx.textAlign = 'right'; dctx.textBaseline = 'alphabetic';
    dctx.fillText(String(s), 200, 68);
    dctx.fillStyle = '#B9C4D6'; dctx.font = '700 18px "DM Sans", sans-serif'; dctx.textAlign = 'left';
    dctx.fillText('km/h', 206, 68);
    dialTex.needsUpdate = true;
  }
  drawDial(0);

  // mirrors share one small rear-facing render target (flipped like a real mirror)
  const rt = new THREE.WebGLRenderTarget(256, 96);
  rt.texture.colorSpace = THREE.SRGBColorSpace;
  rt.texture.wrapS = THREE.RepeatWrapping;
  rt.texture.repeat.x = -1; rt.texture.offset.x = 1;
  const mirrorCam = new THREE.PerspectiveCamera(38, 256 / 96, 0.3, 160);
  mirrorCam.position.set(...C.mirrorCam); // just behind the tailgate, so it sees the road, not the cabin
  mirrorCam.lookAt(0, C.mirrorCam[1] - 0.2, -20);
  root.add(mirrorCam);
  const mirrorMat = new THREE.MeshBasicMaterial({ map: rt.texture });
  const RM = C.rearMirror;
  boxAt(0.02, RM.roof - RM.y, 0.02, '#23272E', 0, (RM.roof + RM.y) / 2, RM.z, g); // stem from the roof
  boxAt(0.27, 0.075, 0.03, '#1E2228', 0, RM.y, RM.z, g);                         // rear-view housing
  facePlane(0.25, 0.058, mirrorMat, new THREE.Vector3(0, RM.y, RM.z - 0.016), Math.PI, g);
  facePlane(0.15, 0.1, mirrorMat, new THREE.Vector3(def.mirror.x, def.mirror.y, def.mirror.z - 0.082), Math.PI, g); // left door mirror glass

  const windshield = createWindshield(g, C.glass);

  return {
    group: g,
    drawDial,
    windshield,
    eye: V3(C.eye),
    look: V3(C.look),
    dashEdge: new THREE.Vector3(0, dashTop, dashFront), // the "dashboard line" for the HUD
    setVisible(v) { g.visible = v; },
    update(dt, car, look) {
      wheel.rotation.z = car.steer * steerToWheel;
      drawDial(car.speedKmh);
      windshield.update(dt, look, car.speedKmh);
    },
    /** Low quality: mirrors refresh once a second instead of every frame. */
    mirrorInterval: 0,
    _mirrorWait: 0,
    /** Render the mirror view (only call while the driver view is shown). */
    renderMirrors(dt = 0) {
      this._mirrorWait -= dt;
      if (this._mirrorWait > 0) return;
      this._mirrorWait = this.mirrorInterval;
      g.visible = false;
      renderer.setRenderTarget(rt);
      renderer.render(scene, mirrorCam);
      renderer.setRenderTarget(null);
      g.visible = true;
    },
    dispose() {
      g.removeFromParent();
      mirrorCam.removeFromParent();
      rt.dispose();
      dialTex.dispose();
      windshield.dispose?.();
    },
  };
}
