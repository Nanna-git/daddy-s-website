// Small speed display: a coral arc plus the number, drawn into a tiny canvas texture.
import * as THREE from 'three';

export function createDial(maxKmh) {
  const canvas = document.createElement('canvas');
  canvas.width = 256; canvas.height = 80;
  const ctx = canvas.getContext('2d');
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const dialMax = Math.ceil(maxKmh / 20) * 20 + 40;
  let last = -1;

  function draw(kmh) {
    const s = Math.round(kmh);
    if (s === last) return;
    last = s;
    ctx.fillStyle = '#14171C'; ctx.fillRect(0, 0, 256, 80);
    const cx = 50, cy = 44, r = 28, a0 = Math.PI * 0.75, span = Math.PI * 1.5;
    ctx.lineWidth = 8; ctx.lineCap = 'round';
    ctx.strokeStyle = '#3A404A'; ctx.beginPath(); ctx.arc(cx, cy, r, a0, a0 + span); ctx.stroke();
    ctx.strokeStyle = '#FF6A4D'; ctx.beginPath(); ctx.arc(cx, cy, r, a0, a0 + span * Math.min(1, s / dialMax)); ctx.stroke();
    ctx.fillStyle = '#FFFFFF'; ctx.font = '600 52px Fredoka, sans-serif'; ctx.textAlign = 'right'; ctx.textBaseline = 'alphabetic';
    ctx.fillText(String(s), 200, 68);
    ctx.fillStyle = '#B9C4D6'; ctx.font = '700 18px "DM Sans", sans-serif'; ctx.textAlign = 'left';
    ctx.fillText('km/h', 206, 68);
    texture.needsUpdate = true;
  }
  draw(0);
  return { texture, draw, dispose: () => texture.dispose() };
}

/** Rear-facing camera + render target shared by a vehicle's mirrors (flipped like a real mirror). */
export function createMirrorView(root, camPos) {
  const rt = new THREE.WebGLRenderTarget(256, 96);
  rt.texture.colorSpace = THREE.SRGBColorSpace;
  rt.texture.wrapS = THREE.RepeatWrapping;
  rt.texture.repeat.x = -1; rt.texture.offset.x = 1;
  const cam = new THREE.PerspectiveCamera(38, 256 / 96, 0.3, 160);
  cam.position.set(...camPos); // just behind the vehicle, so it sees the road, not the cabin
  cam.lookAt(0, camPos[1] - 0.2, -20);
  root.add(cam);
  return {
    material: new THREE.MeshBasicMaterial({ map: rt.texture }),
    render(renderer, scene) {
      renderer.setRenderTarget(rt);
      renderer.render(scene, cam);
      renderer.setRenderTarget(null);
    },
    dispose() { cam.removeFromParent(); rt.dispose(); },
  };
}
