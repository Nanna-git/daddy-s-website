// Low-poly vehicles built from two tapered blocks, four octagonal wheels and flat decals (~220–300 triangles).
// Units are metres. The car faces +Z; +Y is up.
import * as THREE from 'three';
import { flat } from '../scene/props.js';
import { VEHICLES } from './specs.js';
import { buildMotorbike } from './motorbike.js';

const V = (x, y, z) => new THREE.Vector3(x, y, z);

/** Geometry from convex faces; each face is turned to point away from `inside`. */
function convexGeo(faces, inside) {
  const pos = [];
  for (let f of faces) {
    const n = new THREE.Vector3().subVectors(f[1], f[0]).cross(new THREE.Vector3().subVectors(f[2], f[0]));
    const fc = f.reduce((a, p) => a.add(p), new THREE.Vector3()).multiplyScalar(1 / f.length);
    if (n.dot(fc.sub(inside)) < 0) f = [...f].reverse();
    for (let i = 1; i < f.length - 1; i++) pos.push(...f[0].toArray(), ...f[i].toArray(), ...f[i + 1].toArray());
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.computeVertexNormals(); // non-indexed → one flat normal per face
  return g;
}

/** Tapered block: base and top rectangles can differ in size and height front/back. */
function block(b, t) {
  const v = [
    V(-b.x, b.y, b.zb), V(-b.x, b.y, b.zf), V(b.x, b.y, b.zf), V(b.x, b.y, b.zb),
    V(-t.x, t.yb, t.zb), V(-t.x, t.yf, t.zf), V(t.x, t.yf, t.zf), V(t.x, t.yb, t.zb),
  ];
  const c = v.reduce((a, p) => a.add(p), new THREE.Vector3()).multiplyScalar(1 / 8);
  const F = [[0, 1, 2, 3], [4, 5, 6, 7], [0, 1, 5, 4], [1, 2, 6, 5], [2, 3, 7, 6], [3, 0, 4, 7]];
  const faces = F.map(ix => ix.map(i => v[i]));
  return {
    geo: convexGeo(faces, c), c,
    // quads as A,B,C,D with u across and v up, for decals
    front: [v[1], v[2], v[6], v[5]], back: [v[3], v[0], v[4], v[7]],
    left: [v[3], v[2], v[6], v[7]], right: [v[0], v[1], v[5], v[4]],
  };
}

function bil(q, u, w) {
  return new THREE.Vector3()
    .addScaledVector(q[0], (1 - u) * (1 - w)).addScaledVector(q[1], u * (1 - w))
    .addScaledVector(q[2], u * w).addScaledVector(q[3], (1 - u) * w);
}

/** A flat coloured quad lying on a block face, lifted 6 mm off it. */
function decal(q, u0, u1, v0, v1, inside) {
  const pts = [bil(q, u0, v0), bil(q, u1, v0), bil(q, u1, v1), bil(q, u0, v1)];
  const n = new THREE.Vector3().subVectors(pts[1], pts[0]).cross(new THREE.Vector3().subVectors(pts[2], pts[0])).normalize();
  const fc = pts.reduce((a, p) => a.add(p), new THREE.Vector3()).multiplyScalar(0.25);
  if (n.dot(fc.clone().sub(inside)) < 0) n.negate();
  pts.forEach(p => p.addScaledVector(n, 0.006));
  return convexGeo([pts], fc.clone().addScaledVector(n, -1));
}

export const PAINTS = { coral: '#F2674A', sun: '#FFC845', mint: '#2FB59A', cloud: '#F4F4F0' };

/** Any vehicle from its spec (specs.js): two tapered blocks, octagonal wheels, flat decals, a few extras. */
export function buildVehicle(def, paint = PAINTS.coral, opts = {}) {
  if (def.kind === 'bike') return buildMotorbike(def, paint, opts);
  const { headlightBeam = true, shadows = true } = opts;
  const root = new THREE.Group();     // position + heading
  const chassis = new THREE.Group();  // body roll / pitch
  root.add(chassis);

  const bodyMat = new THREE.MeshLambertMaterial({ color: paint, flatShading: true });
  const trimMat = new THREE.MeshLambertMaterial({ color: new THREE.Color(paint).multiplyScalar(0.62), flatShading: true });
  const mesh = (geo, mat) => { const m = new THREE.Mesh(geo, mat); m.castShadow = shadows; chassis.add(m); return m; };

  const body = block(def.body.b, def.body.t);
  const cabin = block(def.cabin.b, def.cabin.t);
  mesh(body.geo, bodyMat);
  mesh(cabin.geo, bodyMat);

  const glass = flat('#2C3B4E'), plate = flat('#F4F1E8'), dark = flat('#2A2F37');
  const head = new THREE.MeshLambertMaterial({ color: '#FFF3C4', emissive: '#FFF3C4', emissiveIntensity: 0, flatShading: true });
  const tail = new THREE.MeshLambertMaterial({ color: '#D9343A', emissive: '#FF2A2A', emissiveIntensity: 0, flatShading: true });
  const D = (q, u0, u1, v0, v1, part, mat) => mesh(decal(q, u0, u1, v0, v1, part.c), mat);
  // body decals
  D(body.front, 0.05, 0.27, 0.56, 0.86, body, head); D(body.front, 0.73, 0.95, 0.56, 0.86, body, head);
  D(body.front, 0.34, 0.66, 0.5, 0.78, body, dark); D(body.front, 0, 1, 0, 0.26, body, trimMat);
  D(body.back, 0.04, 0.24, 0.58, 0.86, body, tail); D(body.back, 0.76, 0.96, 0.58, 0.86, body, tail);
  D(body.back, 0.38, 0.62, 0.32, 0.55, body, plate); D(body.back, 0, 1, 0, 0.24, body, trimMat);
  D(body.left, 0, 1, 0, 0.16, body, trimMat); D(body.right, 0, 1, 0, 0.16, body, trimMat);
  // cabin glass (a row of windows for the bus)
  const sideWins = def.sideWindows || [[0.06, 0.46], [0.54, 0.92]];
  for (const side of [cabin.left, cabin.right]) for (const [u0, u1] of sideWins) D(side, u0, u1, 0.12, 0.88, cabin, glass);
  D(cabin.front, 0.05, 0.95, 0.08, 0.9, cabin, glass);
  D(cabin.back, 0.08, 0.92, 0.1, 0.88, cabin, glass);

  // mirrors
  const mirrorGeo = new THREE.BoxGeometry(0.18, 0.14, 0.16);
  for (const s of [-1, 1]) { const m = mesh(mirrorGeo, bodyMat); m.position.set(s * def.mirror.x, def.mirror.y, def.mirror.z); }

  // wheels: octagonal prisms, axis along X; front pair inside steering pivots
  const W = def.wheel;
  const tyreGeo = new THREE.CylinderGeometry(W.r, W.r, W.w, 8).rotateZ(Math.PI / 2);
  const hubGeo = new THREE.CylinderGeometry(W.r * 0.55, W.r * 0.55, W.w + 0.01, 8).rotateZ(Math.PI / 2);
  const tyreMat = flat('#1D2026'), hubMat = flat('#C9CED6');
  const wheels = [], pivots = [];
  for (const z of [W.zf, W.zr]) for (const s of [-1, 1]) {
    const pivot = new THREE.Group();
    pivot.position.set(s * W.x, W.r, z);
    const w = new THREE.Group();
    const tyre = new THREE.Mesh(tyreGeo, tyreMat); tyre.castShadow = shadows;
    const hub = new THREE.Mesh(hubGeo, hubMat); hub.position.x = s * 0.01;
    w.add(tyre, hub);
    pivot.add(w);
    root.add(pivot);
    wheels.push(w);
    if (z > 0) pivots.push(pivot);
  }

  // extras: wings, roof rails, guards, spare wheel
  const mats = { body: bodyMat, trim: trimMat, dark, glass, sign: flat('#3B2F14', { emissive: '#FFB020', emissiveIntensity: 0.6 }) };
  for (const e of def.extras || []) {
    if (e.spare) {
      const sp = mesh(new THREE.CylinderGeometry(e.r, e.r, e.w, 8).rotateX(Math.PI / 2), tyreMat);
      sp.position.set(...e.pos);
      const hub = mesh(new THREE.CylinderGeometry(e.r * 0.5, e.r * 0.5, e.w + 0.01, 8).rotateX(Math.PI / 2), hubMat);
      hub.position.set(...e.pos);
      continue;
    }
    const m = mesh(new THREE.BoxGeometry(...e.size), mats[e.mat] || dark);
    m.position.set(...e.pos);
  }

  // headlights: one spotlight for the player's car (Reference E)
  const beam = new THREE.SpotLight('#FFF1C8', 0, 45, 0.55, 0.6, 1.2);
  beam.position.set(0, def.lights.y, def.lights.z);
  beam.target.position.set(0, 0, def.lights.z + 12);
  if (headlightBeam) root.add(beam, beam.target);

  let spin = 0;
  return {
    root, def,
    /** 0..1 — headlights, tail lights and the road beam. */
    setLights(v) {
      head.emissiveIntensity = v * 0.9;
      tail.emissiveIntensity = v * 0.6;
      beam.intensity = v * 60;
      beam.visible = headlightBeam && v > 0.01;
    },
    setPaint(hex) { bodyMat.color.set(hex); trimMat.color.set(hex).multiplyScalar(0.62); },
    /** Sync the model with the physics state.
     *  roll: 1 = full body lean (outside view), 0 = none (driver view, so the hood stays level with the dashboard) */
    update(car, dt, roll = 1) {
      root.position.set(car.x, car.y || 0, car.z);
      root.rotation.set(car.pitch || 0, car.heading, car.bank || 0, 'YXZ'); // heading, then the slope
      spin += (car.vF * dt) / W.r;
      wheels.forEach(w => { w.rotation.x = spin; });
      pivots.forEach(p => { p.rotation.y = car.steer; });
      chassis.rotation.z = THREE.MathUtils.clamp(car.latAccel * def.roll, -0.07, 0.07) * roll;
      chassis.rotation.x = THREE.MathUtils.clamp(-car.longAccel * 0.006, -0.04, 0.04) * roll;
    },
    dispose() {
      root.removeFromParent();
      root.traverse(o => { if (o.geometry && o.geometry !== mirrorGeo) o.geometry.dispose?.(); });
    },
  };
}

/** The Hatchback (also used for the AI traffic). */
export function buildHatchback(paint = PAINTS.coral, opts = {}) {
  return buildVehicle(VEHICLES.hatchback, paint, opts);
}
