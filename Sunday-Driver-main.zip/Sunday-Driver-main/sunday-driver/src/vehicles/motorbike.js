// Motorbike: two inline wheels, a simple rider, and a lean into every turn.
// Driver view has no cabin — just handlebars, two round mirrors and a small speed display.
import * as THREE from 'three';
import { flat } from '../scene/props.js';
import { createDial, createMirrorView } from './dial.js';

/** Thin box from a to b. */
function beam(a, b, t, mat, parent) {
  const dir = new THREE.Vector3().subVectors(b, a);
  const m = new THREE.Mesh(new THREE.BoxGeometry(t, dir.length(), t), mat);
  m.position.copy(a).add(b).multiplyScalar(0.5);
  m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
  parent.add(m);
  return m;
}
const V = (x, y, z) => new THREE.Vector3(x, y, z);

export function buildMotorbike(def, paint, { headlightBeam = true, shadows = true } = {}) {
  const root = new THREE.Group();   // position + heading
  const lean = new THREE.Group();   // tilts into turns
  root.add(lean);
  root.userData.lean = lean;

  const bodyMat = new THREE.MeshLambertMaterial({ color: paint, flatShading: true });
  const dark = flat('#2A2F37'), metal = flat('#C9CED6'), engineMat = flat('#3A3F48'), tyreMat = flat('#1D2026');
  const head = new THREE.MeshLambertMaterial({ color: '#FFF3C4', emissive: '#FFF3C4', emissiveIntensity: 0, flatShading: true });
  const tail = new THREE.MeshLambertMaterial({ color: '#D9343A', emissive: '#FF2A2A', emissiveIntensity: 0, flatShading: true });
  const box = (size, pos, mat, parent = lean, rotX = 0) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(...size), mat);
    m.position.set(...pos); m.rotation.x = rotX; m.castShadow = shadows;
    parent.add(m); return m;
  };

  // wheels (axis along X)
  const W = def.wheel;
  const tyreGeo = new THREE.CylinderGeometry(W.r, W.r, W.w, 10).rotateZ(Math.PI / 2);
  const hubGeo = new THREE.CylinderGeometry(W.r * 0.45, W.r * 0.45, W.w + 0.01, 8).rotateZ(Math.PI / 2);
  const makeWheel = () => {
    const w = new THREE.Group();
    const t = new THREE.Mesh(tyreGeo, tyreMat); t.castShadow = shadows;
    w.add(t, new THREE.Mesh(hubGeo, metal));
    return w;
  };
  const rear = makeWheel(); rear.position.set(0, W.r, W.zr); lean.add(rear);
  // front: fork pivot turns with the steering
  const fork = new THREE.Group(); fork.position.set(0, 0, 0.6); lean.add(fork);
  const front = makeWheel(); front.position.set(0, W.r, W.zf - 0.6); fork.add(front);
  for (const s of [-1, 1]) beam(V(s * 0.08, W.r, W.zf - 0.6), V(s * 0.08, 1.0, -0.12), 0.04, metal, fork);
  box([0.16, 0.04, 0.42], [0, W.r + 0.36, W.zf - 0.6], bodyMat, fork);           // front mudguard
  const lamp = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.08, 10).rotateX(Math.PI / 2), head);
  lamp.position.set(0, 0.98, 0.04); fork.add(lamp);
  box([0.7, 0.035, 0.035], [0, 1.03, -0.12], dark, fork);                        // handlebar

  // frame, tank, seat, engine, exhaust
  box([0.3, 0.16, 0.1], [0, 0.92, 0.6], bodyMat);                                 // small fairing (kept below the bars)
  box([0.32, 0.24, 0.55], [0, 0.86, 0.18], bodyMat, lean, -0.15);                 // tank
  box([0.3, 0.1, 0.6], [0, 0.86, -0.38], dark);                                   // seat
  box([0.24, 0.14, 0.36], [0, 0.93, -0.74], bodyMat);                             // tail cowl
  box([0.12, 0.05, 0.04], [0, 0.92, -0.93], tail);                                // tail light
  box([0.32, 0.32, 0.42], [0, 0.5, 0.05], engineMat);                             // engine
  box([0.14, 0.04, 0.4], [0, 0.7, -0.72], bodyMat);                               // rear mudguard
  const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 0.75, 8).rotateX(Math.PI / 2), metal);
  pipe.position.set(-0.18, 0.42, -0.42); pipe.castShadow = shadows; lean.add(pipe);
  beam(V(0, 0.5, -0.2), V(0, W.r, W.zr), 0.06, dark, lean);                       // swing arm

  // rider (hidden in the driver view)
  const rider = new THREE.Group(); lean.add(rider);
  const jacket = flat('#2B3A57'), pants = flat('#30353E'), helmet = flat('#F4F4F0');
  box([0.38, 0.56, 0.26], [0, 1.22, -0.28], jacket, rider, 0.35);
  for (const s of [-1, 1]) {
    box([0.13, 0.13, 0.46], [s * 0.17, 0.95, -0.16], pants, rider, -0.25);
    box([0.12, 0.42, 0.12], [s * 0.2, 0.66, 0.02], pants, rider);
    beam(V(s * 0.18, 1.42, -0.2), V(s * 0.31, 1.04, 0.47), 0.09, jacket, rider);
  }
  const hel = new THREE.Mesh(new THREE.IcosahedronGeometry(0.15, 1), helmet);
  hel.position.set(0, 1.6, -0.12); hel.castShadow = shadows; rider.add(hel);
  box([0.2, 0.07, 0.05], [0, 1.6, 0.02], dark, rider);

  const beamLight = new THREE.SpotLight('#FFF1C8', 0, 40, 0.5, 0.6, 1.2);
  beamLight.position.set(0, def.lights.y, def.lights.z);
  beamLight.target.position.set(0, 0, def.lights.z + 12);
  if (headlightBeam) root.add(beamLight, beamLight.target);

  let spin = 0, leanAngle = 0;
  return {
    root, def,
    eyeRoot: lean, // the rider's eye leans with the bike
    get leanAngle() { return leanAngle; },
    setRiderVisible(v) { rider.visible = v; },
    setLights(v) {
      head.emissiveIntensity = v * 0.9;
      tail.emissiveIntensity = v * 0.6;
      beamLight.intensity = v * 45;
      beamLight.visible = headlightBeam && v > 0.01;
    },
    setPaint(hex) { bodyMat.color.set(hex); },
    update(car, dt) {
      root.position.set(car.x, car.y || 0, car.z);
      root.rotation.set(car.pitch || 0, car.heading, car.bank || 0, 'YXZ'); // heading, then the slope
      spin += (car.vF * dt) / W.r;
      rear.rotation.x = spin; front.rotation.x = spin;
      fork.rotation.y = car.steer * 0.7;
      // lean into the turn (towards the inside), eased
      const target = -THREE.MathUtils.clamp(car.latAccel * def.lean, -def.maxLean, def.maxLean);
      leanAngle += (target - leanAngle) * Math.min(1, dt * 8);
      lean.rotation.z = leanAngle;
    },
    dispose() {
      root.removeFromParent();
      root.traverse(o => o.geometry?.dispose?.());
    },
  };
}

/** Handlebar view: same interface as the car cockpit. */
export function buildBikeCockpit(root, renderer, scene, def) {
  const C = def.cockpit;
  const lean = root.userData.lean || root;
  const g = new THREE.Group();
  g.visible = false;
  lean.add(g);

  const bars = new THREE.Group();
  bars.position.set(0, 1.03, 0.48);
  g.add(bars);
  bars.add(new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.035, 0.035), flat('#1B1E23')));
  for (const s of [-1, 1]) {
    const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.026, 0.13, 8).rotateZ(Math.PI / 2), flat('#262A31'));
    grip.position.x = s * 0.33; bars.add(grip);
    beam(V(s * 0.27, 0.02, -0.01), V(s * 0.31, 0.17, -0.03), 0.015, flat('#262A31'), bars); // mirror stalk
  }
  const clamp = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.05, 0.1), flat('#24282F'));
  clamp.position.set(0, 0.03, 0.01); bars.add(clamp);

  // speed display on top of the clamp, facing the rider
  const dial = createDial(def.physics.speedMax * 3.6);
  const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.14, 0.044), new THREE.MeshBasicMaterial({ map: dial.texture }));
  screen.position.set(0, 0.075, 0.0); screen.rotation.set(-0.5, Math.PI, 0);
  bars.add(screen);

  // two round mirrors on the bars
  const mirror = createMirrorView(root, C.mirrorCam);
  for (const s of [-1, 1]) {
    const rim = new THREE.Mesh(new THREE.CircleGeometry(0.06, 14), flat('#1E2228', { side: THREE.DoubleSide }));
    rim.position.set(s * 0.32, 0.2, -0.035); rim.rotation.y = Math.PI; bars.add(rim);
    const glass = new THREE.Mesh(new THREE.CircleGeometry(0.052, 14), mirror.material);
    glass.position.set(s * 0.32, 0.2, -0.04); glass.rotation.y = Math.PI; bars.add(glass);
  }

  return {
    group: g,
    drawDial: dial.draw,
    windshield: { update() {}, dispose() {}, dropCount: 0, wiperAngle: 0, debugSlow: 1 }, // no glass, no wipers
    eye: new THREE.Vector3(...C.eye),
    look: new THREE.Vector3(...C.look),
    dashEdge: new THREE.Vector3(0, 1.1, 0.5),
    setVisible(v) { g.visible = v; },
    update(dt, car) {
      bars.rotation.y = car.steer * 0.7;
      dial.draw(car.speedKmh);
    },
    mirrorInterval: 0,
    _mirrorWait: 0,
    renderMirrors(dt = 0) {
      this._mirrorWait -= dt;
      if (this._mirrorWait > 0) return;
      this._mirrorWait = this.mirrorInterval;
      g.visible = false;
      mirror.render(renderer, scene);
      g.visible = true;
    },
    dispose() { g.removeFromParent(); mirror.dispose(); dial.dispose(); },
  };
}
