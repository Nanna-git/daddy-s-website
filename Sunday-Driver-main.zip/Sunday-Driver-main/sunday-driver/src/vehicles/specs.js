// Everything that differs between vehicles: body shape, wheels, extras, handling, sound and driver seat.
// Units are metres; the car faces +Z, +Y is up, the driver's left (left-hand drive) is +X.
const KMH = 1 / 3.6, DEG = Math.PI / 180;

export const VEHICLES = {
  hatchback: {
    id: 'hatchback', name: 'Hatchback',
    body: { b: { x: 0.86, y: 0.26, zb: -1.95, zf: 2.0 }, t: { x: 0.86, yb: 1.0, yf: 0.86, zb: -1.93, zf: 1.92 } },
    cabin: { b: { x: 0.82, y: 0.99, zb: -1.9, zf: 0.7 }, t: { x: 0.7, yb: 1.66, yf: 1.66, zb: -1.76, zf: -0.12 } },
    wheel: { r: 0.33, w: 0.22, x: 0.81, zf: 1.28, zr: -1.28 },
    mirror: { x: 0.95, y: 1.11, z: 0.66 },
    lights: { y: 0.75, z: 1.9 },
    roll: 0.012,
    outside: { back: 5.5, height: 2.1, lookY: 1.0 }, // third-person camera
    extras: [],
    physics: {
      speedMax: 120 * KMH, accel: 6, brake: 12, reverseMax: 25 * KMH,
      steerMaxLow: 32 * DEG, steerMaxHigh: 10 * DEG, lateralGrip: 8, wheelbase: 2.56, maxLatAccel: 14,
      mass: 1200, halfWidth: 0.9, halfLength: 2.0,
      gripPow: 1.6, yawGripPow: 0.5, // how much rain/snow loosens the sideways hold / limits turning
    },
    audio: { base: 48, gears: [0, 22, 42, 66, 92, 125], horn: [392, 494] },
    cockpit: {
      eye: [0.36, 1.28, -0.3], look: [-1.3, 1.32, 10],
      dash: { w: 1.68, h: 0.24, d: 0.48, y: 0.9, z: 0.66 },
      wheel: { x: 0.36, y: 0.93, z: 0.34, r: 0.17, tilt: -0.45 },
      floor: { y: 1.012, zb: -1.9 },
      lining: { y: 1.625, zb: -1.7, zf: -0.1, w: 1.44 },
      pillar: { b: [0.8, 0.99, 0.68], t: [0.7, 1.64, -0.1] },
      sill: { x: 0.82, y: 1.12 },
      visor: { y: 1.585, z: -0.06 },
      rearMirror: { y: 1.45, z: 0.08, roof: 1.62 },
      glass: { BL: [0.78, 1.04, 0.63], BR: [-0.78, 1.04, 0.63], TR: [-0.68, 1.61, -0.09], TL: [0.68, 1.61, -0.09] },
      mirrorCam: [0, 1.4, -2.15],
    },
  },

  sports: {
    id: 'sports', name: 'Sports Car',
    body: { b: { x: 0.92, y: 0.22, zb: -2.15, zf: 2.25 }, t: { x: 0.9, yb: 0.82, yf: 0.6, zb: -2.13, zf: 2.05 } },
    cabin: { b: { x: 0.82, y: 0.77, zb: -1.35, zf: 0.55 }, t: { x: 0.66, yb: 1.22, yf: 1.22, zb: -0.95, zf: -0.2 } },
    wheel: { r: 0.34, w: 0.27, x: 0.84, zf: 1.42, zr: -1.36 },
    mirror: { x: 0.98, y: 0.9, z: 0.5 },
    lights: { y: 0.5, z: 2.12 },
    roll: 0.008,
    outside: { back: 5.9, height: 1.8, lookY: 0.8 },
    extras: [
      { size: [1.7, 0.05, 0.34], pos: [0, 1.02, -1.98], mat: 'dark' },  // rear wing
      { size: [0.06, 0.2, 0.12], pos: [0.6, 0.92, -1.98], mat: 'dark' },
      { size: [0.06, 0.2, 0.12], pos: [-0.6, 0.92, -1.98], mat: 'dark' },
      { size: [1.5, 0.04, 0.5], pos: [0, 0.62, 1.55], mat: 'trim' },    // bonnet stripe
    ],
    physics: {
      speedMax: 165 * KMH, accel: 8.5, brake: 13, reverseMax: 25 * KMH,
      steerMaxLow: 30 * DEG, steerMaxHigh: 8 * DEG, lateralGrip: 6.5, wheelbase: 2.78, maxLatAccel: 15,
      mass: 1400, halfWidth: 0.95, halfLength: 2.25,
      gripPow: 2.3, yawGripPow: 0.5, // slides on wet and snowy roads
    },
    audio: { base: 66, gears: [0, 35, 65, 95, 130, 170], horn: [523, 659] },
    cockpit: {
      eye: [0.38, 1.05, -0.45], look: [-1.2, 1.08, 10],
      dash: { w: 1.76, h: 0.2, d: 0.34, y: 0.73, z: 0.25 },
      wheel: { x: 0.38, y: 0.79, z: 0.05, r: 0.16, tilt: -0.6 },
      floor: { y: 0.83, zb: -1.35 },
      lining: { y: 1.19, zb: -1.0, zf: -0.22, w: 1.34 },
      pillar: { b: [0.78, 0.77, 0.55], t: [0.66, 1.22, -0.2] },
      sill: { x: 0.79, y: 0.9 },
      visor: { y: 1.16, z: -0.18 },
      rearMirror: { y: 1.13, z: 0.12, roof: 1.2 },
      glass: { BL: [0.78, 0.86, 0.4], BR: [-0.78, 0.86, 0.4], TR: [-0.66, 1.21, -0.18], TL: [0.66, 1.21, -0.18] },
      mirrorCam: [0, 1.0, -2.4],
    },
  },

  suv: {
    id: 'suv', name: 'SUV / Jeep',
    body: { b: { x: 0.97, y: 0.42, zb: -2.3, zf: 2.35 }, t: { x: 0.97, yb: 1.25, yf: 1.15, zb: -2.3, zf: 2.25 } },
    cabin: { b: { x: 0.92, y: 1.24, zb: -2.28, zf: 0.8 }, t: { x: 0.84, yb: 2.0, yf: 2.0, zb: -2.22, zf: 0.45 } },
    wheel: { r: 0.42, w: 0.3, x: 0.9, zf: 1.5, zr: -1.5 },
    mirror: { x: 1.05, y: 1.45, z: 0.76 },
    lights: { y: 1.0, z: 2.3 },
    roll: 0.016,
    outside: { back: 7.4, height: 3.0, lookY: 1.5 },
    extras: [
      { size: [0.06, 0.07, 2.3], pos: [0.7, 2.04, -0.9], mat: 'dark' },  // roof rails
      { size: [0.06, 0.07, 2.3], pos: [-0.7, 2.04, -0.9], mat: 'dark' },
      { size: [1.5, 0.05, 0.08], pos: [0, 2.06, -0.2], mat: 'dark' },
      { size: [1.5, 0.05, 0.08], pos: [0, 2.06, -1.6], mat: 'dark' },
      { size: [1.6, 0.2, 0.14], pos: [0, 0.62, 2.42], mat: 'dark' },     // front guard
      { spare: true, r: 0.36, w: 0.22, pos: [0, 1.05, -2.42] },           // spare wheel on the tailgate
    ],
    physics: {
      speedMax: 120 * KMH, accel: 5, brake: 10, reverseMax: 22 * KMH,
      steerMaxLow: 30 * DEG, steerMaxHigh: 10 * DEG, lateralGrip: 8.5, wheelbase: 3.0, maxLatAccel: 11.5,
      mass: 2000, halfWidth: 1.0, halfLength: 2.4,
      gripPow: 0.8, yawGripPow: 0.3, // best grip in snow
    },
    audio: { base: 36, gears: [0, 20, 40, 62, 88, 125], horn: [311, 392] },
    cockpit: {
      eye: [0.4, 1.72, -0.35], look: [-1.3, 1.7, 10],
      dash: { w: 1.84, h: 0.3, d: 0.4, y: 1.25, z: 0.52 },
      wheel: { x: 0.4, y: 1.33, z: 0.14, r: 0.19, tilt: -0.35 },
      floor: { y: 1.27, zb: -2.25 },
      lining: { y: 1.97, zb: -2.1, zf: 0.42, w: 1.64 },
      pillar: { b: [0.88, 1.24, 0.8], t: [0.82, 2.0, 0.45] },
      sill: { x: 0.88, y: 1.38 },
      visor: { y: 1.93, z: 0.4 },
      rearMirror: { y: 1.86, z: 0.36, roof: 1.97 },
      glass: { BL: [0.86, 1.42, 0.72], BR: [-0.86, 1.42, 0.72], TR: [-0.8, 1.96, 0.46], TL: [0.8, 1.96, 0.46] },
      mirrorCam: [0, 1.8, -2.65],
    },
  },
};

VEHICLES.bus = {
  id: 'bus', name: 'City Bus',
  body: { b: { x: 1.25, y: 0.35, zb: -5.0, zf: 5.0 }, t: { x: 1.25, yb: 1.3, yf: 1.3, zb: -5.0, zf: 4.98 } },
  cabin: { b: { x: 1.25, y: 1.29, zb: -4.98, zf: 4.96 }, t: { x: 1.2, yb: 3.0, yf: 3.0, zb: -4.9, zf: 4.84 } },
  sideWindows: [[0.03, 0.2], [0.23, 0.39], [0.42, 0.58], [0.61, 0.77], [0.8, 0.9]], // a row of windows (back → front)
  wheel: { r: 0.5, w: 0.32, x: 1.08, zf: 3.3, zr: -2.8 },
  mirror: { x: 1.38, y: 2.3, z: 5.05 },
  lights: { y: 0.8, z: 5.05 },
  roll: 0.02,
  outside: { back: 14, height: 5.2, lookY: 2.0 },
  showcaseScale: 0.55, // shrink it to fit the turntable
  extras: [
    { size: [2.0, 0.16, 0.05], pos: [0, 2.91, 4.87], mat: 'sign' },     // destination sign
    { size: [1.6, 0.26, 2.6], pos: [0, 3.12, -1.0], mat: 'trim' },      // roof air-con unit
    { size: [0.04, 2.3, 0.95], pos: [-1.27, 1.5, 4.2], mat: 'glass' },  // front door (kerb side)
    { size: [0.04, 2.3, 1.2], pos: [-1.27, 1.5, 0.1], mat: 'glass' },   // middle door
    { size: [2.4, 0.2, 0.12], pos: [0, 0.5, 5.04], mat: 'dark' },       // front bumper
    { size: [2.4, 0.2, 0.12], pos: [0, 0.5, -5.04], mat: 'dark' },      // rear bumper
  ],
  physics: {
    speedMax: 80 * KMH, accel: 2.8, brake: 8, reverseMax: 15 * KMH,
    steerMaxLow: 40 * DEG, steerMaxHigh: 12 * DEG, lateralGrip: 9, wheelbase: 6.1, maxLatAccel: 7,
    mass: 9000, halfWidth: 1.3, halfLength: 5.1,
    gripPow: 1.2, yawGripPow: 0.4,
  },
  audio: { base: 30, gears: [0, 15, 30, 48, 65, 85], horn: [233, 294] },
  cockpit: {
    eye: [0.72, 2.45, 3.75], look: [-1.6, 2.15, 16],
    dash: { w: 2.36, h: 0.3, d: 0.4, y: 1.95, z: 4.62 },
    wheel: { x: 0.72, y: 2.18, z: 4.3, r: 0.26, tilt: -1.1 }, // big and nearly flat
    header: { y: 2.86, h: 0.24, z: 4.8 },                       // panel above the glass (hides the destination sign)
    floor: { y: 1.33, zb: -4.9 },
    lining: { y: 2.97, zb: -4.8, zf: 4.78, w: 2.36 },
    pillar: { b: [1.2, 1.3, 4.93], t: [1.16, 2.98, 4.84] },
    sill: { x: 1.2, y: 1.5 },
    visor: { y: 2.88, z: 4.6 },
    rearMirror: { y: 2.8, z: 4.55, roof: 2.97 },
    glass: { BL: [1.18, 2.12, 4.88], BR: [-1.18, 2.12, 4.88], TR: [-1.15, 2.95, 4.83], TL: [1.15, 2.95, 4.83] },
    mirrorCam: [0, 2.4, -5.3],
  },
};

VEHICLES.moto = {
  id: 'moto', name: 'Motorbike', kind: 'bike',
  wheel: { r: 0.32, w: 0.12, zf: 0.72, zr: -0.68 },
  lights: { y: 0.95, z: 0.66 },
  outside: { back: 4.2, height: 1.7, lookY: 0.9 },
  showcaseScale: 1.15,
  lean: 0.055, maxLean: 0.55, // tilts into turns
  physics: {
    speedMax: 140 * KMH, accel: 7.5, brake: 11, reverseMax: 8 * KMH,
    steerMaxLow: 34 * DEG, steerMaxHigh: 9 * DEG, lateralGrip: 9, wheelbase: 1.42, maxLatAccel: 13,
    mass: 250, halfWidth: 0.45, halfLength: 1.1,
    gripPow: 1.9, yawGripPow: 0.6, // two small tyres: nimble, but careful in snow
  },
  audio: { base: 78, gears: [0, 30, 55, 80, 110, 145], horn: [587, 740] },
  cockpit: {
    eye: [0, 1.48, -0.3], look: [0, 1.25, 12],
    mirrorCam: [0, 1.3, -1.2],
  },
};

// Metro taxis: a hatchback with a roof sign (AI traffic only, not in the menu)
VEHICLES.taxi = {
  ...VEHICLES.hatchback, id: 'taxi', name: 'Taxi',
  extras: [{ size: [0.5, 0.16, 0.24], pos: [0, 1.74, -0.95], mat: 'sign' }, { size: [1.7, 0.06, 0.02], pos: [0, 0.62, 2.0], mat: 'dark' }],
};

export const READY = ['hatchback', 'sports', 'suv', 'bus', 'moto'];
