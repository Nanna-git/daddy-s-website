// Weather on the glass in driver view: rain beads and runners, snowflakes, frost, twin wipers.
// Everything is drawn into one small canvas mapped onto the inside of the windshield.
import * as THREE from 'three';

const W = 768;                                // canvas width; height follows the glass shape (~2 mm per px)
const SWEEP = 110, CYCLE = 1.2;               // degrees, seconds per sweep and back

/** quad: inside face of the windshield (car-local) { BL, BR, TR, TL }, BL = bottom-left as seen by the driver */
export function createWindshield(parent, { BL, BR, TR, TL }) {
  const width = Math.hypot(BL[0] - BR[0], BL[1] - BR[1], BL[2] - BR[2]);
  const height = Math.hypot(BL[0] - TL[0], BL[1] - TL[1], BL[2] - TL[2]);
  const H = Math.round(Math.min(640, Math.max(240, W * height / width)));
  const WIPERS = [
    { x: W * 0.26, y: H - 12, len: Math.min(W * 0.51, H * 0.92) },
    { x: W * 0.68, y: H - 12, len: Math.min(W * 0.44, H * 0.8) },
  ];
  const canvas = document.createElement('canvas');
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext('2d');
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute([...BL, ...BR, ...TR, ...BL, ...TR, ...TL], 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute([0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1], 2));
  const glass = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, side: THREE.DoubleSide, fog: false }));
  glass.visible = false;
  glass.renderOrder = 5;
  parent.add(glass);

  const drops = [];
  let phase = 0, angle = 0, wiping = false, spawnRain = 0, spawnSnow = 0, frost = 0, dirty = true;

  function sweepClear(prev, cur) {
    const lo = Math.min(prev, cur) - 3, hi = Math.max(prev, cur) + 3;
    for (let i = drops.length - 1; i >= 0; i--) {
      const d = drops[i];
      for (const w of WIPERS) {
        const dx = d.x - w.x, dy = w.y - d.y;
        const a = Math.atan2(dy, dx) * 180 / Math.PI;
        if (Math.hypot(dx, dy) <= w.len + d.r && a >= lo && a <= hi) { drops.splice(i, 1); break; }
      }
    }
  }

  function draw() {
    ctx.clearRect(0, 0, W, H);
    if (frost > 0.01) {
      const g = ctx.createLinearGradient(0, H * 0.55, 0, H);
      g.addColorStop(0, 'rgba(255,255,255,0)');
      g.addColorStop(1, `rgba(255,255,255,${0.6 * frost})`);
      ctx.fillStyle = g;
      ctx.fillRect(0, H * 0.55, W, H * 0.45);
    }
    for (const d of drops) {
      ctx.beginPath();
      if (d.snow) {
        ctx.fillStyle = `rgba(255,255,255,${0.88 * d.a})`;
        ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.ellipse(d.x, d.y, d.r, d.r * 1.12, 0, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(214,226,240,${0.22 * d.a})`;
        ctx.fill();
        ctx.lineWidth = 1.2;
        ctx.strokeStyle = `rgba(255,255,255,${0.5 * d.a})`;
        ctx.stroke();
        if (d.trail) {
          ctx.fillStyle = `rgba(230,240,250,${0.18 * d.a})`;
          const up = d.vy < 0; // trail is behind the direction the drop runs
          ctx.fillRect(d.x - 1, up ? d.y : d.y - d.trail, 2, d.trail);
        }
      }
    }
    if (angle > 0.01 || wiping) {
      for (const w of WIPERS) {
        const a = angle * Math.PI / 180, ex = w.x + Math.cos(a) * w.len, ey = w.y - Math.sin(a) * w.len;
        ctx.lineCap = 'round';
        ctx.strokeStyle = '#15171B'; ctx.lineWidth = 7;
        ctx.beginPath(); ctx.moveTo(w.x, w.y); ctx.lineTo(ex, ey); ctx.stroke();
        const bx = w.x + Math.cos(a) * w.len * 0.4, by = w.y - Math.sin(a) * w.len * 0.4;
        ctx.strokeStyle = '#0F1114'; ctx.lineWidth = 12;
        ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(ex, ey); ctx.stroke();
        ctx.fillStyle = '#15171B'; ctx.beginPath(); ctx.arc(w.x, w.y, 14, 0, Math.PI * 2); ctx.fill();
      }
    }
    tex.needsUpdate = true;
  }

  return {
    dispose() { tex.dispose(); geo.dispose(); },
    debugSlow: 1, // dev: > 1 slows the wipers down for screenshots
    get dropCount() { return drops.length; },
    get wiperAngle() { return angle; },
    update(dt, look, kmh) {
      const rain = look.rain, snow = look.snow;

      // new rain beads and flakes landing
      spawnRain += rain * (45 + kmh * 0.5) * dt;
      while (spawnRain >= 1 && drops.length < 190) {
        spawnRain -= 1;
        const r = 1.4 + Math.random() * 2.6;
        drops.push({ x: Math.random() * W, y: Math.random() * H * 0.92, r, a: 1, trail: 0, vy: 0, runner: r > 3.4 && Math.random() < 0.6 });
        dirty = true;
      }
      if (spawnRain >= 1) spawnRain = 0;
      spawnSnow += snow * 9 * dt;
      while (spawnSnow >= 1 && drops.length < 190) {
        spawnSnow -= 1;
        drops.push({ x: Math.random() * W, y: Math.random() * H * 0.9, r: 2 + Math.random() * 3, a: 1, snow: true });
        dirty = true;
      }
      if (spawnSnow >= 1) spawnSnow = 0;

      // big drops run: down when slow, pushed up the glass by the wind at speed
      for (let i = drops.length - 1; i >= 0; i--) {
        const d = drops[i];
        if (d.runner) {
          const vy = kmh > 35 ? -(kmh - 35) * 1.8 : 28;
          d.vy = vy;
          d.y += vy * dt;
          d.trail = Math.min(50, d.trail + Math.abs(vy) * dt * 0.6);
          dirty = true;
          if (d.y < -10 || d.y > H + 10) drops.splice(i, 1);
        }
        if (rain < 0.01 && snow < 0.01) { d.a -= dt * 0.25; dirty = true; if (d.a <= 0) drops.splice(i, 1); } // glass dries
      }

      const wantFrost = snow;
      if (Math.abs(frost - wantFrost) > 0.002) { frost += (wantFrost - frost) * Math.min(1, dt * 0.5); dirty = true; }

      // wipers: run while it rains or snows, then finish the sweep and park
      const active = rain > 0.3 || snow > 0.3;
      if (active || angle > 0.01) {
        const prev = angle;
        phase += dt / this.debugSlow;
        if (!active && phase >= CYCLE) { phase = 0; angle = 0; }
        else {
          phase %= CYCLE;
          angle = SWEEP * (1 - Math.cos((phase / CYCLE) * Math.PI * 2)) / 2;
        }
        sweepClear(prev, angle);
        wiping = active;
        dirty = true;
      } else if (wiping) { wiping = false; dirty = true; }

      glass.visible = drops.length > 0 || frost > 0.01 || angle > 0.01 || active;
      if (dirty && glass.visible) { draw(); dirty = false; }
    },
  };
}
