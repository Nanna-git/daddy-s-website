-- Sunday Driver: email-only entry (no Supabase Auth). Run once in Supabase → SQL Editor → New query → Run.
-- Safe to re-run. Keeps all existing rows: people from the magic-link era are matched by email and keep their user_id.
-- The browser calls only the functions below with the public key; the tables are closed to direct access.

-- 1) user_id no longer has to be a real Supabase Auth user.
do $$
declare r record;
begin
  for r in
    select conrelid::regclass as tbl, conname from pg_constraint
    where contype = 'f' and confrelid = 'auth.users'::regclass
      and conrelid in ('public.profiles'::regclass, 'public.journeys'::regclass, 'public.sessions'::regclass)
  loop
    execute format('alter table %s drop constraint %I', r.tbl, r.conname);
  end loop;
end $$;
alter table public.profiles alter column user_id set default gen_random_uuid();

-- 2) Close direct table access (functions below are security definer, so they still work).
revoke all on public.profiles, public.journeys, public.sessions from anon, authenticated;

-- 3) Retire the previous visits log (sessions_history now answers "who and when").
drop table if exists public.visits;

-- 4) Functions. The old auth.uid()-based session functions are replaced.
drop function if exists public.start_session(uuid);
drop function if exists public.ping_session(uuid);
drop function if exists public.end_session(uuid, text);

-- Get or create the user for an email (everyone counts as verified). Existing profiles keep their user_id.
create or replace function public.enter_app(p_email text)
returns table (user_id uuid, display_name text, avatar_id text)
language plpgsql security definer set search_path = public as $$
declare e text := lower(btrim(p_email));
begin
  if e is null or char_length(e) > 254 or e !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then
    raise exception 'invalid email';
  end if;
  insert into public.profiles (email) values (e) on conflict (lower(email)) do nothing;
  return query select p.user_id, p.display_name, p.avatar_id from public.profiles p where lower(p.email) = e;
end $$;

create or replace function public.save_profile(p_user uuid, p_name text, p_avatar text) returns void
language sql security definer set search_path = public as $$
  update public.profiles set display_name = p_name, avatar_id = p_avatar, updated_at = now() where user_id = p_user;
$$;

create or replace function public.get_journey(p_user uuid) returns jsonb
language sql security definer set search_path = public as $$
  select jsonb_build_object('data', data, 'updated_at', updated_at) from public.journeys where user_id = p_user;
$$;

create or replace function public.save_journey(p_user uuid, p_data jsonb) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.profiles where user_id = p_user) then return; end if;
  if pg_column_size(p_data) > 200000 then raise exception 'journey too large'; end if;
  insert into public.journeys (user_id, data, updated_at) values (p_user, p_data, now())
  on conflict (user_id) do update set data = excluded.data, updated_at = now();
end $$;

create or replace function public.delete_journey(p_user uuid) returns void
language sql security definer set search_path = public as $$
  delete from public.journeys where user_id = p_user;
$$;

create or replace function public.start_session(p_user uuid, p_id uuid) returns void
language sql security definer set search_path = public as $$
  insert into public.sessions (id, user_id)
  select p_id, p_user where exists (select 1 from public.profiles where user_id = p_user)
  on conflict do nothing;
$$;
create or replace function public.ping_session(p_user uuid, p_id uuid) returns void
language sql security definer set search_path = public as $$
  update public.sessions set last_seen_at = now()
  where id = p_id and user_id = p_user and logout_at is null;
$$;
create or replace function public.end_session(p_user uuid, p_id uuid, p_reason text) returns void
language sql security definer set search_path = public as $$
  update public.sessions set logout_at = now(), last_seen_at = now(),
         logout_reason = case when p_reason = 'tab_closed' then 'tab_closed' else 'manual' end
  where id = p_id and user_id = p_user and logout_at is null;
$$;

do $$
declare f text;
begin
  foreach f in array array[
    'enter_app(text)', 'save_profile(uuid,text,text)', 'get_journey(uuid)', 'save_journey(uuid,jsonb)',
    'delete_journey(uuid)', 'start_session(uuid,uuid)', 'ping_session(uuid,uuid)', 'end_session(uuid,uuid,text)']
  loop
    execute format('revoke all on function public.%s from public', f);
    execute format('grant execute on function public.%s to anon, authenticated', f);
  end loop;
end $$;

-- Who used the app and when: Table editor → sessions_history (unchanged view; it joins profiles by user_id).
