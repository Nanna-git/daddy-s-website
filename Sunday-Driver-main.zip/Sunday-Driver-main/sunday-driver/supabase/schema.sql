-- Sunday Driver: run this once in Supabase → SQL Editor → New query → Run.
-- Safe to re-run (everything is "if not exists" / "or replace").

-- ---------- profiles: one row per user, created automatically on first sign-in ----------
create table if not exists public.profiles (
  user_id      uuid primary key references auth.users(id) on delete cascade,
  email        text not null,
  display_name text check (display_name is null or char_length(display_name) between 2 and 24),
  avatar_id    text check (avatar_id is null or avatar_id ~ '^car-([1-9]|1[0-2])$'),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create unique index if not exists profiles_email_key on public.profiles (lower(email));

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (user_id, email) values (new.id, new.email) on conflict do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;
drop policy if exists "own profile read"   on public.profiles;
drop policy if exists "own profile update" on public.profiles;
create policy "own profile read"   on public.profiles for select to authenticated using (user_id = auth.uid());
create policy "own profile update" on public.profiles for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
-- users may change only name + avatar, never their user_id or email
revoke update on public.profiles from authenticated;
grant  update (display_name, avatar_id) on public.profiles to authenticated;

-- ---------- journeys: one saved journey per user ----------
create table if not exists public.journeys (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  data       jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.journeys enable row level security;
drop policy if exists "own journey" on public.journeys;
create policy "own journey" on public.journeys for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ---------- sessions: login / logout log (admin-only; the game writes through 3 functions) ----------
create table if not exists public.sessions (
  id             uuid primary key,
  user_id        uuid not null references auth.users(id) on delete cascade,
  login_at       timestamptz not null default now(),
  last_seen_at   timestamptz not null default now(),
  logout_at      timestamptz,
  logout_reason  text check (logout_reason in ('manual', 'tab_closed'))
);
create index if not exists sessions_user_idx on public.sessions (user_id, login_at desc);
alter table public.sessions enable row level security;   -- no policies: nobody but the dashboard can read it
revoke all on public.sessions from anon, authenticated;

create or replace function public.start_session(p_id uuid) returns void
language sql security definer set search_path = public as $$
  insert into public.sessions (id, user_id) values (p_id, auth.uid()) on conflict do nothing;
$$;
create or replace function public.ping_session(p_id uuid) returns void
language sql security definer set search_path = public as $$
  update public.sessions set last_seen_at = now()
  where id = p_id and user_id = auth.uid() and logout_at is null;
$$;
create or replace function public.end_session(p_id uuid, p_reason text) returns void
language sql security definer set search_path = public as $$
  update public.sessions set logout_at = now(), last_seen_at = now(),
         logout_reason = case when p_reason = 'tab_closed' then 'tab_closed' else 'manual' end
  where id = p_id and user_id = auth.uid() and logout_at is null;
$$;
revoke all on function public.start_session(uuid), public.ping_session(uuid), public.end_session(uuid, text) from public, anon;
grant execute on function public.start_session(uuid), public.ping_session(uuid), public.end_session(uuid, text) to authenticated;

-- Readable history for you (dashboard → Table editor → sessions_history).
-- A session with no ping for 2 minutes counts as ended at its last ping ('timeout').
create or replace view public.sessions_history as
select s.id, p.email, p.display_name, s.login_at,
       coalesce(s.logout_at, case when s.last_seen_at < now() - interval '2 minutes' then s.last_seen_at end) as logout_at,
       case when s.logout_at is not null then s.logout_reason
            when s.last_seen_at < now() - interval '2 minutes' then 'timeout'
            else 'active' end as status,
       s.last_seen_at
from public.sessions s join public.profiles p on p.user_id = s.user_id
order by s.login_at desc;
revoke all on public.sessions_history from anon, authenticated;
