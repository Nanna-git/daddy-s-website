// Run: node tests/multiplayer.test.mjs   (pure helpers only; no network, no browser)
import assert from 'node:assert/strict';
globalThis.document = { }; globalThis.innerWidth = 800; globalThis.innerHeight = 600;
const { joinOrder, rankOf, uniqueNames, instanceName, instanceLabel, MAX_PLAYERS } = await import('../src/multiplayer.js');

const P = (id, name, joinedAt) => ({ id, name, joinedAt });

// join order is oldest first; ties broken by id so every client agrees
assert.deepEqual(joinOrder([P('b', 'x', 2), P('a', 'y', 2), P('c', 'z', 1)]).map(p => p.id), ['c', 'a', 'b']);

// rank: full instance pushes the 13th player out
const full = Array.from({ length: 13 }, (_, i) => P('p' + String(i).padStart(2, '0'), 'n' + i, i));
assert.equal(MAX_PLAYERS, 12);
assert.equal(rankOf(full, 'p11'), 12);
assert.equal(rankOf(full, 'p12'), 13);
assert.equal(rankOf(full, 'nobody'), 0);

// duplicate names: later joiner gets #2, then #3; case-insensitive; unique names untouched
const n = uniqueNames([P('a', 'Sam', 1), P('b', 'sam', 2), P('c', 'Alex', 3), P('d', 'Sam', 4)]);
assert.equal(n.get('a'), 'Sam');
assert.equal(n.get('b'), 'sam #2');
assert.equal(n.get('c'), 'Alex');
assert.equal(n.get('d'), 'Sam #3');
assert.equal(uniqueNames([P('a', '', 1)]).get('a'), 'Driver');

assert.equal(instanceName('harbor', 2), 'harbor-2');
assert.equal(instanceLabel(1), ''); assert.equal(instanceLabel(2), ' 2');

const { angleDiff, tagOpacity, predict, TAG_RANGE } = await import('../src/remoteMath.js');
{
  assert.ok(Math.abs(angleDiff(0.1, 2 * Math.PI - 0.1) + 0.2) < 1e-9);   // wraps the short way
  assert.equal(tagOpacity(50), 1); assert.equal(tagOpacity(TAG_RANGE), 0);
  assert.ok(tagOpacity(125) > 0 && tagOpacity(125) < 1);
  const p = predict({ x: 0, z: 0, h: 0, v: 10 }, 0.2);               // heading 0 faces +Z
  assert.ok(Math.abs(p.z - 2) < 1e-9 && Math.abs(p.x) < 1e-9);
  assert.equal(predict({ x: 0, z: 0, h: 0, v: 10 }, 5).z, 4);         // capped at 0.4 s
}
console.log('multiplayer helper tests passed');

// ---------- crashes: damage maths, car-vs-car collision, wall impact speed ----------
const D = await import('../src/damage.js');
const { collideCar, overlapBoxes } = await import('../src/carCollision.js');
const { CarPhysics } = await import('../src/vehicles/carPhysics.js');
const { resolveCollisions } = await import('../src/collision.js');
const { VEHICLES } = await import('../src/vehicles/specs.js');
{
  const kmh = v => v / 3.6;
  assert.equal(D.impactDamage(kmh(9)), 0);                                  // gentle bump: nothing
  assert.ok(D.impactDamage(kmh(50)) > 15 && D.impactDamage(kmh(50)) < 30);
  assert.ok(D.impactDamage(kmh(100)) > D.impactDamage(kmh(50)));
  assert.equal(D.impactDamage(kmh(400)), D.MAX_HIT);                        // capped per hit
  assert.ok(D.impactDamage(kmh(50), 2) > D.impactDamage(kmh(50), 1));       // heavier thing hurts more
  assert.equal(D.massFactor(9000, 250), 2); assert.equal(D.massFactor(250, 9000), 0.5); assert.equal(D.massFactor(1200, 1200), 1);
  assert.equal(D.addDamage(95, 70), 100);
  assert.equal(D.repairStep(100, 5), 0); assert.equal(D.repairStep(10, 1), 0);
  assert.equal(D.performanceFactor(0), 1); assert.ok(Math.abs(D.performanceFactor(100) - 0.7) < 1e-9);
  assert.equal(D.tintPaint('#ff6a4d', 0), '#ff6a4d');
  assert.notEqual(D.tintPaint('#ff6a4d', 100), '#ff6a4d');
  assert.equal(D.SMOKE_FROM, 60);
  const pads = [{ x: 10, z: 10, y: 0 }];
  assert.ok(D.padUnder(pads, 12, 10)); assert.equal(D.padUnder(pads, 20, 10), null);
  assert.equal(D.padUnder(pads, 10, 10, 8), null);                          // up on Metro's highway: not the pad below
  assert.ok(D.isRepairing(pads[0], 2, 30)); assert.ok(!D.isRepairing(pads[0], 20, 30)); assert.ok(!D.isRepairing(null, 0, 30)); assert.ok(!D.isRepairing(pads[0], 0, 0));
}
{
  // boxes: overlap and separation
  const box = (x, z, h = 0) => ({ x, z, fx: Math.sin(h), fz: Math.cos(h), hw: 0.9, hl: 2 });
  assert.equal(overlapBoxes(box(0, 0), box(0, 10)), null);
  const o = overlapBoxes(box(0, 0), box(0, 3));                             // nose to tail, 1 m deep
  assert.ok(Math.abs(o.depth - 1) < 1e-6 && o.nz < 0 && Math.abs(o.nx) < 1e-6);
  assert.equal(overlapBoxes(box(0, 0), box(1.9, 0)), null);                 // side by side, 0.1 m gap
  assert.ok(overlapBoxes(box(0, 0), box(1.7, 0)));                          // 0.1 m overlap
  assert.ok(overlapBoxes(box(0, 0), box(0, 3.9, 0.8)));                     // rotated, still touching

  const remote = (o = {}) => ({ x: 0, y: 0, z: 3, heading: 0, vx: 0, vz: 0, hw: 0.9, hl: 2, mass: 1200, armed: true, ...o });
  // head-on at 54 km/h into a parked equal-mass car: bounces back, closing speed reported
  let car = new CarPhysics(VEHICLES.hatchback.physics, { x: 0, z: 0, heading: 0 }); car.vF = 15;
  let r = collideCar(car, remote());
  assert.ok(Math.abs(r.closing - 15) < 1e-6 && r.massRatio === 1);
  assert.ok(car.vF < 15 * (1 - 1.35 * 0.5) + 1e-6 && car.z < 0);            // share ½: vF = 15 − 1.35·½·15 ≈ 4.9 and pushed back
  // moving apart: pushed out but no hit
  car = new CarPhysics(VEHICLES.hatchback.physics, { x: 0, z: 0, heading: 0 }); car.vF = -2;
  assert.equal(collideCar(car, remote()), null);
  // not armed (spawned inside each other): ignored until apart once
  car = new CarPhysics(VEHICLES.hatchback.physics, { x: 0, z: 0, heading: 0 }); car.vF = 15;
  const ghost = remote({ armed: false });
  assert.equal(collideCar(car, ghost), null); assert.equal(car.vF, 15); assert.equal(ghost.armed, false);
  car.z = -20; assert.equal(collideCar(car, ghost), null); assert.equal(ghost.armed, true);   // apart once → live
  // on another level: no contact
  car = new CarPhysics(VEHICLES.hatchback.physics, { x: 0, z: 0, heading: 0 }); car.vF = 15;
  assert.equal(collideCar(car, remote({ y: 8 })), null);
  // mass: a bike hitting a bus gets thrown back much harder than the bus gets shoved
  const bike = new CarPhysics(VEHICLES.moto.physics, { x: 0, z: 0, heading: 0 }); bike.vF = 10;
  const bus = remote({ mass: VEHICLES.bus.physics.mass, hw: 1.3, hl: 5.1, z: 6 });
  const rb = collideCar(bike, bus);
  assert.ok(rb.massRatio > 30 && bike.vF < 0);
  const heavy = new CarPhysics(VEHICLES.bus.physics, { x: 0, z: 0, heading: 0 }); heavy.vF = 10;
  collideCar(heavy, remote({ mass: 250, hw: 0.45, hl: 1.1, z: 6.3 }));
  assert.ok(heavy.vF > 8);                                                   // barely notices a bike
  assert.ok(D.impactDamage(10, D.massFactor(9000, 250)) > D.impactDamage(10, D.massFactor(250, 9000)));
}
{
  // walls report how hard they were hit
  const car = new CarPhysics(VEHICLES.hatchback.physics, { x: 0, z: 0, heading: 0 }); car.vF = 20;
  const wall = { minX: -10, maxX: 10, minZ: 1.5, maxZ: 5 };
  const hit = resolveCollisions(car, { boxes: [wall], circles: [] });
  assert.ok(hit > 15 && hit <= 20.001);
  assert.equal(resolveCollisions(new CarPhysics(VEHICLES.hatchback.physics, { x: 0, z: -50, heading: 0 }), { boxes: [wall], circles: [] }), 0);
  // damaged cars are slower and pull
  const a = new CarPhysics(VEHICLES.hatchback.physics, { x: 0, z: 0, heading: 0 }), b = new CarPhysics(VEHICLES.hatchback.physics, { x: 0, z: 0, heading: 0 });
  b.damage = 100;
  for (let i = 0; i < 60 * 40; i++) { a.step(1 / 60, { up: 1, down: 0, left: 0, right: 0 }); b.step(1 / 60, { up: 1, down: 0, left: 0, right: 0 }); }
  assert.ok(b.speedKmh < a.speedKmh * 0.75 && b.speedKmh > a.speedKmh * 0.65); assert.ok(Math.abs(b.x) > Math.abs(a.x) + 5);
}
console.log('crash tests ok');

// ---------- chat: pure helpers ----------
{
  const C = await import('../src/chatCore.js');
  assert.equal(C.cleanText('  hi\n\tthere\u0000  '), 'hi there');
  assert.equal(C.cleanText('x'.repeat(500)).length, C.MAX_LEN);
  assert.equal(C.cleanText(null), '');
  assert.equal(C.cleanText('a‮b'), 'a b');                     // bidi override stripped
  assert.equal(C.maskWords('what the shit'), 'what the ****');
  assert.equal(C.maskWords('Shitty. FUCK!'), '******. ****!');
  assert.equal(C.maskWords('Scunthorpe class assess'), 'Scunthorpe class assess'); // no false hits inside words
  assert.equal(C.parseIncoming({ id: 'a', q: 1 }, 'Sam').text, 'Follow me');
  assert.equal(C.parseIncoming({ id: 'a', q: 1 }, 'Sam').phrase, true);
  assert.equal(C.parseIncoming({ id: 'a', q: 99 }, 'Sam'), null);
  assert.equal(C.parseIncoming({ id: 'a', t: '<img src=x onerror=1>' }, 'Sam').text, '<img src=x onerror=1>'); // kept as text; the UI uses textContent
  assert.equal(C.parseIncoming({ id: 'a', t: '   ' }, 'Sam'), null);
  assert.equal(C.parseIncoming({ t: 'no id' }, 'Sam'), null);
  assert.equal(C.parseIncoming({ id: 'a', t: 5 }, 'Sam'), null);
  assert.equal(C.parseIncoming({ id: 'a', t: 'x'.repeat(999) }, 'Sam').text.length, C.MAX_LEN);
  const h = []; for (let i = 0; i < 60; i++) C.pushHistory(h, { id: 'a', at: i, text: String(i) });
  assert.equal(h.length, C.HISTORY_MAX); assert.equal(h[0].text, '10');
  const log = [{ id: 'a', at: 0 }, { id: 'b', at: 9000 }, { id: 'c', at: 9500 }];
  assert.deepEqual(C.visibleLog(log, new Set(['c']), 10000).map(m => m.id), ['b']);   // a faded, c muted
  assert.equal(C.visibleLog(Array.from({ length: 9 }, (_, i) => ({ id: 'a', at: 9000 + i })), new Set(), 9100).length, C.LOG_LINES);
  assert.ok(C.canSendNow(0, 1500) && !C.canSendNow(0, 1499));
  assert.equal(C.PHRASES.length, 6);
}
console.log('chat helper tests passed');
