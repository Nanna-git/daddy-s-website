# Achmad Farizky — Story Site Design — entire project

This project’s pages, files, and uploads as this browser tab had them at export.
Anything left out is listed below.

## Contents

### Overview

- `Main.dc.html` — Cover · site map

### Design system

- `DS-Colors.dc.html` — Colour · light & dark
- `DS-Type.dc.html` — Type · spacing · radius
- `DS-Components.dc.html` — Components · icons · threads
- `DS-Art.dc.html` — 3D art rules · prop kit
- `Diorama.dc.html` — Scene engine (Diorama component)
- `Hud.dc.html` — HUD overlay component
- `Thread.dc.html` — Thread tag component

### Templates T1–T5

- `T1.dc.html` — T1 Hero · light
- `T2.dc.html` — T2 Text + Scene · light
- `T3.dc.html` — T3 Scene + Caption · light
- `T4.dc.html` — T4 Quote · light
- `T5.dc.html` — T5 Grid / List · light
- `TemplatesDark.dc.html` — T1–T5 · dark
- `Phone.dc.html` — Phone & tablet example

### Home (6 views)

- `H01.dc.html` — Home · V01 · T1
- `H02.dc.html` — Home · V02 · text left + visual
- `H02b.dc.html` — Home · V03 · text left + visual
- `H03.dc.html` — Home · V04 · T2 + thread
- `H04.dc.html` — Home · V05 · T2 + thread
- `H05.dc.html` — Home · V06 · T2 + thread
- `H01alt.dc.html` — Home · V01 alt · greeting on the wall (trial)
- `H01altB.dc.html` — Home · V01 alt B · title on the wall (trial)
- `H01altC.dc.html` — Home · V01 alt C · professional greeting (trial)
- `H01altD.dc.html` — Home · V01 alt D · professional greeting (trial)
- `H01altE.dc.html` — Home · V01 alt E · professional greeting (trial)
- `H01altF.dc.html` — Home · V01 alt F · professional greeting, mix of D and E (trial)
- `HomeNight.dc.html` — Home · all views at night

### 2.1 University (11 views)

- `U01.dc.html` — University · V1.01
- `U02.dc.html` — University · V1.02
- `U03.dc.html` — University · V1.03
- `U04.dc.html` — University · V1.04
- `U05.dc.html` — University · V1.05
- `U06.dc.html` — University · V1.06 thread
- `U07.dc.html` — University · V1.07 thread
- `U08.dc.html` — University · V1.08
- `U09.dc.html` — University · V1.09 · T3
- `U10.dc.html` — University · V1.10 · T5
- `U11.dc.html` — University · V1.11 · T5
- `UniNight.dc.html` — University · all views at night

### 2.2 Telkomsel (10 views)

- `TK01.dc.html` — Telkomsel · V2.01
- `TK02.dc.html` — Telkomsel · V2.02
- `TK03.dc.html` — Telkomsel · V2.03
- `TK04.dc.html` — Telkomsel · V2.04
- `TK05.dc.html` — Telkomsel · V2.05 thread
- `TK06.dc.html` — Telkomsel · V2.06 thread
- `TK07.dc.html` — Telkomsel · V2.07 thread
- `TK08.dc.html` — Telkomsel · V2.08 · T3
- `TK09.dc.html` — Telkomsel · V2.09 · T5
- `TK10.dc.html` — Telkomsel · V2.10 · T5
- `TKNight.dc.html` — Telkomsel · all views at night

### 2.3 A year of trying (5 views)

- `YT01.dc.html` — A year of trying · V3.01
- `YT02.dc.html` — A year of trying · V3.02
- `YT03.dc.html` — A year of trying · V3.03 thread
- `YT04.dc.html` — A year of trying · V3.04
- `YT05.dc.html` — A year of trying · V3.05 · T5
- `YTNight.dc.html` — A year of trying · all views at night

### 2.4 Ericsson (18 views)

- `ER01.dc.html` — Ericsson · V4.01
- `ER02.dc.html` — Ericsson · V4.02 · 4a STC
- `ER03.dc.html` — Ericsson · V4.03
- `ER04.dc.html` — Ericsson · V4.04 · 4b Mobily
- `ER05.dc.html` — Ericsson · V4.05
- `ER06.dc.html` — Ericsson · V4.06
- `ER07.dc.html` — Ericsson · V4.07 · T4 quote
- `ER08.dc.html` — Ericsson · V4.08
- `ER09.dc.html` — Ericsson · V4.09
- `ER10.dc.html` — Ericsson · V4.10
- `ER11.dc.html` — Ericsson · V4.11 · 4c
- `ER12.dc.html` — Ericsson · V4.12
- `ER13.dc.html` — Ericsson · V4.13 thread
- `ER14.dc.html` — Ericsson · V4.14 thread
- `ER15.dc.html` — Ericsson · V4.15
- `ER16.dc.html` — Ericsson · V4.16 · T3
- `ER17.dc.html` — Ericsson · V4.17 · T5
- `ER18.dc.html` — Ericsson · V4.18 · T5
- `ERNight.dc.html` — Ericsson · all views at night

### Story: I cheated! (8 views)

- `S01.dc.html` — I cheated! · V01 · T1
- `S02.dc.html` — I cheated! · V02
- `S03.dc.html` — I cheated! · V03
- `S04.dc.html` — I cheated! · V04
- `S05.dc.html` — I cheated! · V05
- `S06.dc.html` — I cheated! · V06
- `S07.dc.html` — I cheated! · V07
- `S08.dc.html` — I cheated! · V08 · next story
- `StoryNight.dc.html` — I cheated! · all views at night

### Key frames

- `K-Telkomsel.dc.html` — 2.2 Telkomsel · day
- `K-Trying.dc.html` — 2.3 A year of trying · day
- `K-Ericsson.dc.html` — 2.4 Ericsson · day
- `K-Kanzway.dc.html` — 2.5 Kanzway · day
- `K-Community.dc.html` — 2.6 Learning through community · day
- `K-Jhah.dc.html` — 2.7 JHAH · day
- `K-Portfolio.dc.html` — 3 Portfolio · day
- `K-Writing.dc.html` — 4 What I write about · day
- `K-Recognition.dc.html` — 5 Community & recognition · day
- `K-Passions.dc.html` — 6 Passions · day
- `K-Tips.dc.html` — 7 Tips · day
- `K-Skills.dc.html` — 8 Skills, tools & certificates · day
- `K-Connect.dc.html` — 9 Let's connect · day
- `KeyNightA.dc.html` — Key frames 2.2–2.7 + Portfolio · night
- `KeyNightB.dc.html` — Key frames 4–9 · night

### Motion

- `M-View.dc.html` — Storyboard · view to view
- `M-Section.dc.html` — Storyboard · section to section
- `M-Spine.dc.html` — Storyboard · timeline-spine jump
- `M-LightDark.dc.html` — Storyboard · light / dark switch
- `M-Spec.dc.html` — Motion spec for developers

### Navigation & fallbacks

- `N-Library.dc.html` — Story library page
- `N-Article.dc.html` — Read as article mode
- `N-Spine.dc.html` — Timeline spine + chapter menu
- `N-Fallbacks.dc.html` — Fallbacks · reduced motion · still · tablet

### Other files

- `canvas.json` — the canvas: its pages, where each artboard sits, its notes and shapes
- `_runtime/` — what runs the pages in a browser; not part of the design

## Viewing

To view a page, start a local web server in this folder (for example `python3 -m http.server`), then open an artboard’s `.dc.html` file through it. Opening the file directly may not work, because some browsers block its scripts.

## Left out of this export

The export never includes hidden files (files whose names start with a dot) or
files the editor keeps for its own use.
